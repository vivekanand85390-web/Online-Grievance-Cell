$files = @('about.php','contact.php','forgot_password.php','index.php','steps_to_lodge.php','submit_grievance.php','team_members.php')
foreach($f in $files) {
    $path = "c:\xampp\htdocs\Online Grievance Cell\" + $f
    $c = Get-Content $path -Raw

    $c = $c -replace '(?s)\.header-branding\s*\{.*?\}(?=\s*\.header-logo)', ".header-branding {`r`n            display: flex;`r`n            justify-content: space-between;`r`n            align-items: center;`r`n            gap: 1rem;`r`n            width: 100%;`r`n            padding: 1rem 2rem;`r`n        }`r`n"
    
    $c = $c -replace 'justify-self:\s*start;', 'flex: 0 0 auto;'
    $c = $c -replace 'justify-self:\s*end;', 'flex: 0 0 auto;'

    $c = $c -replace '(?s)\.header-titles\s*\{.*?\}(?=\s*\.header-titles \.main-title)', ".header-titles {`r`n            text-align: center;`r`n            flex: 1 1 auto;`r`n            min-width: 0;`r`n            padding: 0 1rem;`r`n        }`r`n"

    $c = $c -replace '(?s)(\.header-titles \.main-title\s*\{.*?)(font-size:\s*3\.8rem;)(.*?\})', "`$1font-size: clamp(2rem, 3.5vw, 3.8rem); line-height: 1.1;`$3"
    $c = $c -replace '(?s)(\.header-titles \.main-title\s*\{.*?)(white-space:\s*nowrap;)(.*?\})', "`$1white-space: normal; word-wrap: break-word;`$3"

    $c = $c -replace '(?s)(\.header-titles \.sub-title\s*\{.*?)(font-size:\s*2\.2rem;)(.*?\})', "`$1font-size: clamp(1.2rem, 2vw, 2.2rem); line-height: 1.2;`$3"
    $c = $c -replace '(?s)(\.header-titles \.sub-title\s*\{.*?)(white-space:\s*nowrap;)(.*?\})', "`$1white-space: normal; word-wrap: break-word;`$3"

    Set-Content -Path $path -Value $c
    Write-Host "Fixed $f"
}
