<?php
// config/mail.php — Gmail SMTP Configuration
// ══════════════════════════════════════════════
// SETUP STEPS:
// 1. Google Account → Security → 2-Step Verification (ON karo)
// 2. Security → App Passwords → Select App: Mail → Generate
// 3. 16-character password milega — niche paste karo
// ══════════════════════════════════════════════

define('MAIL_HOST',       'smtp.gmail.com');
define('MAIL_PORT',       587);
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_USERNAME',   'your_gmail@gmail.com');    // <-- Apna Gmail daalo
define('MAIL_PASSWORD',   'xxxx xxxx xxxx xxxx');     // <-- Gmail App Password (16 chars)
define('MAIL_FROM_EMAIL', 'your_gmail@gmail.com');    // <-- Same Gmail
define('MAIL_FROM_NAME',  'NSTI Grievance System');
