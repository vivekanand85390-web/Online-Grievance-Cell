<?php
// ─────────────────────────────────────────────
//  SMS Configuration — Fast2SMS
//  Get your FREE API key from: https://www.fast2sms.com/
//  1. Register at fast2sms.com
//  2. Go to Dev API → API Key
//  3. Paste it below
// ─────────────────────────────────────────────

define('FAST2SMS_API_KEY', 'YOUR_FAST2SMS_API_KEY_HERE');  // ← paste your key here

// Sender ID (default is 'FSTSMS' for free accounts, or your registered sender ID)
define('FAST2SMS_SENDER_ID', 'FSTSMS');

// Route: 'q' = Quick SMS (transactional), 'p' = Promotional
define('FAST2SMS_ROUTE', 'q');
