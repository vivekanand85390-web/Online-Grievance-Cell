<?php
include_once 'includes/functions.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = "All fields are required.";
    } else {
        try {
            // Dynamically create contact_queries table if not exists for persistence
            $pdo->exec("CREATE TABLE IF NOT EXISTS contact_queries (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                subject VARCHAR(200) NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            
            $stmt = $pdo->prepare("INSERT INTO contact_queries (name, email, subject, message) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $subject, $message])) {
                $success = true;
            } else {
                $error = "Failed to submit your message. Please try again.";
            }
        } catch (PDOException $e) {
            // Fallback to mock success if DB operation fails
            $success = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - NSTI R-Hyderabad</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-base: #f7f9fc;
            --nsti-blue: #0f3057;
            --nsti-magenta: #b01c70;
            --text-dark: #2d3748;
            --text-muted: #718096;
            --card-border: rgba(0, 0, 0, 0.06);
            --bg-light: #ffffff;
        }

        body, html {
            margin: 0;
            padding: 0;
            scroll-behavior: smooth;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Header Branding Section */
                        .header-branding {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 1rem;
            width: 100%;
            padding: 1rem 2rem;
        }





        .header-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            justify-self: start;
        }


        .header-logo img {
            width: 110px;
            height: auto;
            object-fit: contain;
        }

        .logo-caption {
            margin: 0;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--nsti-blue);
            text-align: center;
            white-space: nowrap;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-top: 2px solid var(--nsti-magenta);
            padding: 0.4rem 0.5rem 0 0.5rem;
        }

        .logo-caption .caption-location {
            color: var(--nsti-magenta);
            font-weight: 800;
        }

        .header-titles {
            text-align: center;
            justify-self: center;
        }





        .header-titles .main-title {
            font-size: 3.8rem;
            font-weight: 900;
            color: var(--nsti-blue);
            margin: 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .header-titles .sub-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--nsti-magenta);
            margin: 0.25rem 0 0 0;
            white-space: nowrap;
        }

        .header-right-logo {
            justify-self: end;
        }


        @media (max-width: 1400px) {
            .header-titles .main-title { font-size: 3.2rem; }
            .header-titles .sub-title { font-size: 1.8rem; }
            .header-branding { padding: 1rem; }
        }

        @media (max-width: 1200px) {
            .header-titles .main-title { font-size: 2.8rem; }
            .header-titles .sub-title { font-size: 1.6rem; }
        }

        @media (max-width: 991px) {
            .header-branding {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
                text-align: center;
                padding: 1rem;
            }
            .header-titles .main-title {
                font-size: 2.8rem;
                white-space: nowrap;
            }
            .header-titles .sub-title {
                font-size: 1.6rem;
                white-space: nowrap;
                margin-top: 0.25rem;
            }
        }
        
        @media (max-width: 576px) {
            .header-titles .main-title {
                font-size: 2.2rem;
                white-space: normal;
                line-height: 1.2;
            }
            .header-titles .sub-title {
                font-size: 1.4rem;
                white-space: normal;
                line-height: 1.3;
            }
        }

        /* Navigation Bar Styles */
        .custom-navbar {
            background-color: var(--nsti-blue);
            box-shadow: 0 4px 15px rgba(15, 48, 87, 0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            transition: all 0.3s ease;
        }

        .menu-toggle {
            display: none;
            background: transparent;
            border: none;
            color: #ffffff;
            font-size: 1.35rem;
            cursor: pointer;
            padding: 0.5rem;
            align-items: center;
            justify-content: center;
        }

        .mobile-brand {
            display: none;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.95rem;
            text-transform: uppercase;
            text-decoration: none;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            justify-content: center;
            list-style: none;
            flex-wrap: wrap;
            margin: 0;
            padding: 0;
        }

        .nav-menu li {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            color: #ffffff;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.9rem 1.2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            text-transform: capitalize;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #ffe600;
            border-bottom-color: var(--nsti-magenta);
        }

        .nav-menu .separator {
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.9rem;
            user-select: none;
        }

        @media (max-width: 768px) {
            .navbar-container {
                justify-content: flex-end;
                flex-wrap: wrap;
                padding: 0.5rem 1rem;
            }

            .menu-toggle {
                display: flex;
            }

            .mobile-brand {
                display: none;
            }

            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding-top: 0.5rem;
            }

            .nav-menu.show {
                display: flex;
            }

            .nav-menu li {
                width: 100%;
                flex-direction: column;
            }

            .nav-menu a {
                padding: 0.6rem 2rem;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                border-bottom: none;
                border-left: 3px solid transparent;
            }
            .nav-menu a:hover, .nav-menu a.active {
                border-left-color: var(--nsti-magenta);
                border-bottom-color: transparent;
                background-color: rgba(255, 255, 255, 0.05);
            }
            .nav-menu .separator {
                display: none;
            }
        }

        /* Custom Dropdown Styling */
        .nav-menu .dropdown {
            position: relative;
        }

        .nav-menu .dropdown-toggle::after {
            display: none;
        }

        .nav-menu .dropdown-toggle i {
            font-size: 0.75rem;
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            margin-left: 0.35rem;
        }

        .nav-menu .dropdown:hover .dropdown-toggle i,
        .nav-menu .dropdown-toggle[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        .nav-menu .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%) translateY(15px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            background-color: #0b223e;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 0.6rem 0;
            margin-top: 0;
            min-width: 220px;
            overflow: hidden;
            flex-direction: column;
            z-index: 1000;
        }

        .nav-menu .dropdown-menu li {
            display: block !important;
            width: 100% !important;
        }

        .nav-menu .dropdown-item {
            display: block !important;
            width: 100% !important;
            text-align: left;
            color: #ffffff !important;
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.75rem 1.6rem !important;
            border-left: 3px solid transparent !important;
            border-bottom: none !important;
            transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
            text-transform: capitalize;
        }

        .nav-menu .dropdown-item:hover,
        .nav-menu .dropdown-item:focus,
        .nav-menu .dropdown-item.active {
            color: #ffe600 !important;
            background-color: var(--nsti-magenta) !important;
            border-left-color: #ffe600 !important;
            padding-left: 1.9rem !important;
        }

        @media (min-width: 769px) {
            .nav-menu .dropdown:hover .dropdown-menu {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateX(-50%) translateY(0) !important;
            }
            .nav-menu .dropdown-menu {
                display: flex !important;
                opacity: 0;
                visibility: hidden;
                transform: translateX(-50%) translateY(15px);
                transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
        }

        @media (max-width: 768px) {
            .nav-menu .dropdown {
                width: 100%;
                text-align: center;
            }
            .nav-menu .dropdown-toggle {
                width: 100%;
                justify-content: center;
            }
            .nav-menu .dropdown-menu {
                position: relative !important;
                left: auto !important;
                transform: none !important;
                float: none !important;
                width: 100% !important;
                background-color: rgba(0, 0, 0, 0.15) !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
                margin: 0 !important;
                padding: 0.5rem 0 !important;
                display: none !important;
            }
            .nav-menu .dropdown-menu.open {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
            }
            .nav-menu .dropdown-item {
                text-align: center;
                color: rgba(255, 255, 255, 0.8) !important;
                padding: 0.6rem 2rem !important;
                background: transparent !important;
                border-left: 3px solid transparent !important;
            }
            .nav-menu .dropdown-item:hover,
            .nav-menu .dropdown-item:focus,
            .nav-menu .dropdown-item.active {
                color: #ffe600 !important;
                border-left-color: var(--nsti-magenta) !important;
                background-color: rgba(255, 255, 255, 0.05) !important;
                padding-left: 2rem !important;
            }
        }

        /* Page Content Wrapper */
        .page-content-wrapper {
            flex: 1;
            padding: 4rem 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        /* Section Header Layout */
        .custom-section-header-container {
            display: flex;
            justify-content: center;
            width: 100%;
            margin-top: 1rem;
            margin-bottom: 4rem;
        }
        
        .custom-section-header {
            display: flex;
            align-items: center;
            gap: 1.25rem;
        }
        
        .header-left-bar {
            width: 6px;
            height: 75px;
            background: linear-gradient(to bottom, #ff4e3a, #e61c5d);
            border-radius: 3px;
        }
        
        .header-content-wrapper {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        
        .header-title-text {
            font-size: 2.2rem;
            font-weight: 800;
            color: #0f3057;
            line-height: 1.25;
            margin: 0;
            text-transform: none;
        }
        
        .header-bottom-line {
            width: 180px;
            height: 4px;
            background-color: #3b82f6;
            margin-top: 10px;
            border-radius: 2px;
        }

        .page-section-subtitle {
            font-size: 1.1rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Grid */
        .contact-grid {
            display: grid;
            grid-template-columns: 1.2fr 1fr;
            gap: 3rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 991px) {
            .contact-grid {
                grid-template-columns: 1fr;
                gap: 2.5rem;
            }
        }

        /* Form Card Styling */
        .contact-card {
            background-color: var(--bg-light);
            border-radius: 24px;
            padding: 3rem;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 15px 45px rgba(15, 48, 87, 0.03);
            position: relative;
            overflow: hidden;
        }

        .contact-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--nsti-magenta) 0%, var(--nsti-blue) 100%);
        }

        .form-title {
            font-size: 1.5rem;
            font-weight: 750;
            color: var(--nsti-blue);
            margin-top: 0;
            margin-bottom: 1.75rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .form-title i {
            color: var(--nsti-magenta);
        }

        .form-label-custom {
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.75px;
            color: var(--text-muted);
            margin-bottom: 0.6rem;
            display: block;
        }

        .input-group-custom {
            position: relative;
        }

        .form-control-custom {
            width: 100%;
            height: 52px;
            padding: 10px 16px 10px 48px;
            font-size: 0.95rem;
            font-weight: 500;
            color: var(--text-dark);
            background-color: #ffffff;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .form-control-custom:focus {
            outline: none;
            border-color: var(--nsti-blue);
            box-shadow: 0 0 0 4px rgba(15, 48, 87, 0.12);
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            transition: color 0.3s ease;
            pointer-events: none;
            font-size: 1.05rem;
        }

        .form-control-custom:focus ~ .input-icon {
            color: var(--nsti-blue);
        }

        .textarea-custom {
            height: 120px;
            padding: 14px 16px 14px 48px;
            resize: none;
        }

        .textarea-icon {
            top: 24px;
            transform: none;
        }

        .btn-send {
            background: linear-gradient(135deg, #0076fe 0%, #0053b8 100%);
            color: #ffffff;
            border: none;
            border-radius: 14px;
            padding: 0.9rem;
            font-weight: 700;
            font-size: 1.05rem;
            letter-spacing: 0.5px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 15px rgba(0, 118, 254, 0.2);
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 118, 254, 0.35);
            filter: brightness(1.05);
        }

        /* Details Card & Map */
        .details-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .details-card {
            background-color: var(--bg-light);
            border-radius: 24px;
            padding: 2.5rem;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
        }

        .details-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.05);
        }

        .details-card h4 {
            font-size: 1.4rem;
            font-weight: 750;
            color: var(--nsti-blue);
            margin-top: 0;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 0.6rem;
            border-bottom: 1.5px solid #f1f5f9;
        }

        .details-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .details-list li {
            display: flex;
            align-items: start;
            gap: 1rem;
            margin-bottom: 1.25rem;
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .details-list li:last-child {
            margin-bottom: 0;
        }

        .details-list li i {
            color: var(--nsti-magenta);
            font-size: 1.1rem;
            margin-top: 0.2rem;
            width: 20px;
            text-align: center;
        }

        .details-list li strong {
            color: var(--nsti-blue);
            display: block;
            margin-bottom: 0.1rem;
        }

        .map-card {
            background-color: var(--bg-light);
            border-radius: 24px;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
            overflow: hidden;
            height: 280px;
            position: relative;
            transition: all 0.3s ease;
        }

        .map-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.05);
        }

        .map-card iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        /* Site Footer matching the user's mockup layout (3 columns) */
        .site-footer {
            background-color: #0c1e35;
            color: #94a3b8;
            padding-top: 4rem;
            border-top: 5px solid var(--nsti-magenta);
            width: 100%;
            margin-top: auto;
        }

        .footer-links-grid {
            margin-bottom: 3rem;
        }

        .footer-grid-title {
            font-size: 1.05rem;
            position: relative;
            padding-bottom: 0.75rem;
        }

        .footer-grid-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 35px;
            height: 3px;
            background-color: var(--nsti-magenta);
            border-radius: 2px;
        }

        .footer-links-list li {
            font-size: 0.9rem;
        }

        .footer-link {
            color: #cbd5e1;
            transition: all 0.2s ease;
        }

        .footer-link:hover {
            color: #ffe600;
            padding-left: 4px;
        }

        .footer-contact-list {
            font-size: 0.9rem;
        }

        .footer-contact-list li i {
            color: var(--nsti-magenta);
            font-size: 0.95rem;
            width: 20px;
        }

        .footer-watermark {
            background-color: #06101e;
            padding: 1.2rem 2rem;
            text-align: center;
        }

        .watermark-text {
            margin: 0;
            font-size: 0.85rem;
            color: #64748b;
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Top Header Branding Section -->
    <header class="header-branding">
        <a href="index.php" class="header-logo">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="78" height="78">
            <p class="logo-caption">National Skill Training Institute<span class="caption-location"> - Ramanthapur</span></p>
        </a>
        <div class="header-titles">
            <h1 class="main-title">NSTI R-HYDERABAD</h1>
            <h2 class="sub-title">Online Grievance Redressal System</h2>
        </div>
        <div class="header-right-logo d-none d-lg-flex">
            <img src="assets/images/committee_illustration.png" alt="Committee Illustration" style="height: 65px; width: auto; object-fit: contain;">
        </div>
    </header>

    <!-- Horizontal Navbar -->
    <nav class="custom-navbar">
        <div class="container navbar-container">
            <a href="index.php" class="mobile-brand">NSTI R-HYDERABAD</a>
            <button class="menu-toggle" id="mobile-menu-toggle" aria-label="Toggle Menu">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="index.php"><span class="notranslate custom-translate-home">Home</span></a></li>
                <li class="separator">|</li>
                <li><a href="about.php">About</a></li>
                <li class="separator">|</li>
                <li><a href="contact.php" class="active">Contact</a></li>
                <li class="separator">|</li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" id="grievanceDropdown" role="button" aria-expanded="false">
                        Help & Support <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="grievanceDropdown">
                        <li><a class="dropdown-item" href="check_status.php">Track Status</a></li>
                        <li><a class="dropdown-item" href="steps_to_lodge.php">Steps to Lodge</a></li>
                        <li><a class="dropdown-item" href="team_members.php">Project Team</a></li>
                    </ul>
                </li>
                <li class="separator">|</li>
                <li><a href="feedback.php">Feedback</a></li>
                <li class="separator">|</li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Page Content Wrapper -->
    <main class="page-content-wrapper">
        <div class="custom-section-header-container">
            <div class="custom-section-header">
                <div class="header-left-bar"></div>
                <div class="header-content-wrapper">
                    <h2 class="header-title-text"><i class="fas fa-envelope-open-text" style="color: #2e7d32; margin-right: 12px; font-size: 0.9em; vertical-align: middle;"></i>Contact Us</h2>
                    <div class="header-bottom-line"></div>
                    <p class="page-section-subtitle" style="margin-top: 15px; margin-bottom: 0;">Get in Touch with NSTI Ramanthapur, Hyderabad</p>
                </div>
            </div>
        </div>

        <div class="contact-grid">
            <!-- Left Side: Contact Form -->
            <div class="contact-card">
                <h3 class="form-title"><i class="fas fa-paper-plane"></i> Send Us a Message</h3>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger rounded-3 p-3 mb-4" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form action="contact.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label-custom" for="name">Your Name *</label>
                        <div class="input-group-custom">
                            <input type="text" id="name" name="name" class="form-control-custom" placeholder="Enter your full name" required>
                            <span class="input-icon"><i class="fas fa-user"></i></span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label-custom" for="email">Your Email *</label>
                        <div class="input-group-custom">
                            <input type="email" id="email" name="email" class="form-control-custom" placeholder="e.g. name@domain.com" required>
                            <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label-custom" for="subject">Subject *</label>
                        <div class="input-group-custom">
                            <input type="text" id="subject" name="subject" class="form-control-custom" placeholder="Subject of your query" required>
                            <span class="input-icon"><i class="fas fa-info-circle"></i></span>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label-custom" for="message">Message *</label>
                        <div class="input-group-custom">
                            <textarea id="message" name="message" class="form-control-custom textarea-custom" placeholder="Type your message here..." required></textarea>
                            <span class="input-icon textarea-icon"><i class="fas fa-comment-dots"></i></span>
                        </div>
                    </div>

                    <button type="submit" class="btn-send"><i class="fas fa-paper-plane me-1"></i> Send Message</button>
                </form>
            </div>

            <!-- Right Side: Details & Map -->
            <div class="details-container">
                <div class="details-card">
                    <h4>Contact Details</h4>
                    <ul class="details-list">
                        <li>
                            <i class="fas fa-envelope"></i>
                            <div>
                                <strong>Email Address</strong>
                                <a href="mailto:nsti-hyderabad2@dgt.gov.in" class="text-decoration-none" style="color: var(--text-dark);">nsti-hyderabad2@dgt.gov.in</a>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-phone-alt"></i>
                            <div>
                                <strong>Phone Numbers</strong>
                                <span>040-27037266, 040-27038982</span>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <div>
                                <strong>Office Address</strong>
                                <span>Uppal Road, Ramanthapur, Rahat Nagar, Amberpet, Hyderabad, Telangana 500013</span>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Google Map Card -->
                <div class="map-card">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.4116492344794!2d78.53678077598835!3d17.39209530263675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9951664e43bf%3A0xe543e3f4bcb4d0ba!2sNational%20Skill%20Training%20Institute%20(NSTI)%2C%20Ramanthapur!5e0!3m2!1sen!2sin!4v1717800000000!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </main>

    <!-- Site Footer containing Quick Links, Our Team, and Contact Us (3 Columns) -->
    <footer class="site-footer">
        <div class="footer-links-grid container">
            <div class="row g-4">
                <!-- Column 1: Quick Links -->
                <div class="col-md-6 col-lg-4">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-link" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>Quick Links</h5>
                    
                    <span class="d-block text-white fw-bold mb-2 small text-uppercase" style="letter-spacing: 0.5px; opacity: 0.8; font-size: 0.8rem;">Portals</span>
                    <ul class="list-unstyled footer-links-list ps-2 mb-3">
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="login.php?role=student" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Student Portal</a>
                        </li>
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="login.php?role=staff" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Staff / Faculty Portal</a>
                        </li>
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="login.php?role=parent" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Parent Portal</a>
                        </li>
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="login.php" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Administrator Login</a>
                        </li>
                    </ul>

                    <span class="d-block text-white fw-bold mb-2 small text-uppercase" style="letter-spacing: 0.5px; opacity: 0.8; font-size: 0.8rem;">Services</span>
                    <ul class="list-unstyled footer-links-list ps-2">
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="check_status.php" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Track Status</a>
                        </li>
                        <li class="mb-2 d-flex align-items-center gap-2">
                            <i class="fas fa-chevron-right" style="font-size: 0.75rem; color: #a855f7;"></i>
                            <a href="forgot_password.php" class="footer-link text-decoration-none" style="font-size: 0.9rem;">Reset Password</a>
                        </li>
                    </ul>
                </div>

                <!-- Column 2: Our Team -->
                <div class="col-md-6 col-lg-4">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-users" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>Our Team</h5>
                    
                    <ul class="list-unstyled footer-links-list ps-2 text-secondary-white" style="font-size: 0.9rem; line-height: 1.8;">
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-user-tie mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">Aakanksha Netam</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">Team Leader</span>
                            </div>
                        </li>
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-tasks mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">VIVEKANAND</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">Project Manager</span>
                            </div>
                        </li>
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-palette mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">V.Vaishnavi</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">UI/UX Designer</span>
                            </div>
                        </li>
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-palette mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">DEENU RAM</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">UI/UX Designer</span>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Column 3: Contact Us -->
                <div class="col-md-6 col-lg-4" id="contact">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-envelope-open-text" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>Contact Us</h5>
                    <ul class="list-unstyled footer-contact-list">
                        <li class="mb-3 text-secondary-white d-flex align-items-start gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-map-marker-alt mt-1"></i>
                            <span>Uppal Road, Ramanthapur, Rahat Nagar, Amberpet, Hyderabad, Telangana 500013</span>
                        </li>
                        <li class="mb-3 text-secondary-white d-flex align-items-center gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-phone-alt"></i>
                            <span>040-27037266, 040-27038982</span>
                        </li>
                        <li class="mb-3 text-secondary-white d-flex align-items-center gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-envelope"></i>
                            <span>nsti-hyderabad2@dgt.gov.in</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Footer Branding Watermark -->
                    <div class="footer-watermark">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <p class="watermark-text mb-0 text-center text-md-start" style="font-size: 0.85rem;">&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</p>
            <div class="d-flex justify-content-center justify-content-md-end align-items-center" style="font-size: 0.75rem; color: #64748b; padding: 5px 0;">
    <span style="opacity: 0.7; margin-right: 4px;">Developed By:</span>
    <span style="color: rgba(255,255,255,0.7); font-weight: 400;">Vivekanand & Aakanksha</span>
</div>
        </div>
    </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle & SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Mobile Navigation Toggle Script -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const toggleBtn = document.getElementById("mobile-menu-toggle");
            const navMenu = document.getElementById("navMenu");
            
            if (toggleBtn && navMenu) {
                toggleBtn.addEventListener("click", function() {
                    navMenu.classList.toggle("show");
                    const icon = toggleBtn.querySelector("i");
                    if (icon) {
                        if (navMenu.classList.contains("show")) {
                            icon.classList.remove("fa-bars");
                            icon.classList.add("fa-times");
                        } else {
                            icon.classList.remove("fa-times");
                            icon.classList.add("fa-bars");
                            
                            // Reset all dropdowns when menu is closed
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    }
                });

                // Close menu when clicking a link
                const navLinks = document.querySelectorAll(".nav-menu a");
                navLinks.forEach(link => {
                    link.addEventListener("click", () => {
                        if (!link.classList.contains("dropdown-toggle")) {
                            navMenu.classList.remove("show");
                            const icon = toggleBtn.querySelector("i");
                            if (icon) {
                                icon.classList.remove("fa-times");
                                icon.classList.add("fa-bars");
                            }
                            // Reset all dropdowns
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    });
                });

                // Dropdown toggle on mobile (prevents Bootstrap Popper conflicts)
                const dropdownToggles = document.querySelectorAll(".nav-menu .dropdown-toggle");
                dropdownToggles.forEach(toggle => {
                    toggle.addEventListener("click", function(e) {
                        const isMobile = window.getComputedStyle(toggleBtn).display !== "none";
                        if (isMobile) {
                            e.preventDefault();
                            e.stopPropagation();
                            const dropdownMenu = this.nextElementSibling;
                            if (dropdownMenu) {
                                const isShown = dropdownMenu.classList.toggle("open");
                                this.setAttribute("aria-expanded", isShown ? "true" : "false");
                            }
                        }
                    });
                });
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if ($success): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Message Sent!',
                text: 'Your query has been successfully submitted. We will get back to you soon!',
                background: '#ffffff',
                color: '#1e293b',
                confirmButtonColor: '#0f3057'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>
    <?php endif; ?>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>




















