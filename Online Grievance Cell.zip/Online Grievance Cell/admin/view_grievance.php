<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

$id = $_GET['id'] ?? null;
if (!$id) redirect('manage_grievances.php');

// Fetch grievance
$stmt = $pdo->prepare("SELECT g.*, c.name as category, u.name as user_name, u.email as user_email, u.contact as user_contact
                       FROM grievances g 
                       JOIN categories c ON g.category_id = c.id 
                       JOIN users u ON g.user_id = u.id 
                       WHERE g.id = ?");
$stmt->execute([$id]);
$g = $stmt->fetch();

if (!$g) redirect('manage_grievances.php', 'Grievance not found', 'error');

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $message = sanitize($_POST['message']);
    $admin_id = $_SESSION['user_id'];

    $pdo->beginTransaction();
    try {
        // Update grievance status
        $stmt_u = $pdo->prepare("UPDATE grievances SET status = ? WHERE id = ?");
        $stmt_u->execute([$status, $id]);

        // Add to updates table
        $stmt_tu = $pdo->prepare("INSERT INTO grievance_updates (grievance_id, updated_by, status, message) VALUES (?, ?, ?, ?)");
        $stmt_tu->execute([$id, $admin_id, $status, $message]);

        // Add notification for user
        $stmt_not = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $stmt_not->execute([$g['user_id'], "Grievance {$g['complaint_id']} status updated to $status"]);

        $pdo->commit();
        redirect("view_grievance.php?id=$id", 'Grievance updated successfully', 'success');
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['msg'] = "Error updating grievance: " . $e->getMessage();
        $_SESSION['msg_type'] = "error";
    }
}

// Fetch updates
$stmt_up = $pdo->prepare("SELECT gu.*, u.name as updater_name FROM grievance_updates gu JOIN users u ON gu.updated_by = u.id WHERE gu.grievance_id = ? ORDER BY gu.created_at DESC");
$stmt_up->execute([$id]);
$updates = $stmt_up->fetchAll();

include_once '../includes/header.php';
?>

<div class="row fade-in">
    <div class="col-lg-8">
        <div class="glass-card mb-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0">Grievance #<?php echo $g['complaint_id']; ?></h3>
                <div>
                    <a href="../user/print_grievance.php?id=<?php echo $id; ?>" target="_blank" class="btn btn-outline-info me-2"><i class="fas fa-print me-1"></i> Print Form</a>
                    <span class="<?php echo getStatusBadge($g['status']); ?> fs-6 py-2 px-3"><?php echo getStatusLabel($g['status']); ?></span>
                </div>
            </div>
            
            <div class="mb-4">
                <h5 class="text-muted mb-2"><?php echo $g['title']; ?></h5>
                <p class="mb-0"><?php echo nl2br($g['description']); ?></p>
            </div>

            <?php if ($g['attachment']): ?>
                <div class="mb-0">
                    <a href="../uploads/<?php echo $g['attachment']; ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-paperclip me-2"></i>View Attachment
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Progress Update Form -->
        <?php if ($g['status'] != 'Resolved'): ?>
        <div class="glass-card mb-4" id="update-status-form" style="scroll-margin-top: 80px;">
            <h4 class="mb-4">Update Resolution Status</h4>
            <form action="view_grievance.php?id=<?php echo $id; ?>" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="input-label">Update Status</label>
                        <select name="status" class="form-control" required>
                            <option value="Pending" <?php echo $g['status'] == 'Pending' ? 'selected' : ''; ?>>Not Processed</option>
                            <option value="In Progress" <?php echo $g['status'] == 'In Progress' ? 'selected' : ''; ?>>Under Process</option>
                            <option value="Resolved" <?php echo $g['status'] == 'Resolved' ? 'selected' : ''; ?>>Resolved Complaint</option>
                            <option value="Rejected" <?php echo $g['status'] == 'Rejected' ? 'selected' : ''; ?>>Rejected Complaint</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="input-label">Officer's Response/Message</label>
                        <textarea name="message" class="form-control" rows="4" placeholder="Enter your response here..." required></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-premium px-5">Submit Update</button>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- History -->
        <div class="glass-card">
            <h4 class="mb-4">Internal Log / Timeline</h4>
            <div class="list-group">
                <?php foreach ($updates as $u): ?>
                    <div class="list-group-item bg-white mb-3 rounded p-3" style="border: 1px solid rgba(0,0,0,0.08) !important; box-shadow: 0 4px 12px rgba(0,0,0,0.015);">
                        <div class="d-flex justify-content-between">
                            <span class="<?php echo getStatusBadge($u['status']); ?> mb-2"><?php echo getStatusLabel($u['status']); ?></span>
                            <small class="text-muted"><?php echo date('d M, h:i A', strtotime($u['created_at'])); ?></small>
                        </div>
                        <p class="mb-1 text-dark"><?php echo nl2br($u['message']); ?></p>
                        <small class="text-muted">Updated by: <?php echo $u['updater_name']; ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar Info -->
    <div class="col-lg-4">
        <div class="glass-card mb-4">
            <h5 class="mb-4 text-muted border-bottom border-secondary pb-2">Complainant Info</h5>
            <div class="mb-3">
                <small class="text-muted d-block">Name</small>
                <span class="fw-bold"><?php echo $g['user_name']; ?></span>
            </div>
            <div class="mb-3">
                <small class="text-muted d-block">Email</small>
                <span class="fw-bold"><?php echo $g['user_email']; ?></span>
            </div>
            <div class="mb-3">
                <small class="text-muted d-block">Contact</small>
                <span class="fw-bold"><?php echo $g['user_contact']; ?></span>
            </div>
        </div>

        <div class="glass-card bg-purple-gradient text-white">
            <h5 class="mb-3">Quick Actions</h5>
            <div class="d-grid gap-2">
                <a href="mailto:<?php echo $g['user_email']; ?>" class="btn btn-light btn-sm">Email Complainant</a>
                <a href="../user/print_grievance.php?id=<?php echo $id; ?>" target="_blank" class="btn btn-outline-light btn-sm">Print Report</a>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
