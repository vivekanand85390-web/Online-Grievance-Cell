<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

// Ensure is_disabled column exists for the new Disable feature
try {
    $pdo->exec("ALTER TABLE grievances ADD COLUMN IF NOT EXISTS is_disabled TINYINT(1) DEFAULT 0");
} catch(PDOException $e) {
    // Ignore if column already exists (MySQL < 8 doesn't support IF NOT EXISTS for ALTER TABLE perfectly, so we catch)
    try {
        $pdo->exec("ALTER TABLE grievances ADD COLUMN is_disabled TINYINT(1) DEFAULT 0");
    } catch(PDOException $e2) {}
}

// Handle Actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $id = (int)$_GET['id'];
    
    if ($action === 'remove') {
        $stmt = $pdo->prepare("DELETE FROM grievances WHERE id = ?");
        $stmt->execute([$id]);
        redirect('manage_grievances.php', 'Grievance removed successfully!', 'success');
    } elseif ($action === 'disable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 1 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('manage_grievances.php', 'Grievance disabled.', 'success');
    } elseif ($action === 'enable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 0 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('manage_grievances.php', 'Grievance enabled.', 'success');
    }
}

// Admin type
$admin_type = $_SESSION['admin_type'] ?? 'main';

// Formulate level restriction SQL based on admin tier
$level_cond = "1=1";
if ($admin_type === 'department') {
    $level_cond = "DATEDIFF(NOW(), g.created_at) < 7";
} elseif ($admin_type === 'college') {
    $level_cond = "DATEDIFF(NOW(), g.created_at) >= 7 AND DATEDIFF(NOW(), g.created_at) < 14";
} elseif ($admin_type === 'university') {
    $level_cond = "DATEDIFF(NOW(), g.created_at) >= 14";
}

// Search and Filter
$where = "WHERE $level_cond";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $s = sanitize($_GET['search']);
    $where .= " AND (g.complaint_id LIKE '%$s%' OR g.title LIKE '%$s%' OR u.name LIKE '%$s%')";
}
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $st = sanitize($_GET['status']);
    $where .= " AND g.status = '$st'";
}
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $cat = (int)$_GET['category'];
    $where .= " AND g.category_id = $cat";
}
if (isset($_GET['role']) && !empty($_GET['role'])) {
    $roleFilter = sanitize($_GET['role']);
    $where .= " AND u.role = '$roleFilter'";
}

$stmt = $pdo->query("SELECT g.*, c.name as category, u.name as user_name 
                      FROM grievances g 
                      JOIN categories c ON g.category_id = c.id 
                      JOIN users u ON g.user_id = u.id 
                      $where 
                      ORDER BY g.created_at DESC");
$complaints = $stmt->fetchAll();

// Categories for filter
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

include_once '../includes/header.php';
?>

<div class="fade-in">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-5 mt-2">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold mb-1 theme-text" style="font-weight: 800; letter-spacing: -0.5px;"><i class="fas fa-clipboard-list me-2 text-primary opacity-75"></i>Manage Grievances</h2>
            <p class="theme-text-muted mb-0" style="font-size: 1.05rem;">Review, process, and track all submitted grievances.</p>
        </div>
    </div>

    <!-- Filters -->
    <div class="p-4 mb-4 theme-card" style="border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); border: 1px solid var(--border-color, #f8fafc);">
        <form action="manage_grievances.php" method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label mb-2" style="font-size: 0.65rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Search</label>
                <input type="text" name="search" class="form-control bg-white" placeholder="ID, Title, User..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; padding: 0.6rem 1rem; color: #475569; height: 42px;">
            </div>
            <div class="col-md-2">
                <label class="form-label mb-2" style="font-size: 0.65rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Status</label>
                <select name="status" class="form-select bg-white" style="border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; padding: 0.6rem 1rem; color: #475569; height: 42px;">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?php echo ($_GET['status'] ?? '') === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="In Progress" <?php echo ($_GET['status'] ?? '') === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Resolved" <?php echo ($_GET['status'] ?? '') === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
                    <option value="Rejected" <?php echo ($_GET['status'] ?? '') === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-2" style="font-size: 0.65rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Category</label>
                <select name="category" class="form-select bg-white" style="border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; padding: 0.6rem 1rem; color: #475569; height: 42px;">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo ((int)($_GET['category'] ?? 0) === $cat['id']) ? 'selected' : ''; ?>><?php echo $cat['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label mb-2" style="font-size: 0.65rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Role</label>
                <select name="role" class="form-select bg-white" style="border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; padding: 0.6rem 1rem; color: #475569; height: 42px;">
                    <option value="">All Roles</option>
                    <option value="student" <?php echo ($_GET['role'] ?? '') === 'student' ? 'selected' : ''; ?>>Student</option>
                    <option value="staff" <?php echo ($_GET['role'] ?? '') === 'staff' ? 'selected' : ''; ?>>Staff</option>
                    <option value="parent" <?php echo ($_GET['role'] ?? '') === 'parent' ? 'selected' : ''; ?>>Parent</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white" style="background: linear-gradient(135deg, #a855f7 0%, #6366f1 100%); border: none; border-radius: 8px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; height: 42px; transition: transform 0.2s ease, box-shadow 0.2s ease;" onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 4px 10px rgba(99,102,241,0.3)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">Filter</button>
            </div>
        </form>
    </div>

    <div class="glass-card theme-card p-0 overflow-hidden shadow-sm mb-5" style="border-radius: 16px; border: 1px solid var(--border-color, #f1f5f9);">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 border-0">
                <thead style="border-bottom: 2px solid var(--border-color, #e2e8f0);">
                    <tr>
                        <th class="ps-4 text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">ID</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">User</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Subject</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Priority</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Escalation Level</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Status</th>
                        <th class="pe-4 text-end text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Action</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (empty($complaints)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted"><i class="fas fa-folder-open fa-3x mb-3 text-light"></i><br>No grievances found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $c): ?>
                        <?php $level = getComplaintEscalationLevel($c['created_at'], $c['status']); ?>
                        <tr style="transition: all 0.2s ease; <?php echo (!empty($c['is_disabled'])) ? 'opacity: 0.6;' : ''; ?>">
                            <td class="ps-4 py-3 border-bottom theme-border">
                                <div class="fw-bold theme-text" style="font-size: 0.95rem;"><?php echo htmlspecialchars($c['complaint_id']); ?></div>
                            </td>
                            <td class="py-3 border-bottom theme-border">
                                <div class="fw-bold theme-text mb-0" style="font-size: 0.95rem;"><?php echo htmlspecialchars($c['user_name']); ?></div>
                                <div class="theme-text-muted" style="font-size: 0.8rem;"><?php echo htmlspecialchars($c['category']); ?></div>
                            </td>
                            <td class="py-3 border-bottom theme-border text-truncate theme-text" style="max-width: 200px; font-weight: 500; font-size: 0.9rem;">
                                <?php echo htmlspecialchars($c['title']); ?>
                            </td>
                            <td class="py-3 border-bottom theme-border">
                                <?php 
                                    $pColor = '#f1f5f9'; $pText = '#64748b';
                                    if(strtolower($c['priority']) === 'high') { $pColor = '#fee2e2'; $pText = '#ef4444'; }
                                    if(strtolower($c['priority']) === 'medium') { $pColor = '#ffedd5'; $pText = '#f97316'; }
                                    if(strtolower($c['priority']) === 'low') { $pColor = '#d1fae5'; $pText = '#10b981'; }
                                ?>
                                <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo $pColor; ?>; color: <?php echo $pText; ?>; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700;">
                                    <?php echo ucfirst($c['priority']); ?>
                                </span>
                            </td>
                            <td class="py-3 border-bottom theme-border">
                                <?php 
                                    $lColor = '#fef3c7'; $lText = '#d97706'; 
                                    if($level === 1) { $lColor = '#e0f2fe'; $lText = '#0ea5e9'; }
                                    elseif($level === 3) { $lColor = '#fee2e2'; $lText = '#ef4444'; }
                                ?>
                                <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo $lColor; ?>; color: <?php echo $lText; ?>; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700;">
                                    <?php echo getEscalationLabel($level); ?>
                                </span>
                            </td>
                            <td class="py-3 border-bottom theme-border">
                                <?php 
                                    $sColor = '#f1f5f9'; $sText = '#64748b';
                                    if(strtolower($c['status']) === 'pending' || strtolower($c['status']) === 'not processed') { $sColor = '#ffedd5'; $sText = '#f97316'; }
                                    if(strtolower($c['status']) === 'in progress' || strtolower($c['status']) === 'under process') { $sColor = '#e0e7ff'; $sText = '#6366f1'; }
                                    if(strtolower($c['status']) === 'resolved' || strtolower($c['status']) === 'resolved complaint') { $sColor = '#d1fae5'; $sText = '#10b981'; }
                                    if(strtolower($c['status']) === 'rejected' || strtolower($c['status']) === 'rejected complaint') { $sColor = '#fee2e2'; $sText = '#ef4444'; }
                                ?>
                                <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo $sColor; ?>; color: <?php echo $sText; ?>; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700;">
                                    <?php echo getStatusLabel($c['status']); ?>
                                </span>
                            </td>
                            <td class="pe-4 py-3 border-bottom theme-border text-end">
                                <div class="d-flex gap-1 justify-content-end">
                                    <a href="view_grievance.php?id=<?php echo $c['id']; ?>" class="btn btn-sm text-white shadow-sm" style="background-color: #22c55e; border-radius: 6px; font-weight: 600; font-size: 0.8rem; padding: 0.4rem 0.8rem; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85';" onmouseout="this.style.opacity='1';">View</a>
                                    <a href="view_grievance.php?id=<?php echo $c['id']; ?>#update-status-form" class="btn btn-sm text-white shadow-sm" style="background-color: #06b6d4; border-radius: 6px; font-weight: 600; font-size: 0.8rem; padding: 0.4rem 0.8rem; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85';" onmouseout="this.style.opacity='1';">Edit</a>
                                    <a href="manage_grievances.php?action=remove&id=<?php echo $c['id']; ?>" class="btn btn-sm text-white shadow-sm" style="background-color: #ef4444; border-radius: 6px; font-weight: 600; font-size: 0.8rem; padding: 0.4rem 0.8rem; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85';" onmouseout="this.style.opacity='1';" onclick="return confirm('Are you sure you want to permanently remove this grievance?');">Remove</a>
                                    <?php if (isset($c['is_disabled']) && $c['is_disabled']): ?>
                                        <a href="manage_grievances.php?action=enable&id=<?php echo $c['id']; ?>" class="btn btn-sm text-white shadow-sm" style="background-color: #64748b; border-radius: 6px; font-weight: 600; font-size: 0.8rem; padding: 0.4rem 0.8rem; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85';" onmouseout="this.style.opacity='1';">Active</a>
                                    <?php else: ?>
                                        <a href="manage_grievances.php?action=disable&id=<?php echo $c['id']; ?>" class="btn btn-sm text-white shadow-sm" style="background-color: #f59e0b; border-radius: 6px; font-weight: 600; font-size: 0.8rem; padding: 0.4rem 0.8rem; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85';" onmouseout="this.style.opacity='1';" onclick="return confirm('Are you sure you want to disable this grievance?');">Disable</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
