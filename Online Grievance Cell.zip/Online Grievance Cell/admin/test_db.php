<?php
require_once __DIR__ . '/../config/db.php';
$stmt = $pdo->query('DESCRIBE users');
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($res as $r) echo $r['Field'].", ";
echo "\n";
$stmt = $pdo->query('DESCRIBE grievances');
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($res as $r) echo $r['Field'].", ";
?>
