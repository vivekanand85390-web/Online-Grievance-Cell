<?php
include_once '../includes/functions.php';

if (isLoggedIn() && isAdmin()) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $contact = sanitize($_POST['contact']);
    $department = sanitize($_POST['department']);

    // Simple validation
    if (empty($name) || empty($username) || empty($email) || empty($password)) {
        $_SESSION['msg'] = "Please fill all required fields.";
        $_SESSION['msg_type'] = "error";
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        $_SESSION['msg'] = "User ID must be 3-20 characters long and contain only letters, numbers, and underscores.";
        $_SESSION['msg_type'] = "error";
    } else {
        // Check if username exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $_SESSION['msg'] = "User ID already taken.";
            $_SESSION['msg_type'] = "error";
        } else {
            // Check if email exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $_SESSION['msg'] = "Email already registered.";
                $_SESSION['msg_type'] = "error";
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $role = 'admin';
                $admin_type = 'department'; // Defaults to department admin
                
                $stmt = $pdo->prepare("INSERT INTO users (username, name, email, password, role, contact, department, admin_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                if ($stmt->execute([$username, $name, $email, $hashed_password, $role, $contact, $department, $admin_type])) {
                    $_SESSION['msg'] = "Admin registration successful! Please login.";
                    $_SESSION['msg_type'] = "success";
                    header("Location: login.php");
                    exit();
                } else {
                    $_SESSION['msg'] = "Admin registration failed. Try again.";
                    $_SESSION['msg_type'] = "error";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register - Online Grievance Cell</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-dark: #121318;
            --form-bg: #121318;
            --orange-accent: #f59e0b;
            --orange-hover: #d97706;
            --text-main: #ffffff;
            --text-muted: #6f7682;
            --input-border: #22252a;
        }

        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-dark);
            overflow: hidden;
        }

        /* Split layout container */
        .login-container {
            display: flex;
            height: 100vh;
            width: 100vw;
        }

        /* Left Column: Form */
        .form-side {
            flex: 1.1;
            background-color: var(--form-bg);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            padding: 2.5rem 5rem;
            position: relative;
            z-index: 2;
            overflow-y: auto;
        }

        /* Right Column: Illustration */
        .illustration-side {
            flex: 1;
            background-color: #d97706;
            background-image: radial-gradient(circle at 20% 30%, #f59e0b 0%, #b45309 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 4rem;
            position: relative;
            overflow: hidden;
        }

        /* Decorative wavy circles on the right side */
        .illustration-side::before {
            content: '';
            position: absolute;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.05);
            top: -150px;
            right: -100px;
        }
        .illustration-side::after {
            content: '';
            position: absolute;
            width: 350px;
            height: 350px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.03);
            bottom: -80px;
            left: -50px;
        }

        .illustration-content {
            z-index: 3;
            text-align: left;
            width: 85%;
            max-width: 550px;
        }

        .illustration-title {
            font-size: 3.5rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.15;
            margin-bottom: 0.5rem;
        }

        .illustration-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 1.1rem;
            font-weight: 300;
            margin-bottom: 2rem;
        }

        .illustration-image-container {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 1rem;
        }

        .illustration-image {
            max-width: 90%;
            height: auto;
            max-height: 48vh;
            filter: drop-shadow(0px 20px 40px rgba(0, 0, 0, 0.22));
        }

        /* Form styling */
        .form-content {
            width: 100%;
            max-width: 480px;
            margin: auto 0;
            padding-right: 1rem;
        }

        .form-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 0.5rem;
        }

        .form-subtitle {
            color: var(--text-muted);
            margin-bottom: 2.5rem;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-label {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-muted);
            margin-bottom: 0.4rem;
            display: block;
            font-weight: 600;
        }

        .form-input {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--input-border);
            color: var(--text-main);
            padding: 0.5rem 0;
            font-size: 0.95rem;
            outline: none;
            transition: border-color 0.3s ease;
        }

        .form-input:focus {
            border-color: var(--orange-accent);
        }

        .password-toggle {
            position: absolute;
            right: 0;
            bottom: 8px;
            color: var(--text-muted);
            cursor: pointer;
            transition: color 0.3s;
            background: none;
            border: none;
            padding: 0;
        }

        .password-toggle:hover {
            color: var(--orange-accent);
        }

        .btn-login {
            background-color: var(--orange-accent);
            color: #ffffff;
            border: none;
            border-radius: 2rem;
            padding: 0.85rem;
            font-weight: 600;
            font-size: 1rem;
            width: 100%;
            margin-top: 1.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.25);
        }

        .btn-login:hover {
            background-color: var(--orange-hover);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(245, 158, 11, 0.45);
        }

        .signup-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 2rem;
            margin-top: auto;
        }

        .signup-text {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin: 0;
        }

        .btn-signup {
            background-color: #1a1c22;
            color: var(--text-main);
            border: 1px solid var(--input-border);
            border-radius: 0.5rem;
            padding: 0.5rem 1.2rem;
            font-size: 0.85rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-signup:hover {
            background-color: var(--input-border);
            color: var(--orange-accent);
        }

        /* Mobile layout adaptations */
        @media (max-width: 991px) {
            .illustration-side {
                display: none;
            }
            .form-side {
                padding: 4rem 2rem;
            }
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="../assets/css/accessibility.css">
    <script src="../assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once '../includes/accessibility_bar.php'; ?>

<div class="login-container">
    <!-- Left Column: Admin Registration Form -->
    <div class="form-side">
        <div class="form-content">
            <h1 class="form-title">Register Admin</h1>
            <p class="form-subtitle">Create administrative account</p>
            
            <form action="register.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="name" class="form-input" placeholder="Enter full name" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Admin User ID (Username) *</label>
                    <input type="text" name="username" class="form-input" placeholder="Choose User ID" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label class="form-label">Admin Email Address *</label>
                    <input type="email" name="email" class="form-input" placeholder="yourname@nsti.com" required>
                </div>
                
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" id="password-input" class="form-input" placeholder="••••••••" required>
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i id="toggle-icon" class="fas fa-eye-slash"></i>
                        </button>
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="form-label">Department *</label>
                        <input type="text" name="department" class="form-input" placeholder="e.g. IT, Admin Office" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Contact No</label>
                    <input type="text" name="contact" class="form-input" placeholder="10-digit phone number">
                </div>
                
                <button type="submit" class="btn-login">Register Admin</button>
            </form>
        </div>
        
        <div class="signup-section">
            <p class="signup-text">Already have an admin account?</p>
            <a href="login.php" class="btn-signup">Login</a>
        </div>
    </div>
    
    <!-- Right Column: Banner & Vector Image -->
    <div class="illustration-side">
        <div class="illustration-content">
            <h1 class="illustration-title">Welcome to<br>admin portal</h1>
            <p class="illustration-subtitle">Register to create administrative account</p>
            <div class="illustration-image-container">
                <img src="../assets/images/admin_login_illustration.png" alt="Admin Portal Illustration" class="illustration-image">
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 and JS Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($_SESSION['msg'])): ?>
    <script>
        Swal.fire({
            icon: '<?php echo $_SESSION['msg_type']; ?>',
            title: '<?php echo $_SESSION['msg']; ?>',
            timer: 3000,
            showConfirmButton: false,
            background: '#1a1c22',
            color: '#fff'
        });
    </script>
    <?php 
    unset($_SESSION['msg']); 
    unset($_SESSION['msg_type']); 
    ?>
<?php endif; ?>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password-input');
    const toggleIcon = document.getElementById('toggle-icon');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    }
}
</script>

</body>
</html>
