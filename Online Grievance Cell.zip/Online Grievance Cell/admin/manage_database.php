<?php
include_once '../includes/functions.php';

if (!isAdmin() || ($_SESSION['admin_type'] ?? '') !== 'main') {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

$success = '';
$error = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'optimize') {
        try {
            $pdo->exec("OPTIMIZE TABLE users, categories, grievances, grievance_updates, notifications, feedbacks");
            $_SESSION['msg'] = "Database tables optimized successfully!";
            $_SESSION['msg_type'] = "success";
        } catch (PDOException $e) {
            $_SESSION['msg'] = "Optimization failed: " . $e->getMessage();
            $_SESSION['msg_type'] = "error";
        }
        header("Location: manage_database.php");
        exit();
    }

    if ($action === 'delete_row') {
        $table = isset($_POST['table']) ? sanitize($_POST['table']) : '';
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        
        $valid_tables = ['users', 'categories', 'grievances', 'grievance_updates', 'notifications', 'feedbacks'];
        if (in_array($table, $valid_tables) && $id > 0) {
            try {
                // Safety locks: Protect the active admin and the superadmin
                if ($table === 'users') {
                    if ($id == $_SESSION['user_id']) {
                        throw new Exception("You cannot delete your own active admin account.");
                    }
                    
                    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
                    $stmt->execute([$id]);
                    $user_email = $stmt->fetchColumn();
                    if ($user_email === 'admin@nsti.com') {
                        throw new Exception("The primary system administrator account cannot be deleted.");
                    }
                }
                
                $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
                $stmt->execute([$id]);
                
                $_SESSION['msg'] = "Record ID $id successfully deleted from '$table'.";
                $_SESSION['msg_type'] = "success";
            } catch (Exception $e) {
                $_SESSION['msg'] = "Deletion failed: " . $e->getMessage();
                $_SESSION['msg_type'] = "error";
            }
        } else {
            $_SESSION['msg'] = "Invalid action parameters.";
            $_SESSION['msg_type'] = "error";
        }
        header("Location: manage_database.php" . (isset($_GET['view_table']) ? "?view_table=" . $_GET['view_table'] : ""));
        exit();
    }
    
    if ($action === 'reset') {
        try {
            // Disable foreign keys temporarily
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            
            $pdo->exec("TRUNCATE TABLE grievance_updates");
            $pdo->exec("TRUNCATE TABLE notifications");
            $pdo->exec("TRUNCATE TABLE grievances");
            $pdo->exec("TRUNCATE TABLE users");
            $pdo->exec("TRUNCATE TABLE feedbacks");
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
            
            // Re-seed default admin
            $admin_name = 'NSTI ADMIN';
            $admin_email = 'admin@nsti.com';
            $admin_password_hash = password_hash('password', PASSWORD_DEFAULT);
            $admin_role = 'admin';
            $admin_type = 'main';
            $admin_profile_pic = 'admin_avatar.png';
            
            $stmt = $pdo->prepare("INSERT INTO users (username, name, email, password, role, admin_type, profile_pic) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(['admin', $admin_name, $admin_email, $admin_password_hash, $admin_role, $admin_type, $admin_profile_pic]);
            
            // Also seed the other admins so they don't get lost
            $admins = [
                ['dept_admin@nsti.com', 'Department Officer', 'department', 'dept_admin'],
                ['college_admin@nsti.com', 'College Principal', 'college', 'college_admin'],
                ['univ_admin@nsti.com', 'University Registrar', 'university', 'univ_admin']
            ];
            foreach ($admins as $adm) {
                $stmt->execute([$adm[3], $adm[1], $adm[0], $admin_password_hash, 'admin', $adm[2], $admin_profile_pic]);
            }
            
            $_SESSION['msg'] = "Database has been reset successfully!";
            $_SESSION['msg_type'] = "success";
            
        } catch (PDOException $e) {
            $_SESSION['msg'] = "Reset failed: " . $e->getMessage();
            $_SESSION['msg_type'] = "error";
        }
        header("Location: manage_database.php");
        exit();
    }
}

// Handle Backup download
if (isset($_GET['action']) && $_GET['action'] === 'backup') {
    $sql_file = '../database/grievance_db.sql';
    if (file_exists($sql_file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=grievance_database_backup_' . date('Ymd_His') . '.sql');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($sql_file));
        readfile($sql_file);
        exit();
    } else {
        $_SESSION['msg'] = "Backup file not found.";
        $_SESSION['msg_type'] = "error";
        header("Location: manage_database.php");
        exit();
    }
}

// Get database size and tables statistics
$tables = ['users', 'categories', 'grievances', 'grievance_updates', 'notifications', 'feedbacks'];
$db_stats = [];
$total_rows = 0;
$total_size_kb = 0;

foreach ($tables as $t) {
    // Row count
    $rows = $pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
    $total_rows += $rows;
    
    // Status info (Approx size)
    $status_stmt = $pdo->query("SHOW TABLE STATUS LIKE '$t'");
    $status = $status_stmt->fetch();
    $size_kb = round(($status['Data_length'] + $status['Index_length']) / 1024, 2);
    $total_size_kb += $size_kb;
    
    $db_stats[] = [
        'name' => $t,
        'rows' => $rows,
        'size' => $size_kb . ' KB',
        'engine' => $status['Engine'] ?? 'InnoDB'
    ];
}

include_once '../includes/header.php';
?>

<div class="fade-in">
    <div class="mb-4">
        <h2 class="fw-bold theme-text"><i class="fas fa-database me-2 text-warning"></i> Database Management</h2>
        <p class="theme-text-muted">Main Admin console to inspect table sizes, run optimizations, back up schema, or reset records.</p>
    </div>

    <div class="row">
        <!-- Database Table Stats -->
        <div class="col-lg-8 mb-4">
            <div class="glass-card theme-card p-0 h-100 overflow-hidden">
                <div class="p-4 border-bottom theme-border d-flex justify-content-between align-items-center">
                    <h4 class="mb-0 theme-text">Table Allocation & Statistics</h4>
                    <span class="badge bg-purple-gradient px-3 py-2"><?php echo count($tables); ?> Active Tables</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover theme-text mb-0 align-middle">
                        <thead>
                            <tr class="theme-text-muted theme-border">
                                <th class="ps-4">Table Name</th>
                                <th>Engine</th>
                                <th>Total Rows</th>
                                <th class="pe-4 text-end">Storage Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($db_stats as $stat): ?>
                                <tr class="theme-border">
                                    <td class="ps-4 fw-bold text-info"><i class="fas fa-table me-2 small opacity-75"></i><?php echo $stat['name']; ?></td>
                                    <td><?php echo $stat['engine']; ?></td>
                                    <td><?php echo $stat['rows']; ?></td>
                                    <td class="pe-4 text-end theme-text-muted"><?php echo $stat['size']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <!-- Totals Row -->
                            <tr class="border-top theme-border font-weight-bold">
                                <td class="ps-4 fw-bold">Total Summary</td>
                                <td>-</td>
                                <td class="fw-bold"><?php echo $total_rows; ?></td>
                                <td class="pe-4 text-end fw-bold text-success"><?php echo $total_size_kb; ?> KB</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Database Maintenance Actions -->
        <div class="col-lg-4 mb-4">
            <div class="glass-card theme-card h-100 d-flex flex-column justify-content-between">
                <div>
                    <h4 class="mb-4 pb-2 border-bottom theme-border theme-text">Operations</h4>
                    
                    <!-- Optimize tables -->
                    <div class="mb-4">
                        <h6 class="theme-text-muted text-uppercase small mb-2">Structure & Overhead</h6>
                        <p class="small theme-text-muted mb-2">Reorganizes table storage and indexes to recover unused space.</p>
                        <form action="manage_database.php" method="POST">
                            <input type="hidden" name="action" value="optimize">
                            <button type="submit" class="btn btn-outline-info btn-sm w-100"><i class="fas fa-sparkles me-2"></i>Optimize Tables</button>
                        </form>
                    </div>

                    <!-- Backup -->
                    <div class="mb-4">
                        <h6 class="theme-text-muted text-uppercase small mb-2">Backup & Recovery</h6>
                        <p class="small theme-text-muted mb-2">Downloads the SQL schema file containing definitions and defaults.</p>
                        <a href="manage_database.php?action=backup" class="btn btn-outline-secondary btn-sm w-100"><i class="fas fa-file-download me-2"></i>Download SQL Backup</a>
                    </div>
                </div>

                <!-- Database Reset -->
                <div class="border-top theme-border pt-4 mt-4">
                    <h6 class="text-danger text-uppercase small mb-2">Danger Zone</h6>
                    <p class="small theme-text-muted mb-3">Truncates all user profiles, complaints, notifications, and reset histories. (Restores default administrators).</p>
                    
                    <button type="button" class="btn btn-danger btn-sm w-100" onclick="confirmResetDatabase()"><i class="fas fa-trash-alt me-2"></i>Reset Database</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Table Data Explorer & Row Deletion -->
    <div class="glass-card theme-card mt-4 p-4">
        <h4 class="mb-3 theme-text"><i class="fas fa-search me-2 text-info"></i> Browse & Clean Data Records</h4>
        <p class="theme-text-muted small">Select a table to browse records and delete specific entries individually.</p>
        
        <?php
        $view_table = isset($_GET['view_table']) ? sanitize($_GET['view_table']) : '';
        $valid_tables = ['users', 'grievances', 'grievance_updates', 'notifications', 'feedbacks'];
        ?>
        
        <div class="mb-4" style="max-width: 320px;">
            <label class="form-label theme-text-muted small">Choose Table</label>
            <select class="form-select theme-input" id="tableSelector" onchange="switchTable(this.value)">
                <option value="" <?php echo empty($view_table) ? 'selected' : ''; ?>>-- Select Table --</option>
                <option value="users" <?php echo $view_table === 'users' ? 'selected' : ''; ?>>Users (Accounts)</option>
                <option value="grievances" <?php echo $view_table === 'grievances' ? 'selected' : ''; ?>>Grievances (Complaints)</option>
                <option value="grievance_updates" <?php echo $view_table === 'grievance_updates' ? 'selected' : ''; ?>>Grievance Updates (Remarks)</option>
                <option value="notifications" <?php echo $view_table === 'notifications' ? 'selected' : ''; ?>>Notifications</option>
                <option value="feedbacks" <?php echo $view_table === 'feedbacks' ? 'selected' : ''; ?>>Feedbacks (Submissions)</option>
            </select>
        </div>
        
        <?php if (in_array($view_table, $valid_tables)): ?>
            <?php
            // Fetch records for the selected table (limit to 100 to prevent page bloat)
            $stmt = $pdo->query("SELECT * FROM $view_table ORDER BY id DESC LIMIT 100");
            $records = $stmt->fetchAll();
            ?>
            
            <h5 class="mb-3 text-info text-capitalize">Table Records: <?php echo $view_table; ?> <span class="badge bg-secondary font-weight-normal"><?php echo count($records); ?> Shown</span></h5>
            
            <div class="table-responsive">
                <table class="table table-hover theme-text align-middle">
                    <thead class="theme-text-muted">
                        <?php if ($view_table === 'users'): ?>
                            <tr class="theme-border theme-text-muted">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Contact</th>
                                <th>Joined At</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        <?php elseif ($view_table === 'grievances'): ?>
                            <tr class="theme-border theme-text-muted">
                                <th>ID</th>
                                <th>Ref ID</th>
                                <th>Title</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Lodged At</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        <?php elseif ($view_table === 'grievance_updates'): ?>
                            <tr class="theme-border theme-text-muted">
                                <th>ID</th>
                                <th>Grievance ID</th>
                                <th>Updated By</th>
                                <th>Status</th>
                                <th>Message</th>
                                <th>Date</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        <?php elseif ($view_table === 'notifications'): ?>
                            <tr class="theme-border theme-text-muted">
                                <th>ID</th>
                                <th>User ID</th>
                                <th>Message</th>
                                <th>Read Status</th>
                                <th>Created At</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        <?php elseif ($view_table === 'feedbacks'): ?>
                            <tr class="theme-border theme-text-muted">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Rating</th>
                                <th>Message</th>
                                <th>Date</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        <?php endif; ?>
                    </thead>
                    <tbody>
                        <?php if (empty($records)): ?>
                            <tr><td colspan="7" class="text-center py-4 theme-text-muted">No records found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($records as $row): ?>
                                <tr class="theme-border">
                                    <?php if ($view_table === 'users'): ?>
                                        <td><?php echo $row['id']; ?></td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['role']); ?></span></td>
                                        <td><?php echo htmlspecialchars($row['contact'] ?? 'N/A'); ?></td>
                                        <td class="small theme-text-muted"><?php echo $row['created_at']; ?></td>
                                    <?php elseif ($view_table === 'grievances'): ?>
                                        <td><?php echo $row['id']; ?></td>
                                        <td class="fw-bold text-warning"><?php echo htmlspecialchars($row['complaint_id']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($row['title'], 0, 40)) . (strlen($row['title']) > 40 ? '...' : ''); ?></td>
                                        <td><span class="badge bg-primary"><?php echo htmlspecialchars($row['priority']); ?></span></td>
                                        <td><span class="badge <?php 
                                            if ($row['status'] === 'Pending') echo 'bg-warning text-dark';
                                            elseif ($row['status'] === 'In Progress') echo 'bg-info';
                                            elseif ($row['status'] === 'Resolved') echo 'bg-success';
                                            elseif ($row['status'] === 'Rejected') echo 'bg-danger';
                                        ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                        <td class="small theme-text-muted"><?php echo $row['created_at']; ?></td>
                                    <?php elseif ($view_table === 'grievance_updates'): ?>
                                        <td><?php echo $row['id']; ?></td>
                                        <td>#<?php echo $row['grievance_id']; ?></td>
                                        <td>User ID #<?php echo $row['updated_by']; ?></td>
                                        <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['status'] ?? 'N/A'); ?></span></td>
                                        <td><?php echo htmlspecialchars(substr($row['message'], 0, 50)) . (strlen($row['message']) > 50 ? '...' : ''); ?></td>
                                        <td class="small theme-text-muted"><?php echo $row['created_at']; ?></td>
                                    <?php elseif ($view_table === 'notifications'): ?>
                                        <td><?php echo $row['id']; ?></td>
                                        <td>User ID #<?php echo $row['user_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['message']); ?></td>
                                        <td><?php echo $row['is_read'] ? '<span class="text-success">Read</span>' : '<span class="text-warning">Unread</span>'; ?></td>
                                        <td class="small theme-text-muted"><?php echo $row['created_at']; ?></td>
                                    <?php elseif ($view_table === 'feedbacks'): ?>
                                        <td><?php echo $row['id']; ?></td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td class="text-warning">
                                            <?php for ($i = 0; $i < 5; $i++) {
                                                echo $i < $row['rating'] ? '★' : '☆';
                                            } ?>
                                        </td>
                                        <td><?php echo htmlspecialchars(substr($row['message'], 0, 50)) . (strlen($row['message']) > 50 ? '...' : ''); ?></td>
                                        <td class="small theme-text-muted"><?php echo $row['created_at']; ?></td>
                                    <?php endif; ?>
                                    
                                    <!-- Delete actions -->
                                    <td class="text-end pe-4">
                                        <?php 
                                        $disable_delete = false;
                                        if ($view_table === 'users') {
                                            if ($row['id'] == $_SESSION['user_id'] || $row['email'] === 'admin@nsti.com') {
                                                $disable_delete = true;
                                            }
                                        }
                                        ?>
                                        <?php if ($disable_delete): ?>
                                            <button class="btn btn-secondary btn-sm opacity-50" disabled title="Protected Admin Account"><i class="fas fa-lock text-white"></i></button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-danger btn-sm" onclick="confirmDeleteRow('<?php echo $view_table; ?>', <?php echo $row['id']; ?>)" title="Delete Record"><i class="fas fa-trash-alt"></i></button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function switchTable(table) {
    if (table) {
        window.location.href = 'manage_database.php?view_table=' + table;
    } else {
        window.location.href = 'manage_database.php';
    }
}

function confirmDeleteRow(table, id) {
    Swal.fire({
        title: 'Delete this record?',
        text: "This will permanently remove ID " + id + " from table '" + table + "'!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Yes, delete it!',
        background: '#1a1c22',
        color: '#fff'
    }).then((result) => {
        if (result.isConfirmed) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'manage_database.php' + window.location.search;
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete_row';
            
            const tableInput = document.createElement('input');
            tableInput.type = 'hidden';
            tableInput.name = 'table';
            tableInput.value = table;
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = id;
            
            form.appendChild(actionInput);
            form.appendChild(tableInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    });
}

function confirmResetDatabase() {
    Swal.fire({
        title: 'Reset Database?',
        text: "This will delete all student records, complaints, files, and updates! Admins will be reset to default passwords.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Yes, delete everything!',
        background: '#1a1c22',
        color: '#fff'
    }).then((result) => {
        if (result.isConfirmed) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'manage_database.php';
            
            const hiddenField = document.createElement('input');
            hiddenField.type = 'hidden';
            hiddenField.name = 'action';
            hiddenField.value = 'reset';
            
            form.appendChild(hiddenField);
            document.body.appendChild(form);
            form.submit();
        }
    });
}
</script>

<?php include_once '../includes/footer.php'; ?>
