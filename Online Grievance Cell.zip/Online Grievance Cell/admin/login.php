<?php
include_once '../includes/functions.php';

if (isLoggedIn() && isAdmin()) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR username = ?) AND role = 'admin'");
    $stmt->execute([$email, $email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['admin_type'] = $user['admin_type'];

        $_SESSION['msg'] = "Welcome back, Administrator " . $user['name'] . "!";
        $_SESSION['msg_type'] = "success";
        
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['msg'] = "Invalid admin credentials.";
        $_SESSION['msg_type'] = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Online Grievance Cell</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-dark: #121318;
            --form-bg: #121318;
            --orange-accent: #f59e0b;
            --orange-hover: #d97706;
            --text-main: #ffffff;
            --text-muted: #6f7682;
            --input-border: #22252a;
        }

        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-dark);
            overflow: hidden;
        }

        /* Split layout container */
        .login-container {
            display: flex;
            height: 100vh;
            width: 100vw;
        }

        /* Left Column: Form */
        .form-side {
            flex: 1;
            background-color: var(--form-bg);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            padding: 2.5rem 5rem;
            position: relative;
            z-index: 2;
            overflow-y: auto;
        }

        /* Right Column: Illustration */
        .illustration-side {
            flex: 1.1;
            background-color: #d97706;
            background-image: radial-gradient(circle at 20% 30%, #f59e0b 0%, #b45309 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 4rem;
            position: relative;
            overflow: hidden;
        }

        /* Decorative wavy circles on the right side */
        .illustration-side::before {
            content: '';
            position: absolute;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.05);
            top: -150px;
            right: -100px;
        }
        .illustration-side::after {
            content: '';
            position: absolute;
            width: 350px;
            height: 350px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.03);
            bottom: -80px;
            left: -50px;
        }

        .illustration-content {
            z-index: 3;
            text-align: left;
            width: 85%;
            max-width: 550px;
        }

        .illustration-title {
            font-size: 3.5rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.15;
            margin-bottom: 0.5rem;
        }

        .illustration-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 1.1rem;
            font-weight: 300;
            margin-bottom: 2rem;
        }

        .illustration-image-container {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 1rem;
        }

        .illustration-image {
            max-width: 90%;
            height: auto;
            max-height: 48vh;
            filter: drop-shadow(0px 20px 40px rgba(0, 0, 0, 0.22));
        }

        /* Form styling */
        .form-content {
            width: 100%;
            max-width: 380px;
            margin: auto 0;
        }

        .form-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 0.5rem;
        }

        .form-subtitle {
            color: var(--text-muted);
            margin-bottom: 3.5rem;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 2rem;
            position: relative;
        }

        .form-label {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-muted);
            margin-bottom: 0.4rem;
            display: block;
            font-weight: 600;
        }

        .form-input {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--input-border);
            color: var(--text-main);
            padding: 0.5rem 0;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.3s ease;
        }

        .form-input:focus {
            border-color: var(--orange-accent);
        }

        .password-toggle {
            position: absolute;
            right: 0;
            bottom: 8px;
            color: var(--text-muted);
            cursor: pointer;
            transition: color 0.3s;
            background: none;
            border: none;
            padding: 0;
        }

        .password-toggle:hover {
            color: var(--orange-accent);
        }

        .forgot-link {
            display: inline-block;
            color: var(--text-muted);
            font-size: 0.85rem;
            text-decoration: none;
            margin-top: 0.8rem;
            transition: color 0.3s;
        }

        .forgot-link:hover {
            color: var(--orange-accent);
        }

        .btn-login {
            background-color: var(--orange-accent);
            color: #ffffff;
            border: none;
            border-radius: 2rem;
            padding: 0.85rem;
            font-weight: 600;
            font-size: 1rem;
            width: 100%;
            margin-top: 2rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.25);
        }

        .btn-login:hover {
            background-color: var(--orange-hover);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(245, 158, 11, 0.45);
        }

        .signup-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 2rem;
            margin-top: auto;
        }

        .signup-text {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin: 0;
        }

        .btn-signup {
            background-color: #1a1c22;
            color: var(--text-main);
            border: 1px solid var(--input-border);
            border-radius: 0.5rem;
            padding: 0.5rem 1.2rem;
            font-size: 0.85rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-signup:hover {
            background-color: var(--input-border);
            color: var(--orange-accent);
        }

        /* Mobile layout adaptations */
        @media (max-width: 991px) {
            .illustration-side {
                display: none;
            }
            .form-side {
                padding: 4rem 2rem;
            }
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="../assets/css/accessibility.css">
    <script src="../assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once '../includes/accessibility_bar.php'; ?>

<div class="login-container">
    <!-- Left Column: Login Form -->
    <div class="form-side">
        <div class="form-content">
            <h1 class="form-title">Admin Login</h1>
            <p class="form-subtitle">Enter admin portal credentials</p>
            
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Admin User ID / Email Address</label>
                    <input type="text" name="email" class="form-input" placeholder="Enter User ID or Email" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" id="password-input" class="form-input" placeholder="Enter your password" required>
                    <button type="button" class="password-toggle" onclick="togglePassword()">
                        <i id="toggle-icon" class="fas fa-eye-slash"></i>
                    </button>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mt-2">
                    <a href="../forgot_password.php" class="forgot-link">Forgot Password?</a>
                    <a href="../login.php" class="forgot-link text-info fw-bold text-decoration-none"><i class="fas fa-user-graduate me-1"></i>Student/Staff Login</a>
                </div>
                
                <button type="submit" class="btn-login">Login</button>
            </form>
        </div>
        
        <div class="signup-section">
            <p class="signup-text">Don't have an admin account?</p>
            <a href="register.php" class="btn-signup">Register Admin</a>
        </div>
    </div>
    
    <!-- Right Column: Banner & Vector Image -->
    <div class="illustration-side">
        <div class="illustration-content">
            <h1 class="illustration-title">Welcome to<br>admin portal</h1>
            <p class="illustration-subtitle">Access Command Center & Control Panel</p>
            <div class="illustration-image-container">
                <img src="../assets/images/admin_login_illustration.png" alt="Admin Portal Illustration" class="illustration-image">
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 and JS Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($_SESSION['msg'])): ?>
    <script>
        Swal.fire({
            icon: '<?php echo $_SESSION['msg_type']; ?>',
            title: '<?php echo $_SESSION['msg']; ?>',
            timer: 3000,
            showConfirmButton: false,
            background: '#1a1c22',
            color: '#fff'
        });
    </script>
    <?php 
    unset($_SESSION['msg']); 
    unset($_SESSION['msg_type']); 
    ?>
<?php endif; ?>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password-input');
    const toggleIcon = document.getElementById('toggle-icon');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    }
}
</script>

</body>
</html>
