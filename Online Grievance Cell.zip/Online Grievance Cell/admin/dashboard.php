<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

// Admin type
$admin_type = $_SESSION['admin_type'] ?? 'main';

// Formulate level restriction SQL based on admin tier
$level_cond = "1=1";
if ($admin_type === 'department') {
    $level_cond = "DATEDIFF(NOW(), created_at) < 7";
} elseif ($admin_type === 'college') {
    $level_cond = "DATEDIFF(NOW(), created_at) >= 7 AND DATEDIFF(NOW(), created_at) < 14";
} elseif ($admin_type === 'university') {
    $level_cond = "DATEDIFF(NOW(), created_at) >= 14";
}

// Stats
$total_users = $pdo->query("SELECT COUNT(*) FROM users WHERE role != 'admin'")->fetchColumn();
$total_complaints = $pdo->query("SELECT COUNT(*) FROM grievances WHERE $level_cond")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM grievances WHERE status = 'Pending' AND $level_cond")->fetchColumn();
$resolved = $pdo->query("SELECT COUNT(*) FROM grievances WHERE status = 'Resolved' AND $level_cond")->fetchColumn();
$rejected = $pdo->query("SELECT COUNT(*) FROM grievances WHERE status = 'Rejected' AND $level_cond")->fetchColumn();

// Data for Chart.js (Status Distribution)
$stmt = $pdo->query("SELECT status, COUNT(*) as count FROM grievances WHERE $level_cond GROUP BY status");
$chart_data = $stmt->fetchAll();
$db_counts = [];
foreach ($chart_data as $row) {
    $db_counts[$row['status']] = (int)$row['count'];
}

$status_mapping = [
    'Pending' => ['label' => 'Not Processed', 'color' => '#f59e0b'],
    'In Progress' => ['label' => 'Under Process', 'color' => '#3b82f6'],
    'Resolved' => ['label' => 'Resolved Complaint', 'color' => '#10b981'],
    'Rejected' => ['label' => 'Rejected Complaint', 'color' => '#ef4444']
];

$labels = [];
$counts = [];
$colors = [];

foreach ($status_mapping as $status_key => $info) {
    $count = $db_counts[$status_key] ?? 0;
    if ($count > 0) {
        $labels[] = $info['label'];
        $counts[] = $count;
        $colors[] = $info['color'];
    }
}

// Adjust condition for joins with table prefix 'g.'
$join_level_cond = str_replace('created_at', 'g.created_at', $level_cond);

// Recent Complaints
$recent = $pdo->query("SELECT g.*, u.name as user_name, c.name as category 
                      FROM grievances g 
                      JOIN users u ON g.user_id = u.id 
                      JOIN categories c ON g.category_id = c.id 
                      WHERE $join_level_cond
                      ORDER BY g.created_at DESC LIMIT 5")->fetchAll();

include_once '../includes/header.php';
?>

<div class="row fade-in">
    <div class="col-12 mb-4">
        <h2 class="fw-bold text-gradient" style="font-size: 2.2rem; letter-spacing: -1px;"><i class="fas fa-chart-line me-2" style="color: #818cf8;"></i>Admin Dashboard</h2>
        <div class="d-flex align-items-center mt-1">
            <span class="theme-text-muted" style="font-size: 1.05rem;">Welcome back, <span class="fw-bold theme-text"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?></span>! Overview of system health and resolution progress.</span>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-5">
        <div class="col mb-4" style="animation: float 6s ease-in-out infinite;">
            <div class="glass-card theme-card stat-card border-info h-100" onclick="window.location.href='manage_users.php'" style="cursor: pointer;">
                <i class="fas fa-users position-absolute stat-bg-icon text-info" style="right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.05; transform: rotate(-15deg); transition: all 0.3s ease;"></i>
                <div class="position-relative z-1">
                    <h6 class="mb-2 theme-text-muted">Total Users</h6>
                    <h2 class="mb-1 theme-text"><?php echo $total_users; ?></h2>
                    <div class="mt-2">
                        <a href="manage_users.php" onclick="event.stopPropagation();" class="btn btn-sm text-white px-3 py-1 fw-bold d-inline-flex align-items-center" style="background-color: #06b6d4; border-radius: 6px; font-size: 0.75rem; letter-spacing: 0.5px; box-shadow: 0 3px 10px rgba(6, 182, 212, 0.3); border: none;"><i class="fas fa-eye me-1.5"></i> View</a>
                    </div>
                </div>
                <div class="stat-icon-wrapper bg-info-subtle position-relative z-1">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>
        <div class="col mb-4" style="animation: float 6s ease-in-out infinite; animation-delay: 0.2s;">
            <div class="glass-card theme-card stat-card border-primary h-100" onclick="window.location.href='manage_grievances.php'" style="cursor: pointer;">
                <i class="fas fa-file-invoice position-absolute stat-bg-icon text-primary" style="right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.05; transform: rotate(-15deg); transition: all 0.3s ease;"></i>
                <div class="position-relative z-1">
                    <h6 class="mb-2 theme-text-muted">Total Complaints</h6>
                    <h2 class="mb-1 theme-text"><?php echo $total_complaints; ?></h2>
                    <div class="mt-2">
                        <a href="manage_grievances.php" onclick="event.stopPropagation();" class="btn btn-sm text-white px-3 py-1 fw-bold d-inline-flex align-items-center" style="background-color: #3b82f6; border-radius: 6px; font-size: 0.75rem; letter-spacing: 0.5px; box-shadow: 0 3px 10px rgba(59, 130, 246, 0.3); border: none;"><i class="fas fa-eye me-1.5"></i> View</a>
                    </div>
                </div>
                <div class="stat-icon-wrapper bg-primary-subtle position-relative z-1">
                    <i class="fas fa-file-invoice"></i>
                </div>
            </div>
        </div>
        <div class="col mb-4" style="animation: float 6s ease-in-out infinite; animation-delay: 0.4s;">
            <div class="glass-card theme-card stat-card border-warning h-100" onclick="window.location.href='manage_grievances.php?status=Pending'" style="cursor: pointer;">
                <i class="fas fa-clock position-absolute stat-bg-icon text-warning" style="right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.05; transform: rotate(-15deg); transition: all 0.3s ease;"></i>
                <div class="position-relative z-1">
                    <h6 class="mb-2 theme-text-muted">Pending</h6>
                    <h2 class="mb-1 theme-text"><?php echo $pending; ?></h2>
                    <div class="mt-2">
                        <a href="manage_grievances.php?status=Pending" onclick="event.stopPropagation();" class="btn btn-sm text-white px-3 py-1 fw-bold d-inline-flex align-items-center" style="background-color: #f59e0b; border-radius: 6px; font-size: 0.75rem; letter-spacing: 0.5px; box-shadow: 0 3px 10px rgba(245, 158, 11, 0.3); border: none;"><i class="fas fa-eye me-1.5"></i> View</a>
                    </div>
                </div>
                <div class="stat-icon-wrapper bg-warning-subtle position-relative z-1">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>
        <div class="col mb-4" style="animation: float 6s ease-in-out infinite; animation-delay: 0.6s;">
            <div class="glass-card theme-card stat-card border-success h-100" onclick="window.location.href='manage_grievances.php?status=Resolved'" style="cursor: pointer;">
                <i class="fas fa-check-circle position-absolute stat-bg-icon text-success" style="right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.05; transform: rotate(-15deg); transition: all 0.3s ease;"></i>
                <div class="position-relative z-1">
                    <h6 class="mb-2 theme-text-muted">Resolved</h6>
                    <h2 class="mb-1 theme-text"><?php echo $resolved; ?></h2>
                    <div class="mt-2">
                        <a href="manage_grievances.php?status=Resolved" onclick="event.stopPropagation();" class="btn btn-sm text-white px-3 py-1 fw-bold d-inline-flex align-items-center" style="background-color: #10b981; border-radius: 6px; font-size: 0.75rem; letter-spacing: 0.5px; box-shadow: 0 3px 10px rgba(16, 185, 129, 0.3); border: none;"><i class="fas fa-eye me-1.5"></i> View</a>
                    </div>
                </div>
                <div class="stat-icon-wrapper bg-success-subtle position-relative z-1">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
        <div class="col mb-4" style="animation: float 6s ease-in-out infinite; animation-delay: 0.8s;">
            <div class="glass-card theme-card stat-card border-danger h-100" onclick="window.location.href='manage_grievances.php?status=Rejected'" style="cursor: pointer;">
                <i class="fas fa-times-circle position-absolute stat-bg-icon text-danger" style="right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.05; transform: rotate(-15deg); transition: all 0.3s ease;"></i>
                <div class="position-relative z-1">
                    <h6 class="mb-2 theme-text-muted">Rejected</h6>
                    <h2 class="mb-1 theme-text"><?php echo $rejected; ?></h2>
                    <div class="mt-2">
                        <a href="manage_grievances.php?status=Rejected" onclick="event.stopPropagation();" class="btn btn-sm text-white px-3 py-1 fw-bold d-inline-flex align-items-center" style="background-color: #ef4444; border-radius: 6px; font-size: 0.75rem; letter-spacing: 0.5px; box-shadow: 0 3px 10px rgba(239, 68, 68, 0.3); border: none;"><i class="fas fa-eye me-1.5"></i> View</a>
                    </div>
                </div>
                <div class="stat-icon-wrapper bg-danger-subtle position-relative z-1">
                    <i class="fas fa-times-circle"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .stat-card:hover .stat-bg-icon {
        transform: rotate(0deg) scale(1.1) !important;
        opacity: 0.1 !important;
    }
</style>

<div class="row mt-4">
    <!-- Chart -->
    <div class="col-lg-5 mb-4">
        <div class="glass-card theme-card h-100 p-4">
            <h4 class="mb-4 fw-bold theme-text">Complaint Status</h4>
            <div style="position: relative; height: 280px; display: flex; justify-content: center; align-items: center;">
                <canvas id="statusChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Recent Table -->
    <div class="col-lg-7 mb-4">
        <div class="glass-card theme-card h-100 p-0 overflow-hidden">
            <div class="d-flex justify-content-between align-items-center p-4 border-bottom" style="border-color: rgba(255,255,255,0.05) !important;">
                <h4 class="mb-0 fw-bold theme-text">Latest Submissions</h4>
                <a href="manage_grievances.php" class="btn btn-sm btn-premium px-4 py-2 fw-bold">Manage All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 border-0">
                    <thead>
                        <tr>
                            <th class="ps-4 text-uppercase theme-text-muted border-0" style="width: 20%; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1rem;">USER</th>
                            <th class="text-uppercase theme-text-muted border-0" style="width: auto; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1rem;">TITLE</th>
                            <th class="text-uppercase theme-text-muted border-0" style="width: 35%; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1rem;">STATUS</th>
                            <th class="pe-4 text-end text-uppercase theme-text-muted border-0" style="width: 15%; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1rem;">DATE</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach ($recent as $r): ?>
                        <tr style="transition: all 0.2s ease;">
                            <td class="ps-4 py-3 fw-bold border-bottom text-truncate theme-text" style="font-size: 0.95rem;"><?php echo htmlspecialchars($r['user_name']); ?></td>
                            <td class="py-3 text-truncate border-bottom theme-text" style="font-size: 0.95rem;"><?php echo htmlspecialchars($r['title']); ?></td>
                            <td class="py-3 border-bottom">
                                <?php 
                                    $sColor = 'rgba(255,255,255,0.1)'; $sText = '#94a3b8'; $sIcon = 'fa-circle';
                                    if(strtolower($r['status']) === 'pending' || strtolower($r['status']) === 'not processed') { $sColor = 'rgba(245, 158, 11, 0.15)'; $sText = '#fbbf24'; $sIcon = 'fa-clock'; }
                                    if(strtolower($r['status']) === 'in progress' || strtolower($r['status']) === 'under process') { $sColor = 'rgba(99, 102, 241, 0.15)'; $sText = '#818cf8'; $sIcon = 'fa-spinner fa-spin'; }
                                    if(strtolower($r['status']) === 'resolved' || strtolower($r['status']) === 'resolved complaint') { $sColor = 'rgba(16, 185, 129, 0.15)'; $sText = '#34d399'; $sIcon = 'fa-check-circle'; }
                                    if(strtolower($r['status']) === 'rejected' || strtolower($r['status']) === 'rejected complaint') { $sColor = 'rgba(239, 68, 68, 0.15)'; $sText = '#f87171'; $sIcon = 'fa-times-circle'; }
                                ?>
                                <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo $sColor; ?>; color: <?php echo $sText; ?>; font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; border: 1px solid <?php echo $sColor; ?>;">
                                    <i class="fas <?php echo $sIcon; ?> me-1"></i> <?php echo getStatusLabel($r['status']); ?>
                                </span>
                            </td>
                            <td class="pe-4 py-3 text-end fw-medium border-bottom theme-text" style="font-size: 0.95rem;"><?php echo date('d/m', strtotime($r['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('statusChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                data: <?php echo json_encode($counts); ?>,
                backgroundColor: <?php echo json_encode($colors); ?>,
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: { padding: 10 },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#94a3b8', font: { family: 'Outfit', size: 12, weight: '500' }, padding: 20, usePointStyle: true, pointStyle: 'rect' }
                },
                tooltip: { backgroundColor: '#1e293b', padding: 12, cornerRadius: 8, titleFont: { size: 14 }, bodyFont: { size: 13 } }
            },
            cutout: '65%'
        }
    });
});
</script>

<?php include_once '../includes/footer.php'; ?>
