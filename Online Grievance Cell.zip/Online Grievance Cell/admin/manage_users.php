<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

// Ensure is_disabled column exists
try {
    $pdo->exec("ALTER TABLE users ADD COLUMN is_disabled TINYINT(1) DEFAULT 0");
} catch (PDOException $e) {
    // Column already exists
}

// Handle Delete User
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'admin'");
    if ($stmt->execute([$del_id])) {
        $_SESSION['msg'] = 'User removed successfully.';
        $_SESSION['msg_type'] = 'success';
    }
    header("Location: manage_users.php");
    exit();
}

// Handle Disable/Active User
if (isset($_GET['toggle_disable_id'])) {
    $tog_id = (int)$_GET['toggle_disable_id'];
    $stmt = $pdo->prepare("UPDATE users SET is_disabled = NOT is_disabled WHERE id = ? AND role != 'admin'");
    if ($stmt->execute([$tog_id])) {
        $_SESSION['msg'] = 'User status updated successfully.';
        $_SESSION['msg_type'] = 'success';
    }
    header("Location: manage_users.php");
    exit();
}

// Fetch all users
$stmt = $pdo->query("SELECT id, name, email, role, contact, department, created_at, is_disabled FROM users WHERE role != 'admin' ORDER BY created_at DESC");
$users = $stmt->fetchAll();

include_once '../includes/header.php';
?>

<div class="fade-in">
    <style>
        .action-buttons {
            display: flex;
            gap: 6px;
            justify-content: flex-end;
        }
        .btn-action {
            display: inline-block;
            padding: 6px 16px;
            color: #ffffff !important;
            font-size: 0.85rem;
            font-weight: 600;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.25s;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .btn-remove { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .btn-disable { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .btn-active { background: linear-gradient(135deg, #94a3b8, #64748b); }
    </style>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-5 mt-2">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold mb-1 theme-text" style="font-weight: 800; letter-spacing: -0.5px;"><i class="fas fa-users-cog me-2 text-primary opacity-75"></i>Manage Users</h2>
            <p class="theme-text-muted mb-0" style="font-size: 1.05rem;">View, remove, or disable registered users in the system.</p>
        </div>
    </div>

    <div class="glass-card theme-card p-0 overflow-hidden shadow-sm" style="border-radius: 16px; border: 1px solid var(--border-color, #f1f5f9);">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 border-0">
                <thead style="border-bottom: 2px solid var(--border-color, #e2e8f0);">
                    <tr>
                        <th class="ps-4 text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">User</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Email</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Role</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Department</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Contact</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Joined On</th>
                        <th class="pe-4 text-end text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (empty($users)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted"><i class="fas fa-inbox fa-3x mb-3 text-light"></i><br>No users registered yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                        <tr style="transition: all 0.2s ease; <?php echo !empty($u['is_disabled']) ? 'opacity: 0.6;' : ''; ?>">
                            <td class="ps-4 py-3 border-bottom theme-border">
                                <div class="d-flex align-items-center">
                                    <div class="rounded-circle d-flex justify-content-center align-items-center text-white fw-bold me-3 shadow-sm" style="width: 42px; height: 42px; background: linear-gradient(135deg, #3b82f6, #06b6d4); flex-shrink: 0; font-size: 1.1rem;">
                                        <?php echo strtoupper(substr($u['name'], 0, 1)); ?>
                                    </div>
                                    <div class="fw-bold theme-text mb-0" style="font-size: 0.95rem;"><?php echo htmlspecialchars($u['name']); ?></div>
                                </div>
                            </td>
                            <td class="py-3 border-bottom theme-text-muted theme-border" style="font-size: 0.9rem;">
                                <?php echo htmlspecialchars($u['email']); ?>
                            </td>
                            <td class="py-3 border-bottom theme-border">
                                <?php 
                                    $roleColor = 'bg-secondary';
                                    if($u['role'] === 'student') $roleColor = 'bg-info';
                                    if($u['role'] === 'staff') $roleColor = 'bg-primary';
                                    if($u['role'] === 'admin') $roleColor = 'bg-danger';
                                ?>
                                <span class="badge <?php echo $roleColor; ?> rounded-pill px-3 py-2 shadow-sm" style="font-size: 0.7rem; letter-spacing: 0.5px; font-weight: 700; text-transform: uppercase;">
                                    <?php echo ucfirst($u['role']); ?>
                                </span>
                            </td>
                            <td class="py-3 border-bottom theme-text-muted theme-border" style="font-size: 0.9rem;">
                                <?php echo htmlspecialchars($u['department']) ?: '<span class="opacity-50">N/A</span>'; ?>
                            </td>
                            <td class="py-3 border-bottom theme-text-muted theme-border" style="font-size: 0.9rem;">
                                <?php echo htmlspecialchars($u['contact']) ?: '<span class="opacity-50">N/A</span>'; ?>
                            </td>
                            <td class="py-3 border-bottom theme-text-muted theme-border" style="font-size: 0.9rem;">
                                <div class="fw-medium theme-text"><?php echo date('d M Y', strtotime($u['created_at'])); ?></div>
                            </td>
                            <td class="pe-4 py-3 border-bottom theme-border">
                                <div class="action-buttons">
                                    <a href="manage_users.php?delete_id=<?php echo $u['id']; ?>" class="btn-action btn-remove" style="padding: 0.4rem 1rem; border-radius: 8px;" onclick="return confirm('Are you sure you want to permanently remove this user? This action cannot be undone.');"><i class="fas fa-trash-alt me-1"></i> Remove</a>
                                    <?php if (!empty($u['is_disabled'])): ?>
                                        <a href="manage_users.php?toggle_disable_id=<?php echo $u['id']; ?>" class="btn-action btn-active" style="padding: 0.4rem 1rem; border-radius: 8px;" onclick="return confirm('Re-activate this user account?');"><i class="fas fa-check-circle me-1"></i> Active</a>
                                    <?php else: ?>
                                        <a href="manage_users.php?toggle_disable_id=<?php echo $u['id']; ?>" class="btn-action btn-disable" style="padding: 0.4rem 1rem; border-radius: 8px;" onclick="return confirm('Disable this user account? They will not be able to log in.');"><i class="fas fa-ban me-1"></i> Disable</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
