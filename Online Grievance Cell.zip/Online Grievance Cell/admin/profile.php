<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Handle Avatar Upload Form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_pic'])) {
    if ($_FILES['profile_pic']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['profile_pic']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'admin_' . $user_id . '_' . time() . '.' . $ext;
            $upload_path = '../uploads/' . $new_filename;
            
            // Create uploads directory if not exists
            if (!file_exists('../uploads')) {
                mkdir('../uploads', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $upload_path)) {
                // Update DB
                $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
                if ($stmt->execute([$new_filename, $user_id])) {
                    $_SESSION['msg'] = "Profile picture updated successfully!";
                    $_SESSION['msg_type'] = "success";
                } else {
                    $_SESSION['msg'] = "Failed to update profile picture in database.";
                    $_SESSION['msg_type'] = "error";
                }
            } else {
                $_SESSION['msg'] = "Failed to move uploaded file.";
                $_SESSION['msg_type'] = "error";
            }
        } else {
            $_SESSION['msg'] = "Invalid file type. Only JPG, JPEG, and PNG are allowed.";
            $_SESSION['msg_type'] = "error";
        }
    } else {
        $_SESSION['msg'] = "File upload error code: " . $_FILES['profile_pic']['error'];
        $_SESSION['msg_type'] = "error";
    }
    header("Location: profile.php");
    exit();
}

// Handle Details Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_details'])) {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $contact = sanitize($_POST['contact']);
    $department = sanitize($_POST['department']);
    
    // Validate uniqueness of email if changed
    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND id != ?");
    $stmt_check->execute([$email, $user_id]);
    $duplicate = $stmt_check->fetchColumn();
    
    if ($duplicate > 0) {
        $_SESSION['msg'] = "Email address is already in use by another user.";
        $_SESSION['msg_type'] = "error";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, contact = ?, department = ? WHERE id = ?");
        if ($stmt->execute([$name, $email, $contact, $department, $user_id])) {
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['msg'] = "Profile details updated successfully!";
            $_SESSION['msg_type'] = "success";
        } else {
            $_SESSION['msg'] = "Failed to update profile details.";
            $_SESSION['msg_type'] = "error";
        }
    }
    header("Location: profile.php");
    exit();
}

// Handle Password Change Form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $_SESSION['msg'] = "All password fields are required.";
        $_SESSION['msg_type'] = "error";
    } elseif ($new_password !== $confirm_password) {
        $_SESSION['msg'] = "New passwords do not match.";
        $_SESSION['msg_type'] = "error";
    } else {
        // Fetch current user details
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $curr_hash = $stmt->fetchColumn();
        
        if (password_verify($current_password, $curr_hash)) {
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt_up = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($stmt_up->execute([$new_hash, $user_id])) {
                $_SESSION['msg'] = "Password changed successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['msg'] = "Failed to update password.";
                $_SESSION['msg_type'] = "error";
            }
        } else {
            $_SESSION['msg'] = "Incorrect current password.";
            $_SESSION['msg_type'] = "error";
        }
    }
    header("Location: profile.php");
    exit();
}

// Fetch current user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$u = $stmt->fetch();

$profile_pic = !empty($u['profile_pic']) ? $u['profile_pic'] : 'default_profile.png';
if ($profile_pic === 'default_profile.png') {
    $profile_pic = 'admin_avatar.png';
}
$profile_pic_path = '../uploads/' . $profile_pic;
$profile_pic_version = file_exists($profile_pic_path) ? filemtime($profile_pic_path) : time();
$admin_level = $u['admin_type'] ?? 'main';

include_once '../includes/header.php';
?>

<style>
    /* Premium Profile Styles */
    .profile-avatar-container {
        position: relative;
        width: 140px;
        height: 140px;
        margin: 0 auto 1.5rem;
        border-radius: 50%;
        overflow: hidden;
        border: 4px solid transparent;
        background: linear-gradient(135deg, #a855f7 0%, #6366f1 100%) padding-box,
                    linear-gradient(135deg, #a855f7 0%, #6366f1 100%) border-box;
        box-shadow: 0 8px 30px rgba(99, 102, 241, 0.2);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        cursor: pointer;
    }
    
    .profile-avatar-container:hover {
        transform: scale(1.05);
        box-shadow: 0 15px 35px rgba(99, 102, 241, 0.4);
    }
    
    .profile-avatar-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .profile-avatar-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(15, 23, 42, 0.75);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.3s ease;
        color: #ffffff;
        backdrop-filter: blur(2px);
    }
    
    .profile-avatar-container:hover .profile-avatar-overlay {
        opacity: 1;
    }
    
    .profile-avatar-overlay i {
        font-size: 1.75rem;
        margin-bottom: 0.25rem;
    }
    
    .profile-avatar-overlay span {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 600;
    }
    
    .profile-initial-fallback {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
        color: #ffffff;
        font-size: 3.5rem;
        font-weight: 700;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    .form-group-icon {
        position: relative;
    }
    
    .form-group-icon i {
        position: absolute;
        left: 1.25rem;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 1.1rem;
        transition: color 0.3s ease;
    }
    
    .form-group-icon .form-control {
        padding-left: 3rem;
        border: 1px solid #cbd5e1;
        border-radius: 12px;
        transition: all 0.3s ease;
        font-weight: 500;
    }
    
    .form-group-icon .form-control:focus {
        border-color: #6366f1 !important;
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15) !important;
    }
    
    .form-group-icon .form-control:focus + i {
        color: #6366f1;
    }
    
    .badge-admin-type {
        text-transform: uppercase;
        font-weight: 700;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        padding: 0.5em 1em;
        border-radius: 50px;
    }
    
    .nav-tabs-premium {
        border-bottom: 1px solid #e2e8f0;
        gap: 0.75rem;
        padding-bottom: 0.5rem;
    }
    
    .nav-tabs-premium .nav-link {
        color: #64748b;
        font-weight: 600;
        border: none;
        border-radius: 30px;
        padding: 0.6rem 1.35rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: #f1f5f9;
        font-size: 0.9rem;
    }
    
    .nav-tabs-premium .nav-link:hover {
        color: #6366f1;
        background: #e2e8f0;
    }
    
    .nav-tabs-premium .nav-link.active {
        color: #ffffff;
        background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        font-weight: 600;
    }
    
    .password-toggle-btn {
        position: absolute;
        right: 1.25rem;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        cursor: pointer;
        transition: color 0.3s ease;
        z-index: 10;
    }
    
    .password-toggle-btn:hover {
        color: #6366f1;
    }
    
    .form-control-pass {
        padding-right: 3rem;
    }
    
    .input-label {
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.6rem !important;
        display: inline-block;
        font-weight: 600;
    }
    
    .btn-premium {
        background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 0.75rem 1.75rem !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3) !important;
        transition: all 0.3s ease !important;
        color: #ffffff !important;
    }
    
    .btn-premium:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(99, 102, 241, 0.5) !important;
    }
    
    .btn-danger {
        background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%) !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 0.75rem 1.75rem !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3) !important;
        transition: all 0.3s ease !important;
    }
    
    .btn-danger:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(239, 68, 68, 0.5) !important;
    }
</style>

<div class="fade-in">
    <!-- Header -->
    <div class="mb-4">
        <h2 class="fw-bold theme-text"><i class="fas fa-user-cog me-2 text-warning"></i> Account Settings</h2>
        <p class="theme-text-muted">Manage your administrative profile properties, avatar image, and system authentication credentials.</p>
    </div>
    
    <div class="row">
        <!-- Left Panel: Profile Avatar Card -->
        <div class="col-lg-4 mb-4">
            <div class="glass-card theme-card text-center p-4">
                <form action="profile.php" method="POST" enctype="multipart/form-data">
                    <div class="profile-avatar-container" onclick="document.getElementById('profile_pic_input').click();">
                        <?php if ($profile_pic === 'admin_avatar.png'): ?>
                            <div class="profile-initial-fallback" style="background: #ffffff; border: 3px solid #e2e8f0;">
                                <i class="fas fa-user-cog" style="font-size: 5rem; color: #374151;"></i>
                            </div>
                        <?php elseif ($profile_pic === 'default_profile.png'): ?>
                            <div class="profile-initial-fallback">
                                <?php echo strtoupper(substr($u['name'], 0, 1)); ?>
                            </div>
                        <?php else: ?>
                            <img src="../uploads/<?php echo htmlspecialchars($profile_pic); ?>?v=<?php echo $profile_pic_version; ?>" alt="Admin Avatar">
                        <?php endif; ?>
                        <div class="profile-avatar-overlay">
                            <i class="fas fa-camera"></i>
                            <span>Upload Photo</span>
                        </div>
                    </div>
                    <input type="file" id="profile_pic_input" name="profile_pic" style="display:none;" onchange="this.form.submit();">
                </form>
                
                <h4 class="fw-bold theme-text mb-1"><?php echo htmlspecialchars($u['name']); ?></h4>
                <p class="theme-text-muted small mb-3"><?php echo htmlspecialchars($u['email']); ?></p>
                
                <div class="mb-4">
                    <?php if ($admin_level === 'main'): ?>
                        <span class="badge bg-warning text-dark badge-admin-type"><i class="fas fa-shield-halved me-1"></i> Super Admin</span>
                    <?php else: ?>
                        <span class="badge bg-info text-white badge-admin-type"><i class="fas fa-shield me-1"></i> <?php echo $admin_level; ?> Admin</span>
                    <?php endif; ?>
                </div>
                
                <hr class="border-secondary border-opacity-10 my-4">
                
                <!-- Extra Metrics/Overview list -->
                <div class="text-start">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="theme-text-muted small fw-medium">Department</span>
                        <span class="theme-text small fw-semibold"><?php echo htmlspecialchars($u['department'] ?? 'Administration'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="theme-text-muted small fw-medium">Contact Number</span>
                        <span class="theme-text small fw-semibold"><?php echo htmlspecialchars($u['contact'] ?? 'Not set'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="theme-text-muted small fw-medium">Registered Since</span>
                        <span class="theme-text small fw-semibold"><?php echo date('d M, Y', strtotime($u['created_at'])); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Panel: Tabs for Edit Details & Password Reset -->
        <div class="col-lg-8 mb-4">
            <div class="glass-card theme-card p-4">
                <nav class="nav nav-tabs nav-tabs-premium mb-4" id="profile-tabs" role="tablist">
                    <button class="nav-link active" id="details-tab" data-bs-toggle="tab" data-bs-target="#details-content" type="button" role="tab"><i class="fas fa-id-card me-2"></i>Edit Details</button>
                    <button class="nav-link" id="password-tab" data-bs-toggle="tab" data-bs-target="#password-content" type="button" role="tab"><i class="fas fa-key me-2"></i>Change Password</button>
                </nav>
                
                <div class="tab-content" id="profile-tabs-content">
                    <!-- Tab 1: Edit Details -->
                    <div class="tab-pane fade show active" id="details-content" role="tabpanel">
                        <form action="profile.php" method="POST">
                            <input type="hidden" name="update_details" value="1">
                            
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">Full Name</label>
                                    <div class="form-group-icon">
                                        <input type="text" name="name" class="form-control theme-input" value="<?php echo htmlspecialchars($u['name']); ?>" required>
                                        <i class="fas fa-user"></i>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">Email Address</label>
                                    <div class="form-group-icon">
                                        <input type="email" name="email" class="form-control theme-input" value="<?php echo htmlspecialchars($u['email']); ?>" required>
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">Contact Number</label>
                                    <div class="form-group-icon">
                                        <input type="text" name="contact" class="form-control theme-input" value="<?php echo htmlspecialchars($u['contact'] ?? ''); ?>" placeholder="Enter 10-digit number">
                                        <i class="fas fa-phone"></i>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">Department / Designation</label>
                                    <div class="form-group-icon">
                                        <input type="text" name="department" class="form-control theme-input" value="<?php echo htmlspecialchars($u['department'] ?? ''); ?>" placeholder="e.g. IT Cell, General Office">
                                        <i class="fas fa-building"></i>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label class="input-label theme-text-muted">Access Level (System Locked)</label>
                                    <div class="form-group-icon">
                                        <input type="text" class="form-control theme-input opacity-75" value="<?php echo ucfirst($admin_level); ?> Administrator (<?php echo $admin_level === 'main' ? 'All Privileges' : 'Restricted Privileges'; ?>)" readonly>
                                        <i class="fas fa-lock"></i>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 pt-2 text-end">
                                <button type="submit" class="btn btn-premium px-4"><i class="fas fa-save me-2"></i>Save Details</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Tab 2: Change Password -->
                    <div class="tab-pane fade" id="password-content" role="tabpanel">
                        <form action="profile.php" method="POST">
                            <input type="hidden" name="change_password" value="1">
                            
                            <div class="row g-4">
                                <div class="col-md-12">
                                    <label class="input-label theme-text-muted">Current Password</label>
                                    <div class="form-group-icon position-relative">
                                        <input type="password" name="current_password" id="pass_current" class="form-control theme-input form-control-pass" required>
                                        <i class="fas fa-lock"></i>
                                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('pass_current')"><i class="fas fa-eye"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">New Password</label>
                                    <div class="form-group-icon position-relative">
                                        <input type="password" name="new_password" id="pass_new" class="form-control theme-input form-control-pass" required>
                                        <i class="fas fa-key"></i>
                                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('pass_new')"><i class="fas fa-eye"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="input-label theme-text-muted">Confirm New Password</label>
                                    <div class="form-group-icon position-relative">
                                        <input type="password" name="confirm_password" id="pass_confirm" class="form-control theme-input form-control-pass" required>
                                        <i class="fas fa-circle-check"></i>
                                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('pass_confirm')"><i class="fas fa-eye"></i></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 pt-2 text-end">
                                <button type="submit" class="btn btn-danger px-4"><i class="fas fa-key me-2"></i>Update Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function togglePasswordVisibility(fieldId) {
        const input = document.getElementById(fieldId);
        const icon = input.nextElementSibling.nextElementSibling.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
</script>

<?php include_once '../includes/footer.php'; ?>
