<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

// Retrieve filter variables
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$category_id = $_GET['category'] ?? '';
$priority = $_GET['priority'] ?? '';
$user_id_filter = $_GET['user_id'] ?? '';

// Build filters query
$where_clauses = ["1=1"];
$params = [];

// Formulate level restriction SQL based on admin tier
$admin_type = $_SESSION['admin_type'] ?? 'main';
if ($admin_type === 'department') {
    $where_clauses[] = "DATEDIFF(NOW(), g.created_at) < 7";
} elseif ($admin_type === 'college') {
    $where_clauses[] = "DATEDIFF(NOW(), g.created_at) >= 7 AND DATEDIFF(NOW(), g.created_at) < 14";
} elseif ($admin_type === 'university') {
    $where_clauses[] = "DATEDIFF(NOW(), g.created_at) >= 14";
}

if (!empty($start_date)) {
    $where_clauses[] = "g.created_at >= ?";
    $params[] = $start_date . ' 00:00:00';
}
if (!empty($end_date)) {
    $where_clauses[] = "g.created_at <= ?";
    $params[] = $end_date . ' 23:59:59';
}
if (!empty($category_id)) {
    $where_clauses[] = "g.category_id = ?";
    $params[] = (int)$category_id;
}
if (!empty($priority)) {
    $where_clauses[] = "g.priority = ?";
    $params[] = $priority;
}
if (!empty($user_id_filter)) {
    $where_clauses[] = "g.user_id = ?";
    $params[] = (int)$user_id_filter;
}

$where = implode(' AND ', $where_clauses);

// Fetch grievances matching filters
$stmt = $pdo->prepare("SELECT g.*, c.name as category, u.name as user_name, u.email as user_email
                       FROM grievances g 
                       JOIN categories c ON g.category_id = c.id 
                       JOIN users u ON g.user_id = u.id 
                       WHERE $where 
                       ORDER BY g.created_at DESC");
$stmt->execute($params);
$complaints = $stmt->fetchAll();

// Handle CSV export before rendering any HTML
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=grievance_report_' . date('Ymd') . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Complaint ID', 'Complainant', 'Complainant Email', 'Category', 'Title', 'Priority', 'Status', 'Date Submitted']);
    foreach ($complaints as $c) {
        fputcsv($output, [
            $c['complaint_id'],
            $c['user_name'],
            $c['user_email'],
            $c['category'],
            $c['title'],
            $c['priority'],
            $c['status'],
            date('Y-m-d H:i:s', strtotime($c['created_at']))
        ]);
    }
    fclose($output);
    exit();
}

// Calculate Statistics
$total_count = count($complaints);
$pending_count = 0;
$in_progress_count = 0;
$resolved_count = 0;
$rejected_count = 0;

$categories_count = [];
$priority_count = ['Low' => 0, 'Medium' => 0, 'High' => 0];

foreach ($complaints as $c) {
    if ($c['status'] === 'Pending') $pending_count++;
    elseif ($c['status'] === 'In Progress') $in_progress_count++;
    elseif ($c['status'] === 'Resolved') $resolved_count++;
    elseif ($c['status'] === 'Rejected') $rejected_count++;

    $cat = $c['category'];
    $categories_count[$cat] = ($categories_count[$cat] ?? 0) + 1;
    
    $pri = $c['priority'];
    if (isset($priority_count[$pri])) {
        $priority_count[$pri]++;
    }
}

$resolution_rate = $total_count > 0 ? round(($resolved_count / $total_count) * 100) : 0;

// Avg resolution time in hours
$avg_stmt = $pdo->prepare("SELECT AVG(TIMESTAMPDIFF(HOUR, g.created_at, gu.created_at)) as avg_hours 
                           FROM grievances g 
                           JOIN grievance_updates gu ON g.id = gu.grievance_id 
                           WHERE g.status = 'Resolved' AND gu.status = 'Resolved' AND $where");
$avg_stmt->execute($params);
$avg_res_time = $avg_stmt->fetch()['avg_hours'];
$avg_res_time = $avg_res_time ? round($avg_res_time, 1) : null;

// Categories for filters dropdown
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

// Users for filters dropdown
$filter_users = $pdo->query("SELECT id, name, email, role FROM users WHERE role != 'admin' ORDER BY name ASC")->fetchAll();

include_once '../includes/header.php';
?>

<style>
    .print-header {
        display: none;
    }
    @media print {
        body {
            background: white !important;
            color: black !important;
        }
        .portal-sidebar, .portal-topbar, .no-print, form, .btn {
            display: none !important;
        }
        .portal-main {
            margin-left: 0 !important;
            width: 100% !important;
            padding: 0 !important;
            height: auto !important;
            overflow: visible !important;
        }
        .print-header {
            display: block !important;
            margin-bottom: 25px;
            text-align: center;
        }
        .glass-card {
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            color: black !important;
            padding: 0 !important;
            margin-bottom: 20px !important;
        }
        table {
            color: black !important;
            border-collapse: collapse !important;
            width: 100% !important;
        }
        table th, table td {
            border: 1px solid #dee2e6 !important;
            color: black !important;
            padding: 8px !important;
        }
        .text-white, .text-muted, .text-info {
            color: black !important;
        }
        .badge {
            border: 1px solid #000 !important;
            color: black !important;
            background: transparent !important;
        }
    }
</style>

<div class="fade-in">
    <!-- Printable Header (Visible only during printing) -->
    <div class="print-header text-center border-bottom pb-3">
        <h2 class="fw-bold text-dark">NSTI Hyderabad - Grievance Cell Report</h2>
        <p class="text-muted mb-0">Generated on: <?php echo date('d M Y, h:i A'); ?></p>
        <?php if (!empty($user_id_filter)): ?>
            <?php 
            $selected_user_stmt = $pdo->prepare("SELECT name, email, role FROM users WHERE id = ?");
            $selected_user_stmt->execute([$user_id_filter]);
            $su_info = $selected_user_stmt->fetch();
            if ($su_info):
            ?>
                <p class="fw-bold text-dark mt-2 mb-0">Filtered for Complainant: <?php echo htmlspecialchars($su_info['name']); ?> (<?php echo htmlspecialchars($su_info['email']); ?> - <?php echo ucfirst($su_info['role']); ?>)</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-5 mt-2 no-print">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold mb-1 theme-text" style="font-weight: 800; letter-spacing: -0.5px;">Grievance Analytics & Reports</h2>
            <p class="theme-text-muted mb-0" style="font-size: 1.05rem;">Generate audit logs, review key metrics, and print or export data.</p>
        </div>
        <div class="d-flex gap-3">
            <button onclick="window.print()" class="btn shadow-sm d-flex align-items-center justify-content-center" style="border-radius: 8px; border: 1px solid #cbd5e1; background: #f8fafc; color: #64748b; font-weight: 600; padding: 0.6rem 1.2rem; transition: all 0.2s ease;" onmouseover="this.style.background='#f1f5f9'; this.style.color='#475569';" onmouseout="this.style.background='#f8fafc'; this.style.color='#64748b';">
                <i class="fas fa-print me-2"></i> Print Report
            </button>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>" class="btn shadow d-flex align-items-center justify-content-center text-white" style="border-radius: 8px; background: linear-gradient(135deg, #a855f7 0%, #6366f1 100%); border: none; font-weight: 700; padding: 0.6rem 1.5rem; text-transform: uppercase; letter-spacing: 0.5px; transition: transform 0.2s ease;" onmouseover="this.style.transform='translateY(-2px)';" onmouseout="this.style.transform='translateY(0)';">
                <i class="fas fa-file-csv me-2 fs-5"></i> Export CSV
            </a>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="glass-card theme-card p-4 mb-4 no-print shadow-sm" style="border-radius: 16px; border: 1px solid var(--border-color, #f1f5f9);">
        <h5 class="mb-4 fw-bold theme-text d-flex align-items-center">
            <i class="fas fa-filter text-primary me-2 fs-5" style="color: #6366f1 !important;"></i> Filter Report Data
        </h5>
        <form method="GET" action="" class="row g-4 align-items-end">
            <div class="col-md-2">
                <label class="form-label text-muted fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">Start Date</label>
                <div class="position-relative">
                    <input type="date" name="start_date" class="form-control form-control-lg bg-white" value="<?php echo $start_date; ?>" style="border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.9rem; padding: 0.75rem 1rem;">
                </div>
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">End Date</label>
                <div class="position-relative">
                    <input type="date" name="end_date" class="form-control form-control-lg bg-white" value="<?php echo $end_date; ?>" style="border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.9rem; padding: 0.75rem 1rem;">
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label text-muted fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">User / Complainant</label>
                <select name="user_id" class="form-select form-select-lg bg-white" style="border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.9rem; padding: 0.75rem 1rem;">
                    <option value="">All Users</option>
                    <?php foreach ($filter_users as $fu): ?>
                        <option value="<?php echo $fu['id']; ?>" <?php echo $user_id_filter == $fu['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($fu['name']); ?> (<?php echo ucfirst($fu['role']); ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label text-muted fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">Category</label>
                <select name="category" class="form-select form-select-lg bg-white" style="border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.9rem; padding: 0.75rem 1rem;">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo $category_id == $cat['id'] ? 'selected' : ''; ?>><?php echo $cat['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">Priority</label>
                <select name="priority" class="form-select form-select-lg bg-white" style="border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.9rem; padding: 0.75rem 1rem;">
                    <option value="">All Priorities</option>
                    <option value="Low" <?php echo $priority === 'Low' ? 'selected' : ''; ?>>Low</option>
                    <option value="Medium" <?php echo $priority === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                    <option value="High" <?php echo $priority === 'High' ? 'selected' : ''; ?>>High</option>
                </select>
            </div>
            <div class="col-12 mt-4 text-end">
                <a href="reports.php" class="btn btn-light px-4 py-2 me-2 text-muted fw-bold shadow-sm" style="border: 1px solid #e2e8f0; border-radius: 10px; font-size: 0.9rem; letter-spacing: 0.5px; transition: all 0.3s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='#ffffff';">Clear Filters</a>
                <button type="submit" class="btn btn-primary px-4 py-2 text-white fw-bold shadow-sm" style="background: linear-gradient(135deg, #a855f7 0%, #6366f1 100%); border: none; border-radius: 10px; font-size: 0.9rem; letter-spacing: 0.5px; text-transform: uppercase; transition: transform 0.2s ease;" onmouseover="this.style.transform='translateY(-2px)';" onmouseout="this.style.transform='translateY(0)';">Generate Report</button>
            </div>
        </form>
    </div>

    <!-- Analytics Dashboard Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="glass-card h-100 position-relative overflow-hidden p-4" style="background: linear-gradient(135deg, #4f46e5 0%, #3b82f6 100%); border: none; box-shadow: 0 10px 25px rgba(79, 70, 229, 0.4); color: white; transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(79, 70, 229, 0.6)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 25px rgba(79, 70, 229, 0.4)';">
                <div class="position-absolute" style="top: -20px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.15); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-center mb-3 position-relative z-1">
                    <h6 class="text-uppercase small mb-0 fw-semibold" style="letter-spacing: 0.5px; opacity: 0.9;">Total Complaints</h6>
                    <div style="background: rgba(255,255,255,0.2); width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(5px);">
                        <i class="fas fa-layer-group fa-lg"></i>
                    </div>
                </div>
                <h2 class="mb-0 fw-bold position-relative z-1" style="font-size: 2.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.15);"><?php echo $total_count; ?></h2>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="glass-card h-100 position-relative overflow-hidden p-4" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); border: none; box-shadow: 0 10px 25px rgba(16, 185, 129, 0.4); color: white; transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(16, 185, 129, 0.6)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 25px rgba(16, 185, 129, 0.4)';">
                <div class="position-absolute" style="top: -20px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.15); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-center mb-3 position-relative z-1">
                    <h6 class="text-uppercase small mb-0 fw-semibold" style="letter-spacing: 0.5px; opacity: 0.9;">Resolution Rate</h6>
                    <div style="background: rgba(255,255,255,0.2); width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(5px);">
                        <i class="fas fa-chart-line fa-lg"></i>
                    </div>
                </div>
                <h2 class="mb-0 fw-bold position-relative z-1" style="font-size: 2.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.15);"><?php echo $resolution_rate; ?>%</h2>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="glass-card h-100 position-relative overflow-hidden p-4" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); border: none; box-shadow: 0 10px 25px rgba(245, 158, 11, 0.4); color: white; transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(245, 158, 11, 0.6)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 25px rgba(245, 158, 11, 0.4)';">
                <div class="position-absolute" style="top: -20px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.15); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-center mb-3 position-relative z-1">
                    <h6 class="text-uppercase small mb-0 fw-semibold" style="letter-spacing: 0.5px; opacity: 0.9;">Resolution Time</h6>
                    <div style="background: rgba(255,255,255,0.2); width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(5px);">
                        <i class="fas fa-clock fa-lg"></i>
                    </div>
                </div>
                <h2 class="mb-0 fw-bold position-relative z-1" style="font-size: 2.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.15);"><?php echo $avg_res_time ? $avg_res_time . '<span class="fs-6 fw-normal ms-1">hrs</span>' : 'N/A'; ?></h2>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="glass-card h-100 position-relative overflow-hidden p-4" style="background: linear-gradient(135deg, #ec4899 0%, #db2777 100%); border: none; box-shadow: 0 10px 25px rgba(236, 72, 153, 0.4); color: white; transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(236, 72, 153, 0.6)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 10px 25px rgba(236, 72, 153, 0.4)';">
                <div class="position-absolute" style="top: -20px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.15); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-center mb-3 position-relative z-1">
                    <h6 class="text-uppercase small mb-0 fw-semibold" style="letter-spacing: 0.5px; opacity: 0.9;">Resolved Cases</h6>
                    <div style="background: rgba(255,255,255,0.2); width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(5px);">
                        <i class="fas fa-check-circle fa-lg"></i>
                    </div>
                </div>
                <h2 class="mb-0 fw-bold position-relative z-1" style="font-size: 2.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.15);"><?php echo $resolved_count; ?><span class="fs-5 fw-normal opacity-75 ms-1">/ <?php echo $total_count; ?></span></h2>
            </div>
        </div>
    </div>

    <!-- Charts and Breakdown -->
    <div class="row mb-4 no-print">
        <div class="col-md-6 mb-3">
            <div class="glass-card theme-card h-100 p-4 shadow-sm" style="border-radius: 16px; border: 1px solid var(--border-color, #f1f5f9);">
                <h5 class="mb-4 fw-bold theme-text"><i class="fas fa-chart-pie me-2 text-primary opacity-75"></i>Grievance Status Breakdown</h5>
                <div style="max-height: 280px; position: relative;" class="d-flex justify-content-center">
                    <canvas id="statusReportChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="glass-card theme-card h-100 p-4 shadow-sm" style="border-radius: 16px; border: 1px solid var(--border-color, #f1f5f9);">
                <h5 class="mb-4 fw-bold theme-text"><i class="fas fa-chart-bar me-2 text-primary opacity-75"></i>Grievance Category Distribution</h5>
                <div style="max-height: 280px; position: relative;">
                    <canvas id="categoryReportChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="glass-card theme-card p-0 overflow-hidden shadow-sm mt-4">
        <div class="p-4 border-bottom d-flex justify-content-between align-items-center" style="border-color: var(--border-color, #e2e8f0) !important;">
            <h4 class="mb-0 fw-bold theme-text"><i class="fas fa-list-alt text-primary me-2"></i>Audit Log & Records</h4>
            <span class="badge rounded-pill bg-light text-dark border px-3 py-2 fw-semibold" style="box-shadow: 0 2px 4px rgba(0,0,0,0.02);"><?php echo $total_count; ?> Records Found</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 border-0">
                <thead style="border-bottom: 2px solid var(--border-color, #e2e8f0);">
                    <tr>
                        <th class="ps-4 text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Complaint ID</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Complainant</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Category</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Subject</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Priority</th>
                        <th class="text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Status</th>
                        <th class="pe-4 text-uppercase theme-text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px; font-weight: 700; padding: 1.2rem 1rem;">Date Submitted</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (empty($complaints)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                                <p class="mb-0 fw-medium">No records match the active filters.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $c): ?>
                            <tr style="transition: all 0.2s ease;">
                                <td class="ps-4 py-3 border-bottom theme-border">
                                    <span class="fw-bold text-primary" style="font-family: monospace; letter-spacing: 0.5px; font-size: 0.9rem;"><?php echo $c['complaint_id']; ?></span>
                                </td>
                                <td class="py-3 border-bottom theme-border">
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle d-flex justify-content-center align-items-center text-white fw-bold me-3 shadow-sm" style="width: 42px; height: 42px; background: linear-gradient(135deg, #6366f1, #a855f7); flex-shrink: 0; font-size: 1.1rem;">
                                            <?php echo strtoupper(substr($c['user_name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold theme-text mb-0" style="font-size: 0.95rem;"><?php echo htmlspecialchars($c['user_name']); ?></div>
                                            <div class="theme-text-muted" style="font-size: 0.8rem;"><?php echo htmlspecialchars($c['user_email']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3 border-bottom theme-border">
                                    <span class="fw-medium theme-text" style="font-size: 0.9rem;"><?php echo htmlspecialchars($c['category']); ?></span>
                                </td>
                                <td class="py-3 border-bottom theme-border">
                                    <div class="text-truncate theme-text fw-medium" style="max-width: 200px; font-size: 0.9rem;" title="<?php echo htmlspecialchars($c['title']); ?>"><?php echo htmlspecialchars($c['title']); ?></div>
                                </td>
                                <td class="py-3 border-bottom theme-border">
                                    <span class="<?php echo getPriorityBadge($c['priority']); ?> px-3 py-2 rounded-pill shadow-sm" style="font-size: 0.7rem; letter-spacing: 0.5px; font-weight: 700; text-transform: uppercase;"><?php echo $c['priority']; ?></span>
                                </td>
                                <td class="py-3 border-bottom theme-border">
                                    <span class="<?php echo getStatusBadge($c['status']); ?> px-3 py-2 rounded-pill shadow-sm" style="font-size: 0.7rem; letter-spacing: 0.5px; font-weight: 700; text-transform: uppercase;"><?php echo getStatusLabel($c['status']); ?></span>
                                </td>
                                <td class="pe-4 py-3 border-bottom theme-text-muted theme-border">
                                    <div class="fw-semibold theme-text" style="font-size: 0.9rem;"><?php echo date('d M Y', strtotime($c['created_at'])); ?></div>
                                    <div style="font-size: 0.75rem;"><i class="far fa-clock me-1 opacity-75"></i><?php echo date('h:i A', strtotime($c['created_at'])); ?></div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Chart Scripts -->
<script class="no-print">
document.addEventListener('DOMContentLoaded', function() {
    // 1. Status Chart
    const statusCtx = document.getElementById('statusReportChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Not Processed', 'Under Process', 'Resolved Complaint', 'Rejected Complaint'],
            datasets: [{
                data: [
                    <?php echo $pending_count; ?>,
                    <?php echo $in_progress_count; ?>,
                    <?php echo $resolved_count; ?>,
                    <?php echo $rejected_count; ?>
                ],
                backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444'],
                hoverOffset: 10,
                borderWidth: 3,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            layout: { padding: 10 },
            plugins: {
                legend: {
                    position: 'right',
                    labels: { color: '#64748b', font: { family: 'Outfit', size: 13, weight: '500' }, padding: 20, usePointStyle: true, pointStyle: 'circle' }
                },
                tooltip: { backgroundColor: '#1e293b', padding: 12, cornerRadius: 8, titleFont: { size: 14 }, bodyFont: { size: 13 } }
            },
            cutout: '70%'
        }
    });

    // 2. Category Chart
    const categoryCtx = document.getElementById('categoryReportChart').getContext('2d');
    
    const gradient = categoryCtx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, '#a855f7');
    gradient.addColorStop(1, '#6366f1');

    const categoryData = <?php echo json_encode($categories_count); ?>;
    const categoryLabels = Object.keys(categoryData);
    const categoryValues = Object.values(categoryData);

    new Chart(categoryCtx, {
        type: 'bar',
        data: {
            labels: categoryLabels,
            datasets: [{
                label: 'Complaints count',
                data: categoryValues,
                backgroundColor: gradient,
                borderRadius: 8,
                barPercentage: 0.6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: '#64748b', font: { family: 'Outfit', weight: '500' } }
                },
                y: {
                    grid: { color: '#f1f5f9', drawBorder: false },
                    border: { display: false },
                    ticks: { color: '#64748b', font: { family: 'Outfit' }, stepSize: 1, padding: 10 }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: '#1e293b', padding: 12, cornerRadius: 8, titleFont: { size: 14 }, bodyFont: { size: 13 } }
            }
        }
    });
});
</script>

<?php include_once '../includes/footer.php'; ?>
