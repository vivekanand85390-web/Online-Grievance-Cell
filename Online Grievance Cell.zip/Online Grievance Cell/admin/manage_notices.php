<?php
include_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../admin/login.php', 'Unauthorized access', 'error');
}

// Handle Form Submission for New Notice
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = sanitize($_POST['title']);
    $message = sanitize($_POST['message']);
    $target_audience = sanitize($_POST['target_audience']);
    $created_by = $_SESSION['user_id'];

    if (empty($title) || empty($message)) {
        redirect('manage_notices.php', 'Title and message are required', 'error');
    } else {
        $stmt = $pdo->prepare("INSERT INTO notices (title, message, target_audience, created_by) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$title, $message, $target_audience, $created_by])) {
            redirect('manage_notices.php', 'Notice added successfully', 'success');
        } else {
            redirect('manage_notices.php', 'Failed to add notice', 'error');
        }
    }
}

// Handle Notice Deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM notices WHERE id = ?");
    if ($stmt->execute([$id])) {
        redirect('manage_notices.php', 'Notice deleted successfully', 'success');
    } else {
        redirect('manage_notices.php', 'Failed to delete notice', 'error');
    }
}

// Fetch existing notices
$stmt = $pdo->query("SELECT n.*, u.name as created_by_name FROM notices n LEFT JOIN users u ON n.created_by = u.id ORDER BY n.created_at DESC");
$notices = $stmt->fetchAll();

include_once '../includes/header.php';
?>

<div class="fade-in">
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="glass-card theme-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom theme-border">
                    <h5 class="mb-0 theme-text"><i class="fas fa-plus-circle me-2 text-primary"></i>Add New Notice</h5>
                </div>
                <div>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label for="title" class="form-label theme-text">Notice Title</label>
                            <input type="text" class="form-control theme-input" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="target_audience" class="form-label theme-text">Target Audience</label>
                            <select class="form-select theme-input" id="target_audience" name="target_audience" required>
                                <option value="all">All</option>
                                <option value="student">Students Only</option>
                                <option value="staff">Staff Only</option>
                                <option value="parent">Parents Only</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label theme-text">Message</label>
                            <textarea class="form-control theme-input" id="message" name="message" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i> Publish Notice
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-12">
            <div class="glass-card theme-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom theme-border">
                    <h5 class="mb-0 theme-text"><i class="fas fa-list me-2 text-info"></i>Existing Notices</h5>
                </div>
                <div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="theme-text">Date</th>
                                    <th class="theme-text">Title</th>
                                    <th class="theme-text">Target</th>
                                    <th class="theme-text">Author</th>
                                    <th class="theme-text">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($notices)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No notices found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($notices as $notice): ?>
                                        <tr>
                                            <td class="theme-text"><?php echo date('d M Y, h:i A', strtotime($notice['created_at'])); ?></td>
                                            <td class="theme-text"><strong><?php echo htmlspecialchars($notice['title']); ?></strong></td>
                                            <td class="theme-text"><span class="badge bg-info text-dark"><?php echo ucfirst($notice['target_audience']); ?></span></td>
                                            <td class="theme-text"><?php echo htmlspecialchars($notice['created_by_name'] ?? 'System'); ?></td>
                                            <td>
                                                <a href="manage_notices.php?action=delete&id=<?php echo $notice['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this notice?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
