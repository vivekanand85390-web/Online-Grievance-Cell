﻿<?php
include_once 'includes/functions.php';

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $contact = isset($_POST['contact']) ? sanitize($_POST['contact']) : '';
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    $message = sanitize($_POST['message']);

    if (empty($name) || empty($email) || $rating === 0 || empty($message)) {
        $error = 'Please fill out all required fields and select a rating.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO feedbacks (name, email, contact, rating, message) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $contact, $rating, $message])) {
                $success = true;
            } else {
                $error = 'Failed to submit feedback. Please try again.';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Feedback - Online Grievance Cell</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-base: #f5f7fb;
            --nsti-blue: #0f3057;
            --nsti-blue-glow: rgba(15, 48, 87, 0.12);
            --nsti-magenta: #b01c70;
            --nsti-magenta-glow: rgba(176, 28, 112, 0.12);
            --text-dark: #1e293b;
            --text-muted: #64748b;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            background-image: 
                radial-gradient(at 0% 0%, rgba(15, 48, 87, 0.03) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(176, 28, 112, 0.03) 0px, transparent 50%);
            min-height: 100vh;
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .custom-navbar {
            padding: 1.1rem 5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(15, 48, 87, 0.05);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }

        .logo-text {
            font-weight: 800;
            font-size: 1.35rem;
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-links .btn-home {
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            color: #ffffff !important;
            padding: 0.6rem 1.6rem;
            border-radius: 2rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(176, 28, 112, 0.2);
            display: inline-flex;
            align-items: center;
            font-size: 0.95rem;
        }

        .nav-links .btn-home:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(176, 28, 112, 0.35);
        }

        .main-container {
            flex: 1;
            padding: 3.5rem 1.5rem;
            max-width: 680px;
            margin: 0 auto;
            width: 100%;
        }

        .feedback-card {
            background: #ffffff;
            border-radius: 24px;
            border: none;
            box-shadow: 0 15px 45px rgba(15, 48, 87, 0.05);
            padding: 3.5rem 3rem;
            position: relative;
            overflow: hidden;
        }

        .feedback-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--nsti-magenta) 0%, var(--nsti-blue) 100%);
        }

        .feedback-header-icon-wrapper {
            display: flex;
            justify-content: center;
            margin-bottom: 1.25rem;
        }

        .feedback-header-icon {
            width: 86px;
            height: 86px;
            background-color: #dbeafe; /* Light blue */
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #2563eb;
            font-size: 2.3rem;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.1);
        }

        .form-title {
            font-size: 1.85rem;
            font-weight: 800;
            color: var(--nsti-blue);
            text-align: center;
            margin-bottom: 0.5rem;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .form-subtitle {
            color: var(--text-muted);
            text-align: center;
            margin-bottom: 2.5rem;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .form-label {
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.75px;
            color: var(--text-muted);
            margin-bottom: 0.6rem;
        }

        .input-group-custom {
            position: relative;
        }

        .form-control-custom {
            width: 100%;
            height: 52px;
            padding: 10px 16px 10px 48px;
            font-size: 0.95rem;
            font-weight: 500;
            color: var(--text-dark);
            background-color: #ffffff;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .form-control-custom:focus {
            outline: none;
            border-color: var(--nsti-blue);
            box-shadow: 0 0 0 4px var(--nsti-blue-glow);
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            transition: color 0.3s ease;
            pointer-events: none;
            font-size: 1.05rem;
        }

        .form-control-custom:focus ~ .input-icon {
            color: var(--nsti-blue);
        }

        .textarea-custom {
            height: 120px;
            padding: 14px 16px 14px 48px;
            resize: none;
        }

        .textarea-icon {
            top: 24px;
            transform: none;
        }

        /* Interactive Star Ratings */
        .rating-container {
            background-color: #f8fafc;
            border: 1.5px dashed #cbd5e1;
            border-radius: 16px;
            padding: 1.5rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .rating-stars {
            display: flex;
            flex-direction: row-reverse;
            justify-content: center;
            gap: 0.75rem;
            margin-top: 0.5rem;
        }

        .rating-stars input {
            display: none;
        }

        .rating-stars label {
            font-size: 2.5rem;
            color: #cbd5e1;
            cursor: pointer;
            transition: color 0.2s ease-in-out, transform 0.2s ease;
        }

        .rating-stars label:hover,
        .rating-stars label:hover ~ label,
        .rating-stars input:checked ~ label {
            color: #fbbf24; /* Warm yellow */
            transform: scale(1.1);
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            color: #ffffff;
            border: none;
            border-radius: 14px;
            padding: 0.95rem;
            font-weight: 700;
            font-size: 1.1rem;
            letter-spacing: 0.5px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 15px rgba(176, 28, 112, 0.2);
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(176, 28, 112, 0.35);
            filter: brightness(1.05);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .footer-bar {
            background-color: var(--nsti-blue);
            color: #ffffff;
            padding: 1.5rem 5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            border-top: 4px solid var(--nsti-magenta);
            margin-top: 4rem;
        }

        @media (max-width: 768px) {
            .custom-navbar {
                padding: 1rem 2rem;
            }
            .logo-text {
                font-size: 1.15rem;
            }
            .main-container {
                padding: 2rem 1rem;
            }
            .feedback-card {
                padding: 2.5rem 1.5rem;
            }
            .footer-bar {
                padding: 1.2rem 2rem;
                flex-direction: column;
                gap: 0.5rem;
                text-align: center;
            }
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Header Navigation -->
    <header class="custom-navbar">
        <a href="index.php" class="logo-section">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="36" height="36" class="logo-img">
            <span class="logo-text">NSTI R-HYDERABAD</span>
        </a>
        <nav class="nav-links">
            <a href="index.php" class="btn-home"><i class="fas fa-home me-2"></i><span class="notranslate custom-translate-home">Home</span></a>
        </nav>
    </header>

    <!-- Main Container -->
    <main class="main-container">
        <div class="feedback-card">
            <div class="feedback-header-icon-wrapper">
                <div class="feedback-header-icon">
                    <i class="fas fa-comments"></i>
                </div>
            </div>
            
            <h1 class="form-title">Share Your Feedback</h1>
            <p class="form-subtitle">Help us improve the Online Grievance Cell experience</p>

            <?php if ($error): ?>
                <div class="alert alert-danger rounded-3 p-3 mb-4" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="feedback.php" method="POST">
                
                <!-- Name Field -->
                <div class="mb-4">
                    <label class="form-label" for="name">Full Name *</label>
                    <div class="input-group-custom">
                        <input type="text" id="name" name="name" class="form-control-custom" placeholder="Enter your full name" required>
                        <span class="input-icon"><i class="fas fa-user"></i></span>
                    </div>
                </div>

                <!-- Row: Email and Mobile -->
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <label class="form-label" for="email">Email Address *</label>
                        <div class="input-group-custom">
                            <input type="email" id="email" name="email" class="form-control-custom" placeholder="e.g. name@domain.com" required>
                            <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="contact">Mobile Number</label>
                        <div class="input-group-custom">
                            <input type="text" id="contact" name="contact" class="form-control-custom" placeholder="10-digit number">
                            <span class="input-icon"><i class="fas fa-phone-alt"></i></span>
                        </div>
                    </div>
                </div>

                <!-- Rating Selector -->
                <div class="rating-container mb-4">
                    <span class="form-label d-block text-center fw-bold">Overall Rating *</span>
                    <div class="rating-stars">
                        <input type="radio" id="star5" name="rating" value="5" required>
                        <label for="star5" title="5 Stars"><i class="fas fa-star"></i></label>
                        
                        <input type="radio" id="star4" name="rating" value="4">
                        <label for="star4" title="4 Stars"><i class="fas fa-star"></i></label>
                        
                        <input type="radio" id="star3" name="rating" value="3">
                        <label for="star3" title="3 Stars"><i class="fas fa-star"></i></label>
                        
                        <input type="radio" id="star2" name="rating" value="2">
                        <label for="star2" title="2 Stars"><i class="fas fa-star"></i></label>
                        
                        <input type="radio" id="star1" name="rating" value="1">
                        <label for="star1" title="1 Star"><i class="fas fa-star"></i></label>
                    </div>
                </div>

                <!-- Feedback Message -->
                <div class="mb-4">
                    <label class="form-label" for="message">Suggestions / Feedback *</label>
                    <div class="input-group-custom">
                        <textarea id="message" name="message" class="form-control-custom textarea-custom" placeholder="Tell us about your experience..." required></textarea>
                        <span class="input-icon textarea-icon"><i class="fas fa-comment-dots"></i></span>
                    </div>
                </div>

                <button type="submit" class="btn-submit"><i class="fas fa-paper-plane me-2"></i>Submit Feedback</button>
            </form>
        </div>
    </main>

    <!-- Footer Bar -->
    <footer class="footer-bar">
        <div>
            <span>Grievance Management System</span>
        </div>
        <div>
            <span>&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</span>
        </div>
    </footer>

    <!-- Bootstrap & SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if ($success): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Thank You!',
                text: 'Your feedback has been successfully submitted.',
                background: '#ffffff',
                color: '#1e293b',
                confirmButtonColor: '#0f3057'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>
    <?php endif; ?>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>







