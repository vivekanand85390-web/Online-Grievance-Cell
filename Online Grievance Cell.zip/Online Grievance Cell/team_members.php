<?php
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Members - NSTI R-Hyderabad</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-base: #f7f9fc;
            --nsti-blue: #0f3057;
            --nsti-magenta: #b01c70;
            --text-dark: #2d3748;
            --text-muted: #718096;
            --card-border: rgba(0, 0, 0, 0.06);
            --bg-light: #ffffff;
        }

        body, html {
            margin: 0;
            padding: 0;
            scroll-behavior: smooth;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Header Branding Section */
                        .header-branding {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 1rem;
            width: 100%;
            padding: 1rem 2rem;
        }





        .header-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            justify-self: start;
        }


        .header-logo img {
            width: 110px;
            height: auto;
            object-fit: contain;
        }

        .logo-caption {
            margin: 0;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--nsti-blue);
            text-align: center;
            white-space: nowrap;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-top: 2px solid var(--nsti-magenta);
            padding: 0.4rem 0.5rem 0 0.5rem;
        }

        .logo-caption .caption-location {
            color: var(--nsti-magenta);
            font-weight: 800;
        }

        .header-titles {
            text-align: center;
            justify-self: center;
        }





        .header-titles .main-title {
            font-size: 3.8rem;
            font-weight: 900;
            color: var(--nsti-blue);
            margin: 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .header-titles .sub-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--nsti-magenta);
            margin: 0.25rem 0 0 0;
            white-space: nowrap;
        }

        .header-right-logo {
            justify-self: end;
        }


        @media (max-width: 1400px) {
            .header-titles .main-title { font-size: 3.2rem; }
            .header-titles .sub-title { font-size: 1.8rem; }
            .header-branding { padding: 1rem; }
        }

        @media (max-width: 1200px) {
            .header-titles .main-title { font-size: 2.8rem; }
            .header-titles .sub-title { font-size: 1.6rem; }
        }

        @media (max-width: 991px) {
            .header-branding {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
                text-align: center;
                padding: 1rem;
            }
            .header-titles .main-title {
                font-size: 2.8rem;
                white-space: nowrap;
            }
            .header-titles .sub-title {
                font-size: 1.6rem;
                white-space: nowrap;
                margin-top: 0.25rem;
            }
        }
        
        @media (max-width: 576px) {
            .header-titles .main-title {
                font-size: 2.2rem;
                white-space: normal;
                line-height: 1.2;
            }
            .header-titles .sub-title {
                font-size: 1.4rem;
                white-space: normal;
                line-height: 1.3;
            }
        }

        /* Navigation Bar Styles */
        .custom-navbar {
            background-color: var(--nsti-blue);
            box-shadow: 0 4px 15px rgba(15, 48, 87, 0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            transition: all 0.3s ease;
        }

        .menu-toggle {
            display: none;
            background: transparent;
            border: none;
            color: #ffffff;
            font-size: 1.35rem;
            cursor: pointer;
            padding: 0.5rem;
            align-items: center;
            justify-content: center;
        }

        .mobile-brand {
            display: none;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.95rem;
            text-transform: uppercase;
            text-decoration: none;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            justify-content: center;
            list-style: none;
            flex-wrap: wrap;
            margin: 0;
            padding: 0;
        }

        .nav-menu li {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            color: #ffffff;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.9rem 1.2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            text-transform: capitalize;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #ffe600;
            border-bottom-color: var(--nsti-magenta);
        }

        .nav-menu .separator {
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.9rem;
            user-select: none;
        }

        @media (max-width: 768px) {
            .navbar-container {
                justify-content: flex-end;
                flex-wrap: wrap;
                padding: 0.5rem 1rem;
                background-color: rgba(255, 255, 255, 0.05);
            }

            .menu-toggle {
                display: flex;
            }

            .mobile-brand {
                display: none;
            }

            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding-top: 0.5rem;
            }

            .nav-menu.show {
                display: flex;
            }

            .nav-menu li {
                width: 100%;
                flex-direction: column;
            }

            .nav-menu a {
                padding: 0.6rem 2rem;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                border-bottom: none;
                border-left: 3px solid transparent;
            }

            .nav-menu a:hover, .nav-menu a.active {
                border-left-color: var(--nsti-magenta);
                border-bottom-color: transparent;
                background-color: rgba(255, 255, 255, 0.05);
            }

            .nav-menu .separator {
                display: none;
            }
        }

        /* Custom Dropdown Styling */
        .nav-menu .dropdown {
            position: relative;
        }

        .nav-menu .dropdown-toggle::after {
            display: none; /* Hide default bootstrap arrow */
        }

        /* Chevron Animation */
        .nav-menu .dropdown-toggle i {
            font-size: 0.75rem;
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            margin-left: 0.35rem;
        }

        /* Chevron Rotates when open or hovered */
        .nav-menu .dropdown:hover .dropdown-toggle i,
        .nav-menu .dropdown-toggle[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        .nav-menu .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%) translateY(15px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            background-color: #0b223e; /* Darker navy for contrast */
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 0.6rem 0;
            margin-top: 0;
            min-width: 220px;
            overflow: hidden;
            flex-direction: column;
            z-index: 1000;
        }

        .nav-menu .dropdown-menu li {
            display: block !important;
            width: 100% !important;
        }

        .nav-menu .dropdown-item {
            display: block !important;
            width: 100% !important;
            text-align: left;
            color: #ffffff !important;
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.75rem 1.6rem !important;
            border-left: 3px solid transparent !important;
            border-bottom: none !important; /* Remove any border from global menu styles */
            transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
            text-transform: capitalize;
        }

        /* Slide-out indent animation on hover */
        .nav-menu .dropdown-item:hover,
        .nav-menu .dropdown-item:focus,
        .nav-menu .dropdown-item.active {
            color: #ffe600 !important;
            background-color: var(--nsti-magenta) !important;
            border-left-color: #ffe600 !important;
            padding-left: 1.9rem !important; /* Subtle indentation */
        }

        /* Desktop Hover Behavior */
        @media (min-width: 769px) {
            .nav-menu .dropdown:hover .dropdown-menu {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateX(-50%) translateY(0) !important;
            }
            .nav-menu .dropdown-menu {
                display: flex !important;
                opacity: 0;
                visibility: hidden;
                transform: translateX(-50%) translateY(15px);
                transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
        }

        /* Mobile Responsive Dropdown Override */
        @media (max-width: 768px) {
            .nav-menu .dropdown {
                width: 100%;
                text-align: center;
            }
            .nav-menu .dropdown-toggle {
                width: 100%;
                justify-content: center;
            }
            .nav-menu .dropdown-menu {
                position: relative !important;
                left: auto !important;
                transform: none !important;
                float: none !important;
                width: 100% !important;
                background-color: rgba(0, 0, 0, 0.15) !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
                margin: 0 !important;
                padding: 0.5rem 0 !important;
                display: none !important;
            }
            .nav-menu .dropdown-menu.open {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
            }
            .nav-menu .dropdown-item {
                text-align: center;
                color: rgba(255, 255, 255, 0.8) !important;
                padding: 0.6rem 2rem !important;
                background: transparent !important;
                border-left: 3px solid transparent !important;
            }
            .nav-menu .dropdown-item:hover,
            .nav-menu .dropdown-item:focus,
            .nav-menu .dropdown-item.active {
                color: #ffe600 !important;
                border-left-color: var(--nsti-magenta) !important;
                background-color: rgba(255, 255, 255, 0.05) !important;
                padding-left: 2rem !important; /* Keep it consistent on mobile */
            }
        }

        /* Standalone page styling */
        .page-content-wrapper {
            flex: 1;
            padding: 4rem 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        .page-section-header {
            text-align: center;
            margin-bottom: 4rem;
        }

        .page-section-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--nsti-blue);
            text-transform: uppercase;
            position: relative;
            display: inline-block;
            padding-bottom: 0.75rem;
            margin-bottom: 0.5rem;
        }

        .page-section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 25%;
            width: 50%;
            height: 4px;
            background-color: var(--nsti-magenta);
            border-radius: 2px;
        }

        .page-section-subtitle {
            font-size: 1.1rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Committee Grid layout */
        .committee-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.5rem;
            margin-top: 1rem;
        }

        @media (max-width: 991px) {
            .committee-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 576px) {
            .committee-grid {
                grid-template-columns: 1fr;
            }
        }

        .committee-card {
            background-color: #ffffff;
            border-radius: 16px;
            border: 1px solid var(--card-border);
            padding: 2.5rem 1.5rem;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.02);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .committee-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background-color: var(--nsti-blue);
            transition: background-color 0.3s ease;
        }

        .committee-card:hover::before {
            background-color: var(--nsti-magenta);
        }

        .committee-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(15, 48, 87, 0.08);
            border-color: rgba(15, 48, 87, 0.15);
        }

        .committee-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: #f1f5f9;
            color: var(--nsti-blue);
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 1.5rem auto;
            font-size: 2.2rem;
            border: 3px solid #ffffff;
            box-shadow: 0 8px 20px rgba(15, 48, 87, 0.08);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }

        .committee-card:hover .committee-avatar {
            background-color: var(--nsti-magenta);
            color: #ffffff;
            border-color: var(--nsti-magenta);
            box-shadow: 0 10px 25px rgba(176, 28, 112, 0.25);
            transform: scale(1.05);
        }

        .committee-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center 12%;
            border-radius: 50%;
        }

        .committee-name {
            font-size: 1.15rem;
            font-weight: 700;
            color: var(--nsti-blue);
            margin: 0;
        }

        .committee-role {
            font-size: 0.82rem;
            font-weight: 700;
            color: var(--nsti-magenta);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-top: 0.4rem;
        }

        .committee-designation {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-top: 0;
            margin-bottom: 0;
            max-height: 0;
            opacity: 0;
            overflow: hidden;
            transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.4s ease, margin-top 0.4s ease;
        }

        .committee-card.show-description .committee-designation {
            max-height: 120px;
            opacity: 1;
            margin-top: 0.75rem;
        }

        .toggle-icon {
            font-size: 0.75rem;
            margin-left: 6px;
            transition: transform 0.3s ease;
            vertical-align: middle;
            opacity: 0.75;
        }

        .committee-card.show-description .toggle-icon {
            transform: rotate(180deg);
        }

        /* Site Footer */
        .site-footer {
            background-color: #0c1e35;
            color: #94a3b8;
            padding-top: 1.5rem;
            border-top: 5px solid var(--nsti-magenta);
            width: 100%;
        }

        .footer-watermark {
            background-color: #06101e;
            padding: 1.2rem 2rem;
            text-align: center;
        }

        .watermark-text {
            margin: 0;
            font-size: 0.85rem;
            color: #64748b;
        }

        /* Committee Marquee Styling */
        .committee-marquee-container {
            overflow: hidden;
            width: 100%;
            position: relative;
            padding: 1.5rem 0;
        }

        .committee-marquee-track {
            display: flex;
            width: max-content;
            animation: scroll-right-to-left 20s linear infinite;
        }

        .committee-marquee-group {
            display: flex;
            gap: 1.5rem;
            padding-right: 1.5rem;
        }

        .committee-marquee-group .committee-card {
            width: 270px;
            flex-shrink: 0;
        }

        /* Pause animation on hover */
        .committee-marquee-container:hover .committee-marquee-track {
            animation-play-state: paused;
        }

        @keyframes scroll-right-to-left {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(-50%);
            }
        }

        .custom-section-header-container {
            display: flex;
            justify-content: center;
            width: 100%;
            margin-top: 1rem;
            margin-bottom: 3rem;
        }
        .custom-section-header {
            display: flex;
            align-items: center;
            gap: 1.25rem;
        }
        .header-left-bar {
            width: 6px;
            height: 75px;
            background: linear-gradient(to bottom, #ff4e3a, #e61c5d); /* Red to pink gradient */
            border-radius: 3px;
        }
        .header-content-wrapper {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        .header-title-text {
            font-size: 2.2rem;
            font-weight: 800;
            color: #0f3057; /* Deep blue NSTI */
            line-height: 1.25;
            margin: 0;
            text-transform: none;
        }
        .header-bottom-line {
            width: 180px;
            height: 4px;
            background-color: #3b82f6; /* Blue underline */
            margin-top: 10px;
            border-radius: 2px;
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Top Header Branding Section -->
    <header class="header-branding">
        <a href="index.php" class="header-logo">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="78" height="78">
            <p class="logo-caption">National Skill Training Institute<span class="caption-location"> - Ramanthapur</span></p>
        </a>
        <div class="header-titles">
            <h1 class="main-title">NSTI R-HYDERABAD</h1>
            <h2 class="sub-title">Online Grievance Redressal System</h2>
        </div>
        <div class="header-right-logo d-none d-lg-flex">
            <img src="assets/images/committee_illustration.png" alt="Committee Illustration" style="height: 65px; width: auto; object-fit: contain;">
        </div>
    </header>

    <!-- Horizontal Navbar -->
    <nav class="custom-navbar">
        <div class="container navbar-container">
            <a href="index.php" class="mobile-brand">NSTI R-HYDERABAD</a>
            <button class="menu-toggle" id="mobile-menu-toggle" aria-label="Toggle Menu">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="index.php"><span class="notranslate custom-translate-home">Home</span></a></li>
                <li class="separator">|</li>
                <li><a href="about.php">About</a></li>
                <li class="separator">|</li>
                <li><a href="contact.php">Contact</a></li>
                <li class="separator">|</li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle active" id="grievanceDropdown" role="button" aria-expanded="false">
                        Help & Support <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="grievanceDropdown">
                        <li><a class="dropdown-item" href="check_status.php">Track Status</a></li>
                        <li><a class="dropdown-item" href="steps_to_lodge.php">Steps to Lodge</a></li>
                        <li><a class="dropdown-item active" href="team_members.php">Project Team</a></li>
                    </ul>
                </li>
                <li class="separator">|</li>
                <li><a href="feedback.php">Feedback</a></li>
                <li class="separator">|</li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Page Content Wrapper -->
    <main class="page-content-wrapper">
        <div class="custom-section-header-container">
            <div class="custom-section-header">
                <div class="header-left-bar"></div>
                <div class="header-content-wrapper">
                    <h2 class="header-title-text"><i class="fas fa-users" style="color: #2e7d32; margin-right: 12px; font-size: 0.9em; vertical-align: middle;"></i>Meet Our Team</h2>
                    <div class="header-bottom-line"></div>
                    <p class="page-section-subtitle" style="margin-top: 15px; margin-bottom: 0;">The Team behind NSTI R-Hyderabad's Online Grievance Cell Project</p>
                </div>
            </div>
        </div>

        <!-- Committee Member Cards Marquee (reused for developers) -->
        <div class="committee-marquee-container mb-4">
            <div class="committee-marquee-track">
                <!-- Group 1 -->
                <div class="committee-marquee-group">
                    <!-- Developer 1 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/team_leader.jpg" alt="Aakanksha Netam">
                        </div>
                        <h5 class="committee-name">Aakanksha Netam</h5>
                        <p class="committee-role">Team Leader <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Created a whole documentation for this project.</p>
                    </div>
                    
                    <!-- Developer 2 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/project_manager.png" alt="VIVEKANAND">
                        </div>
                        <h5 class="committee-name">VIVEKANAND</h5>
                        <p class="committee-role">Project Manager <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Full-Stack Developer & UI/UX Designer ensuring a seamless experience for the Online Grievance Redressal System.</p>
                    </div>

                    <!-- Developer 3 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/ui_designer.jpg" alt="V.Vaishnavi" style="object-position: center; object-fit: cover; transform: scale(1.2);">
                        </div>
                        <h5 class="committee-name">V.Vaishnavi</h5>
                        <p class="committee-role">UI/UX Designer <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Designing intuitive and user-centric interfaces to ensure a seamless navigation experience.</p>
                    </div>

                    <!-- Developer 4 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/deenu_ram.jpg" alt="DEENU RAM">
                        </div>
                        <h5 class="committee-name">DEENU RAM</h5>
                        <p class="committee-role">UI/UX Designer <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Crafting high-fidelity UI designs and interactive mockups to optimize user satisfaction.</p>
                    </div>
                </div>

                <!-- Group 2 (duplicate for seamless loop) -->
                <div class="committee-marquee-group">
                    <!-- Developer 1 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/team_leader.jpg" alt="Aakanksha Netam">
                        </div>
                        <h5 class="committee-name">Aakanksha Netam</h5>
                        <p class="committee-role">Team Leader <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Created a whole documentation for this project.</p>
                    </div>
                    
                    <!-- Developer 2 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/project_manager.png" alt="VIVEKANAND">
                        </div>
                        <h5 class="committee-name">VIVEKANAND</h5>
                        <p class="committee-role">Project Manager <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Full-Stack Developer & UI/UX Designer ensuring a seamless experience for the Online Grievance Redressal System.</p>
                    </div>

                    <!-- Developer 3 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/ui_designer.jpg" alt="V.Vaishnavi" style="object-position: center; object-fit: cover; transform: scale(1.2);">
                        </div>
                        <h5 class="committee-name">V.Vaishnavi</h5>
                        <p class="committee-role">UI/UX Designer <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Designing intuitive and user-centric interfaces to ensure a seamless navigation experience.</p>
                    </div>

                    <!-- Developer 4 -->
                    <div class="committee-card">
                        <div class="committee-avatar">
                            <img src="assets/images/deenu_ram.jpg" alt="DEENU RAM">
                        </div>
                        <h5 class="committee-name">DEENU RAM</h5>
                        <p class="committee-role">UI/UX Designer <i class="fas fa-chevron-down toggle-icon"></i></p>
                        <p class="committee-designation">Crafting high-fidelity UI designs and interactive mockups to optimize user satisfaction.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
                    <div class="footer-watermark">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <p class="watermark-text mb-0 text-center text-md-start" style="font-size: 0.85rem;">&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</p>
            <div class="d-flex justify-content-center justify-content-md-end align-items-center" style="font-size: 0.75rem; color: #64748b; padding: 5px 0;">
    <span style="opacity: 0.7; margin-right: 4px;">Developed By:</span>
    <span style="color: rgba(255,255,255,0.7); font-weight: 400;">Vivekanand & Aakanksha</span>
</div>
        </div>
    </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle team member card description on click
        document.querySelectorAll('.committee-card').forEach(card => {
            card.setAttribute('tabindex', '0');
            card.setAttribute('role', 'button');
            card.setAttribute('aria-expanded', 'false');

            const toggleDesc = () => {
                const isExpanded = card.classList.toggle('show-description');
                card.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
            };

            card.addEventListener('click', toggleDesc);
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleDesc();
                }
            });
        });
    </script>
    
    <!-- Mobile Navigation Toggle -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const toggleBtn = document.getElementById("mobile-menu-toggle");
            const navMenu = document.getElementById("navMenu");
            
            if (toggleBtn && navMenu) {
                toggleBtn.addEventListener("click", function() {
                    navMenu.classList.toggle("show");
                    const icon = toggleBtn.querySelector("i");
                    if (icon) {
                        if (navMenu.classList.contains("show")) {
                            icon.classList.remove("fa-bars");
                            icon.classList.add("fa-times");
                        } else {
                            icon.classList.remove("fa-times");
                            icon.classList.add("fa-bars");
                            
                            // Reset all dropdowns when menu is closed
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    }
                });

                // Close menu when clicking a link
                const navLinks = document.querySelectorAll(".nav-menu a");
                navLinks.forEach(link => {
                    link.addEventListener("click", () => {
                        if (!link.classList.contains("dropdown-toggle")) {
                            navMenu.classList.remove("show");
                            const icon = toggleBtn.querySelector("i");
                            if (icon) {
                                icon.classList.remove("fa-times");
                                icon.classList.add("fa-bars");
                            }
                            // Reset all dropdowns
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    });
                });

                // Dropdown toggle on mobile (prevents Bootstrap Popper conflicts)
                const dropdownToggles = document.querySelectorAll(".nav-menu .dropdown-toggle");
                dropdownToggles.forEach(toggle => {
                    toggle.addEventListener("click", function(e) {
                        const isMobile = window.getComputedStyle(toggleBtn).display !== "none";
                        if (isMobile) {
                            e.preventDefault();
                            e.stopPropagation();
                            const dropdownMenu = this.nextElementSibling;
                            if (dropdownMenu) {
                                const isShown = dropdownMenu.classList.toggle("open");
                                this.setAttribute("aria-expanded", isShown ? "true" : "false");
                            }
                        }
                    });
                });
            }
        });
    </script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>




















