<?php
function downloadImage($url, $path) {
    $options = [
        "http" => [
            "method" => "GET",
            "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
        ],
        "ssl" => [
            "verify_peer" => false,
            "verify_peer_name" => false,
        ]
    ];
    $context = stream_context_create($options);
    $data = file_get_contents($url, false, $context);
    
    if ($data) {
        file_put_contents($path, $data);
        echo "Successfully downloaded $url to $path\n";
    } else {
        echo "Failed to download $url\n";
    }
}

downloadImage('https://www.india.gov.in/sites/upload_files/npi/files/logo_1.png', 'assets/images/govt_emblem.png');
downloadImage('https://amritmahotsav.nic.in/writereaddata/portal/images/logo-black.png', 'assets/images/amrit_mahotsav.png');
