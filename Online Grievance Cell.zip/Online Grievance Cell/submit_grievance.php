<?php
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit a Grievance - NSTI R-Hyderabad</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-base: #f7f9fc;
            --nsti-blue: #0f3057;
            --nsti-magenta: #b01c70;
            --text-dark: #2d3748;
            --text-muted: #718096;
            --card-border: rgba(0, 0, 0, 0.06);
            --bg-light: #ffffff;
        }

        body, html {
            margin: 0;
            padding: 0;
            scroll-behavior: smooth;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Header Branding Section */
                        .header-branding {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 1rem;
            width: 100%;
            padding: 1rem 2rem;
        }





        .header-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            justify-self: start;
        }


        .header-logo img {
            width: 110px;
            height: auto;
            object-fit: contain;
        }

        .logo-caption {
            margin: 0;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--nsti-blue);
            text-align: center;
            white-space: nowrap;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-top: 2px solid var(--nsti-magenta);
            padding: 0.4rem 0.5rem 0 0.5rem;
        }

        .logo-caption .caption-location {
            color: var(--nsti-magenta);
            font-weight: 800;
        }

        .header-titles {
            text-align: center;
            justify-self: center;
        }





        .header-titles .main-title {
            font-size: 3.8rem;
            font-weight: 900;
            color: var(--nsti-blue);
            margin: 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .header-titles .sub-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--nsti-magenta);
            margin: 0.25rem 0 0 0;
            white-space: nowrap;
        }

        .header-right-logo {
            justify-self: end;
        }


        @media (max-width: 1400px) {
            .header-titles .main-title { font-size: 3.2rem; }
            .header-titles .sub-title { font-size: 1.8rem; }
            .header-branding { padding: 1rem; }
        }

        @media (max-width: 1200px) {
            .header-titles .main-title { font-size: 2.8rem; }
            .header-titles .sub-title { font-size: 1.6rem; }
        }

        @media (max-width: 991px) {
            .header-branding {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
                text-align: center;
                padding: 1rem;
            }
            .header-titles .main-title {
                font-size: 2.8rem;
                white-space: nowrap;
            }
            .header-titles .sub-title {
                font-size: 1.6rem;
                white-space: nowrap;
                margin-top: 0.25rem;
            }
        }
        
        @media (max-width: 576px) {
            .header-titles .main-title {
                font-size: 2.2rem;
                white-space: normal;
                line-height: 1.2;
            }
            .header-titles .sub-title {
                font-size: 1.4rem;
                white-space: normal;
                line-height: 1.3;
            }
        }

        /* Navigation Bar Styles */
        .custom-navbar {
            background-color: var(--nsti-blue);
            box-shadow: 0 4px 15px rgba(15, 48, 87, 0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            transition: all 0.3s ease;
        }

        .menu-toggle {
            display: none;
            background: transparent;
            border: none;
            color: #ffffff;
            font-size: 1.35rem;
            cursor: pointer;
            padding: 0.5rem;
            align-items: center;
            justify-content: center;
        }

        .mobile-brand {
            display: none;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.95rem;
            text-transform: uppercase;
            text-decoration: none;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            justify-content: center;
            list-style: none;
            flex-wrap: wrap;
            margin: 0;
            padding: 0;
        }

        .nav-menu li {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            color: #ffffff;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.9rem 1.2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            text-transform: capitalize;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #ffe600;
            border-bottom-color: var(--nsti-magenta);
        }

        .nav-menu .separator {
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.9rem;
            user-select: none;
        }

        @media (max-width: 768px) {
            .navbar-container {
                justify-content: flex-end;
                flex-wrap: wrap;
                padding: 0.5rem 1rem;
                background-color: rgba(255, 255, 255, 0.05);
            }

            .menu-toggle {
                display: flex;
            }

            .mobile-brand {
                display: none;
            }

            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding-top: 0.5rem;
            }

            .nav-menu.show {
                display: flex;
            }

            .nav-menu li {
                width: 100%;
                flex-direction: column;
            }

            .nav-menu a {
                padding: 0.6rem 2rem;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                border-bottom: none;
                border-left: 3px solid transparent;
            }

            .nav-menu a:hover, .nav-menu a.active {
                border-left-color: var(--nsti-magenta);
                border-bottom-color: transparent;
                background-color: rgba(255, 255, 255, 0.05);
            }

            .nav-menu .separator {
                display: none;
            }
        }

        /* Custom Dropdown Styling */
        .nav-menu .dropdown {
            position: relative;
        }

        .nav-menu .dropdown-toggle::after {
            display: none;
        }

        /* Chevron Animation */
        .nav-menu .dropdown-toggle i {
            font-size: 0.75rem;
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            margin-left: 0.35rem;
        }

        .nav-menu .dropdown:hover .dropdown-toggle i,
        .nav-menu .dropdown-toggle[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        .nav-menu .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%) translateY(15px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            background-color: #0b223e;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 0.6rem 0;
            margin-top: 0;
            min-width: 220px;
            overflow: hidden;
            flex-direction: column;
            z-index: 1000;
        }

        .nav-menu .dropdown-menu li {
            display: block !important;
            width: 100% !important;
        }

        .nav-menu .dropdown-item {
            display: block !important;
            width: 100% !important;
            text-align: left;
            color: #ffffff !important;
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.75rem 1.6rem !important;
            border-left: 3px solid transparent !important;
            border-bottom: none !important;
            transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
            text-transform: capitalize;
        }

        .nav-menu .dropdown-item:hover,
        .nav-menu .dropdown-item:focus,
        .nav-menu .dropdown-item.active {
            color: #ffe600 !important;
            background-color: var(--nsti-magenta) !important;
            border-left-color: #ffe600 !important;
            padding-left: 1.9rem !important;
        }

        @media (min-width: 769px) {
            .nav-menu .dropdown:hover .dropdown-menu {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateX(-50%) translateY(0) !important;
            }
            .nav-menu .dropdown-menu {
                display: flex !important;
                opacity: 0;
                visibility: hidden;
                transform: translateX(-50%) translateY(15px);
                transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
        }

        @media (max-width: 768px) {
            .nav-menu .dropdown {
                width: 100%;
                text-align: center;
            }
            .nav-menu .dropdown-toggle {
                width: 100%;
                justify-content: center;
            }
            .nav-menu .dropdown-menu {
                position: relative !important;
                left: auto !important;
                transform: none !important;
                float: none !important;
                width: 100% !important;
                background-color: rgba(0, 0, 0, 0.15) !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
                margin: 0 !important;
                padding: 0.5rem 0 !important;
                display: none !important;
            }
            .nav-menu .dropdown-menu.open {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
            }
            .nav-menu .dropdown-item {
                text-align: center;
                color: rgba(255, 255, 255, 0.8) !important;
                padding: 0.6rem 2rem !important;
                background: transparent !important;
                border-left: 3px solid transparent !important;
            }
            .nav-menu .dropdown-item:hover,
            .nav-menu .dropdown-item:focus,
            .nav-menu .dropdown-item.active {
                color: #ffe600 !important;
                border-left-color: var(--nsti-magenta) !important;
                background-color: rgba(255, 255, 255, 0.05) !important;
                padding-left: 2rem !important;
            }
        }

        /* Standalone page styling */
        .page-content-wrapper {
            flex: 1;
            padding: 4rem 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        .page-section-header {
            text-align: center;
            margin-bottom: 3.5rem;
        }

        .page-section-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--nsti-blue);
            text-transform: uppercase;
            position: relative;
            display: inline-block;
            padding-bottom: 0.75rem;
            margin-bottom: 0.5rem;
        }

        .page-section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 25%;
            width: 50%;
            height: 4px;
            background-color: var(--nsti-magenta);
            border-radius: 2px;
        }

        .page-section-subtitle {
            font-size: 1.1rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Role Selector Cards styling */
        .role-selector-card {
            border-radius: 28px;
            padding: 3rem 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            height: 100%;
            text-decoration: none;
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 1;
        }

        .role-selector-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 60%);
            opacity: 0;
            transition: opacity 0.5s ease;
            z-index: -1;
            pointer-events: none;
        }

        .role-selector-card:hover::before {
            opacity: 1;
        }

        .role-selector-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .role-bg-student { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); }
        .role-bg-staff { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .role-bg-parent { background: linear-gradient(135deg, #db2777 0%, #be185d 100%); }
        .role-bg-admin { background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%); }

        .role-avatar-circle {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.95);
            border: 6px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15), inset 0 4px 8px rgba(0,0,0,0.05);
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 2rem;
            overflow: hidden;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            backdrop-filter: blur(5px);
        }

        .role-selector-card:hover .role-avatar-circle {
            transform: scale(1.08) translateY(-5px);
            border-color: rgba(255, 255, 255, 0.6);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2), inset 0 4px 10px rgba(0,0,0,0.05);
        }

        .role-pill-btn {
            color: #ffffff !important;
            font-weight: 700;
            font-size: 1.05rem;
            letter-spacing: 0.5px;
            padding: 0.8rem 3rem;
            border-radius: 30px;
            text-transform: uppercase;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.4);
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }

        .role-selector-card:hover .role-pill-btn {
            transform: translateY(-3px) scale(1.02);
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.6);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.2);
            color: #ffffff !important;
        }

        .btn-pill-student { /* Managed by global */ }
        .btn-pill-staff { /* Managed by global */ }
        .btn-pill-parent { /* Managed by global */ }
        .btn-pill-admin { /* Managed by global */ }

        .grievance-card {
            background-color: #ffffff;
            border-radius: 12px;
            border: 1px solid var(--card-border);
            padding: 2rem 1.5rem;
            text-align: center;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.015);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .grievance-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(15, 48, 87, 0.08);
            border-color: rgba(15, 48, 87, 0.15);
        }

        .grievance-card::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 4px;
            background-color: var(--nsti-magenta);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .grievance-card:hover::after {
            transform: scaleX(1);
        }

        .icon-circle {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 1.25rem;
            transition: transform 0.3s ease;
        }

        .grievance-card:hover .icon-circle {
            transform: scale(1.06);
        }

        .circle-status { background-color: #fae8ff; color: #c084fc; }

        .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--nsti-blue);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
        }

        .card-description {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin: 0;
            line-height: 1.5;
        }

        /* Site Footer */
        .site-footer {
            background-color: #0c1e35;
            color: #94a3b8;
            padding-top: 1.5rem;
            border-top: 5px solid var(--nsti-magenta);
            width: 100%;
        }

        .footer-watermark {
            background-color: #06101e;
            padding: 1.2rem 2rem;
            text-align: center;
        }

        .watermark-text {
            margin: 0;
            font-size: 0.85rem;
            color: #64748b;
        }

        /* Premium Status Tracker Card */
        .status-tracker-card {
            background: linear-gradient(135deg, #0f3057 0%, #b01c70 100%);
            border-radius: 20px;
            padding: 3rem 2.5rem;
            text-align: center;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 12px 30px rgba(176, 28, 112, 0.15);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        /* Ambient glowing background blur effect */
        .status-tracker-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 230, 0, 0.15) 0%, transparent 60%);
            opacity: 0;
            transition: opacity 0.5s ease;
            z-index: -1;
            pointer-events: none;
        }

        .status-tracker-card:hover::before {
            opacity: 1;
        }

        .status-tracker-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 45px rgba(176, 28, 112, 0.35);
            border-color: rgba(255, 230, 0, 0.4);
        }

        .status-tracker-card .icon-wrapper-glowing {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.25);
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 1.5rem;
            color: #ffe600; /* Neon yellow/gold */
            box-shadow: 0 8px 25px rgba(255, 230, 0, 0.15);
            transition: all 0.4s ease;
        }

        .status-tracker-card:hover .icon-wrapper-glowing {
            background-color: #ffe600;
            color: #0f3057;
            border-color: #ffe600;
            box-shadow: 0 10px 30px rgba(255, 230, 0, 0.45);
            transform: scale(1.1) rotate(10deg);
        }

        .status-tracker-card .tracker-title {
            font-size: 1.45rem;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 0.6rem;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            transition: color 0.3s ease;
        }

        .status-tracker-card:hover .tracker-title {
            color: #ffe600;
        }

        .status-tracker-card .tracker-description {
            font-size: 0.95rem;
            color: #cbd5e1;
            line-height: 1.6;
            margin-bottom: 1.5rem;
            max-width: 480px;
        }

        .status-tracker-card .tracker-btn {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1.5px solid rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 700;
            padding: 0.6rem 2.2rem;
            border-radius: 30px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .status-tracker-card:hover .tracker-btn {
            background-color: #ffffff;
            color: #0f3057;
            border-color: #ffffff;
            box-shadow: 0 8px 20px rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Top Header Branding Section -->
    <header class="header-branding">
        <a href="index.php" class="header-logo">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="78" height="78">
            <p class="logo-caption">National Skill Training Institute<span class="caption-location"> - Ramanthapur</span></p>
        </a>
        <div class="header-titles">
            <h1 class="main-title">NSTI R-HYDERABAD</h1>
            <h2 class="sub-title">Online Grievance Redressal System</h2>
        </div>
        <div class="header-right-logo d-none d-lg-flex">
            <img src="assets/images/committee_illustration.png" alt="Committee Illustration" style="height: 65px; width: auto; object-fit: contain;">
        </div>
    </header>

    <!-- Horizontal Navbar -->
    <nav class="custom-navbar">
        <div class="container navbar-container">
            <a href="index.php" class="mobile-brand">NSTI R-HYDERABAD</a>
            <button class="menu-toggle" id="mobile-menu-toggle" aria-label="Toggle Menu">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="index.php"><span class="notranslate custom-translate-home">Home</span></a></li>
                <li class="separator">|</li>
                <li><a href="about.php">About</a></li>
                <li class="separator">|</li>
                <li><a href="contact.php">Contact</a></li>
                <li class="separator">|</li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle active" id="grievanceDropdown" role="button" aria-expanded="false">
                        Help & Support <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="grievanceDropdown">
                        <li><a class="dropdown-item" href="check_status.php">Track Status</a></li>
                        <li><a class="dropdown-item" href="steps_to_lodge.php">Steps to Lodge</a></li>
                        <li><a class="dropdown-item" href="team_members.php">Project Team</a></li>
                    </ul>
                </li>
                <li class="separator">|</li>
                <li><a href="feedback.php">Feedback</a></li>
                <li class="separator">|</li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Page Content Wrapper -->
    <main class="page-content-wrapper">
        <div class="page-section-header">
            <h1 class="page-section-title">Submit a Grievance</h1>
            <p class="page-section-subtitle">Please select your role to proceed to log your complaint</p>
        </div>

        <!-- Role Selector Grid -->
        <div class="row justify-content-center g-4 mb-5">
            <!-- Student Card -->
            <div class="col-lg-3 col-md-6">
                <a href="login.php?role=student" class="role-selector-card role-bg-student">
                    <div class="role-avatar-circle">
                        <svg width="102" height="102" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="48" fill="#ffb74d"/>
                            <path d="M15,80 C15,68 25,62 32,62 C34,62 36,63 38,64 C35,68 35,74 38,78" fill="#e53935"/>
                            <circle cx="28" cy="46" r="8" fill="#ffcc80"/>
                            <polygon points="28,34 38,39 28,44 18,39" fill="#37474f"/>
                            <path d="M85,80 C85,68 75,62 68,62 C66,62 64,63 62,64 C65,68 65,74 62,78" fill="#e53935"/>
                            <circle cx="72" cy="46" r="8" fill="#ffcc80"/>
                            <polygon points="72,34 82,39 72,44 62,39" fill="#37474f"/>
                            <path d="M22,88 C22,72 35,66 50,66 C65,66 78,72 78,88 Z" fill="#008080"/>
                            <rect x="46" y="54" width="8" height="15" fill="#ffe082"/>
                            <circle cx="50" cy="44" r="14" fill="#ffe082"/>
                            <path d="M36,44 C36,32 64,32 64,44 C64,48 60,48 58,46 Q50,42 42,46 C40,48 36,48 36,44" fill="#263238"/>
                            <polygon points="50,22 72,30 50,38 28,30" fill="#37474f"/>
                            <polygon points="46,36 46,50 50,48" fill="#ffe082"/>
                            <rect x="70" y="30" width="2" height="12" fill="#ffb300"/>
                            <circle cx="71" cy="42" r="2" fill="#ffb300"/>
                        </svg>
                    </div>
                    <span class="role-pill-btn btn-pill-student">Student</span>
                </a>
            </div>

            <!-- Staff Card -->
            <div class="col-lg-3 col-md-6">
                <a href="login.php?role=staff" class="role-selector-card role-bg-staff">
                    <div class="role-avatar-circle">
                        <svg width="102" height="102" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="48" fill="#4fc3f7"/>
                            <path d="M15,80 C15,66 28,62 35,62" fill="#37474f"/>
                            <circle cx="28" cy="45" r="8" fill="#ffe082"/>
                            <path d="M22,39 Q28,33 34,39" fill="#263238" stroke="#263238" stroke-width="2"/>
                            <path d="M85,80 C85,66 72,62 65,62" fill="#e53935"/>
                            <circle cx="72" cy="45" r="8" fill="#ffe082"/>
                            <path d="M66,39 Q72,33 78,39" fill="#d81b60" stroke="#d81b60" stroke-width="2"/>
                            <path d="M22,88 C22,70 34,64 50,64 C66,64 78,70 78,88 Z" fill="#2d3748"/>
                            <rect x="46" y="56" width="8" height="15" fill="#ffe082"/>
                            <circle cx="50" cy="44" r="13" fill="#ffe082"/>
                            <path d="M37,42 C37,30 63,30 63,42 Q50,34 37,42" fill="#1a202c"/>
                            <polygon points="42,64 58,64 50,72" fill="#ffffff"/>
                            <polygon points="48,70 52,70 54,88 46,88" fill="#00b0ff"/>
                        </svg>
                    </div>
                    <span class="role-pill-btn btn-pill-staff">Staff / Faculty</span>
                </a>
            </div>

            <!-- Parent Card -->
            <div class="col-lg-3 col-md-6">
                <a href="login.php?role=parent" class="role-selector-card role-bg-parent">
                    <div class="role-avatar-circle">
                        <svg width="102" height="102" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="48" fill="#f472b6"/>
                            <path d="M12,88 C12,72 24,66 38,66 C48,66 52,72 54,88 Z" fill="#0066cc"/>
                            <circle cx="32" cy="44" r="11" fill="#ffe082"/>
                            <path d="M22,42 C22,34 42,34 42,42" fill="#2d3748"/>
                            <path d="M46,88 C46,74 56,68 70,68 C84,68 88,74 88,88 Z" fill="#ff9900"/>
                            <circle cx="68" cy="46" r="11" fill="#ffe082"/>
                            <path d="M58,46 C58,34 78,34 78,46" fill="#800000"/>
                        </svg>
                    </div>
                    <span class="role-pill-btn btn-pill-parent">Parent</span>
                </a>
            </div>

            <!-- Admin Card -->
            <div class="col-lg-3 col-md-6">
                <a href="login.php?role=admin" class="role-selector-card role-bg-admin">
                    <div class="role-avatar-circle">
                        <svg width="102" height="102" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="48" fill="#c084fc"/>
                            <path d="M50,18 L76,28 L76,54 C76,68 64,78 50,82 C36,78 24,68 24,54 L24,28 Z" fill="#581c87"/>
                            <path d="M50,25 L70,33 L70,54 C70,64 60,73 50,76 C40,73 30,64 30,54 L30,33 Z" fill="#ffffff"/>
                            <circle cx="50" cy="42" r="7" fill="#581c87"/>
                            <path d="M38,62 C38,54 43,50 50,50 C57,50 62,54 62,62 Z" fill="#581c87"/>
                        </svg>
                    </div>
                    <span class="role-pill-btn btn-pill-admin">Admin</span>
                </a>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
                    <div class="footer-watermark">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <p class="watermark-text mb-0 text-center text-md-start" style="font-size: 0.85rem;">&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</p>
            <div class="d-flex justify-content-center justify-content-md-end align-items-center" style="font-size: 0.75rem; color: #64748b; padding: 5px 0;">
    <span style="opacity: 0.7; margin-right: 4px;">Developed By:</span>
    <span style="color: rgba(255,255,255,0.7); font-weight: 400;">Vivekanand & Aakanksha</span>
</div>
        </div>
    </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Mobile Navigation Toggle -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const toggleBtn = document.getElementById("mobile-menu-toggle");
            const navMenu = document.getElementById("navMenu");
            
            if (toggleBtn && navMenu) {
                toggleBtn.addEventListener("click", function() {
                    navMenu.classList.toggle("show");
                    const icon = toggleBtn.querySelector("i");
                    if (icon) {
                        if (navMenu.classList.contains("show")) {
                            icon.classList.remove("fa-bars");
                            icon.classList.add("fa-times");
                        } else {
                            icon.classList.remove("fa-times");
                            icon.classList.add("fa-bars");
                            
                            // Reset all dropdowns when menu is closed
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    }
                });

                // Close menu when clicking a link
                const navLinks = document.querySelectorAll(".nav-menu a");
                navLinks.forEach(link => {
                    link.addEventListener("click", () => {
                        if (!link.classList.contains("dropdown-toggle")) {
                            navMenu.classList.remove("show");
                            const icon = toggleBtn.querySelector("i");
                            if (icon) {
                                icon.classList.remove("fa-times");
                                icon.classList.add("fa-bars");
                            }
                            // Reset all dropdowns
                            const dropdownMenus = navMenu.querySelectorAll(".dropdown-menu");
                            dropdownMenus.forEach(menu => menu.classList.remove("open"));
                            const dropdownToggles = navMenu.querySelectorAll(".dropdown-toggle");
                            dropdownToggles.forEach(t => t.setAttribute("aria-expanded", "false"));
                        }
                    });
                });

                // Dropdown toggle on mobile (prevents Bootstrap Popper conflicts)
                const dropdownToggles = document.querySelectorAll(".nav-menu .dropdown-toggle");
                dropdownToggles.forEach(toggle => {
                    toggle.addEventListener("click", function(e) {
                        const isMobile = window.getComputedStyle(toggleBtn).display !== "none";
                        if (isMobile) {
                            e.preventDefault();
                            e.stopPropagation();
                            const dropdownMenu = this.nextElementSibling;
                            if (dropdownMenu) {
                                const isShown = dropdownMenu.classList.toggle("open");
                                this.setAttribute("aria-expanded", isShown ? "true" : "false");
                            }
                        }
                    });
                });
            }
        });
    </script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>




















