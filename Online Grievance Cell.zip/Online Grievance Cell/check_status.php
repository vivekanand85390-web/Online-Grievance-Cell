﻿<?php
include_once 'includes/functions.php';

// â”€â”€ AJAX endpoint for home page live tracker â”€â”€
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json');
    $gid = isset($_GET['grievance_id']) ? trim($_GET['grievance_id']) : '';
    if (empty($gid)) {
        echo json_encode(['found' => false]);
        exit;
    }
    $stmt = $pdo->prepare("SELECT g.complaint_id, g.status, g.created_at, g.updated_at, c.name as category
                           FROM grievances g
                           JOIN categories c ON g.category_id = c.id
                           WHERE g.complaint_id = ?");
    $stmt->execute([$gid]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['found' => false]);
        exit;
    }
    echo json_encode([
        'found'        => true,
        'grievance_id' => $row['complaint_id'],
        'status'       => $row['status'],
        'category'     => $row['category'],
        'submitted_on' => date('d M Y', strtotime($row['created_at'])),
        'updated_on'   => date('d M Y, h:i A', strtotime($row['updated_at'])),
    ]);
    exit;
}
// â”€â”€ End AJAX â”€â”€

$complaint_id = '';
$contact = '';
$grievance = null;
$updates = [];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $complaint_id = sanitize($_POST['complaint_id']);
    $contact = sanitize($_POST['contact']);

    if (empty($complaint_id) || empty($contact)) {
        $error = 'Please enter both Grievance ID and Registered Phone Number.';
    } else {
        // Query grievance details
        $stmt = $pdo->prepare("SELECT g.*, u.name as complainant_name, u.contact, c.name as category 
                               FROM grievances g 
                               JOIN users u ON g.user_id = u.id 
                               JOIN categories c ON g.category_id = c.id 
                               WHERE g.complaint_id = ? AND u.contact = ?");
        $stmt->execute([$complaint_id, $contact]);
        $grievance = $stmt->fetch();

        if (!$grievance) {
            $error = 'No grievance found matching this ID and Phone Number. Please check your inputs.';
        } else {
            // Fetch updates/timeline
            $stmt_updates = $pdo->prepare("SELECT gu.*, u.name as updater_name, u.role as updater_role 
                                           FROM grievance_updates gu 
                                           JOIN users u ON gu.updated_by = u.id 
                                           WHERE gu.grievance_id = ? 
                                           ORDER BY gu.created_at ASC");
            $stmt_updates->execute([$grievance['id']]);
            $updates = $stmt_updates->fetchAll();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Grievance Status - Online Grievance Cell</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-base: #f5f7fb;
            --nsti-blue: #0f3057;
            --nsti-blue-glow: rgba(15, 48, 87, 0.12);
            --nsti-magenta: #b01c70;
            --nsti-magenta-glow: rgba(176, 28, 112, 0.12);
            
            --text-dark: #1e293b;
            --text-muted: #64748b;
            
            --success-color: #10b981;
            --success-bg: rgba(16, 185, 129, 0.08);
            --warning-color: #f59e0b;
            --warning-bg: rgba(245, 158, 11, 0.08);
            --danger-color: #ef4444;
            --danger-bg: rgba(239, 68, 68, 0.08);
            --info-color: #3b82f6;
            --info-bg: rgba(59, 130, 246, 0.08);
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            background-image: 
                radial-gradient(at 0% 0%, rgba(15, 48, 87, 0.03) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(176, 28, 112, 0.03) 0px, transparent 50%),
                radial-gradient(at 50% 100%, rgba(99, 102, 241, 0.02) 0px, transparent 50%);
            min-height: 100vh;
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .custom-navbar {
            padding: 1.1rem 5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(15, 48, 87, 0.05);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }

        .logo-text {
            font-weight: 800;
            font-size: 1.35rem;
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-links .btn-home {
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            color: #ffffff !important;
            padding: 0.6rem 1.6rem;
            border-radius: 2rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(176, 28, 112, 0.2);
            display: inline-flex;
            align-items: center;
            font-size: 0.95rem;
        }

        .nav-links .btn-home:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(176, 28, 112, 0.35);
        }

        .main-container {
            flex: 1;
            padding: 3.5rem 1.5rem;
            max-width: 920px;
            margin: 0 auto;
            width: 100%;
        }

        .status-card-search {
            background: #ffffff;
            border-radius: 24px;
            border: 1px solid rgba(15, 48, 87, 0.08);
            box-shadow: 0 12px 40px rgba(15, 48, 87, 0.05);
            padding: 3.5rem 2.5rem;
            margin-bottom: 2.5rem;
            position: relative;
            overflow: hidden;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            z-index: 1;
        }

        .status-card-search::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
        }

        .status-card-search:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 45px rgba(15, 48, 87, 0.08);
        }

        .status-card-results {
            background: #ffffff;
            border-radius: 24px;
            border: 1px solid rgba(15, 48, 87, 0.08);
            box-shadow: 0 12px 40px rgba(15, 48, 87, 0.05);
            padding: 3rem 2.5rem;
            margin-bottom: 2.5rem;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .status-card-results::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
        }

        /* Mockup Top Header Styles */
        .status-header-icon-wrapper {
            display: flex;
            justify-content: center;
            margin-bottom: 1.5rem;
        }

        .status-card-search .status-header-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            border: none;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #ffffff;
            font-size: 2rem;
            transition: all 0.4s ease;
            box-shadow: 0 10px 25px rgba(176, 28, 112, 0.2);
        }

        .status-card-search:hover .status-header-icon {
            transform: scale(1.05);
            box-shadow: 0 15px 30px rgba(176, 28, 112, 0.3);
        }

        .status-card-search .form-title {
            font-size: 2rem;
            font-weight: 800;
            color: var(--nsti-blue);
            text-align: center;
            margin-bottom: 0.5rem;
            letter-spacing: 0px;
            text-transform: none;
        }

        .status-card-search .form-subtitle {
            color: var(--text-muted);
            text-align: center;
            margin-bottom: 2.5rem;
            font-size: 1.05rem;
            font-weight: 400;
        }

        .status-card-search .form-label {
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #475569;
            margin-bottom: 0.75rem;
            display: block;
        }

        .input-group-custom {
            position: relative;
        }

        .status-card-search .form-control-custom {
            width: 100%;
            height: 54px;
            padding: 10px 16px 10px 48px;
            font-size: 1rem;
            font-weight: 500;
            color: #1e293b;
            background-color: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .status-card-search .form-control-custom::placeholder {
            color: #94a3b8;
            font-weight: 400;
        }

        .status-card-search .form-control-custom:focus {
            outline: none;
            border-color: var(--nsti-blue);
            background-color: #ffffff;
            box-shadow: 0 0 0 4px rgba(15, 48, 87, 0.1);
        }

        .status-card-search .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            transition: color 0.3s ease;
            pointer-events: none;
            font-size: 1.1rem;
        }

        .status-card-search .form-control-custom:focus ~ .input-icon {
            color: var(--nsti-blue);
        }

        .status-card-search .btn-track {
            background: linear-gradient(135deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            color: #ffffff !important;
            border: none;
            border-radius: 12px;
            padding: 1.1rem;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 0.5px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 8px 20px rgba(15, 48, 87, 0.15);
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.6rem;
            cursor: pointer;
        }

        .status-card-search .btn-track:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(15, 48, 87, 0.25);
        }

        .status-card-search .btn-track:active {
            transform: translateY(0);
        }

        /* Results styling */
        .result-header {
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 1.5rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .result-id {
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--nsti-blue);
            margin: 0;
        }

        .btn-copy {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 1.15rem;
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            transition: all 0.2s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-copy:hover {
            color: var(--nsti-blue);
            background-color: var(--nsti-blue-glow);
        }

        .btn-copy:active {
            transform: scale(0.9);
        }

        /* Beautiful Stepper Progress */
        .step-tracker {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 3.5rem 0;
            position: relative;
        }

        .step-tracker::before {
            content: '';
            position: absolute;
            height: 6px;
            background: #e2e8f0;
            top: 27px;
            left: 12.5%;
            right: 12.5%;
            z-index: 1;
            border-radius: 3px;
        }

        .step-progress {
            content: '';
            position: absolute;
            height: 6px;
            background: linear-gradient(90deg, var(--nsti-blue) 0%, var(--nsti-magenta) 100%);
            top: 27px;
            left: 12.5%;
            z-index: 1;
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            border-radius: 3px;
        }

        .step-item {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 25%;
        }

        .step-icon {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            background: #ffffff;
            border: 3px solid #e2e8f0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.25rem;
            color: var(--text-muted);
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);
            position: relative;
        }

        .step-item.active .step-icon {
            border-color: var(--nsti-blue);
            background: var(--nsti-blue);
            color: #ffffff;
            box-shadow: 0 0 0 6px var(--nsti-blue-glow), 0 8px 15px rgba(15, 48, 87, 0.2);
            transform: scale(1.1);
        }

        .step-item.active .step-icon::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 3px solid var(--nsti-blue);
            animation: pulse-ring 1.8s infinite;
            z-index: -1;
        }

        .step-item.completed .step-icon {
            border-color: var(--success-color);
            background: var(--success-color);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
        }

        .step-item.rejected .step-icon {
            border-color: var(--danger-color);
            background: var(--danger-color);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2);
        }

        .step-label {
            margin-top: 1rem;
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-muted);
            text-align: center;
            transition: all 0.3s ease;
        }

        .step-item.active .step-label {
            color: var(--nsti-blue);
            font-weight: 800;
        }

        .step-item.completed .step-label {
            color: var(--success-color);
            font-weight: 700;
        }

        .step-item.rejected .step-label {
            color: var(--danger-color);
            font-weight: 700;
        }

        @keyframes pulse-ring {
            0% {
                transform: scale(0.95);
                opacity: 1;
            }
            100% {
                transform: scale(1.45);
                opacity: 0;
            }
        }

        /* Status Badge Overrides */
        .badge-custom {
            padding: 0.6rem 1.35rem;
            font-weight: 750;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            border-radius: 30px;
            text-transform: uppercase;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .badge-pending {
            background-color: var(--warning-bg) !important;
            color: var(--warning-color) !important;
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .badge-progress {
            background-color: var(--info-bg) !important;
            color: var(--info-color) !important;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        .badge-resolved {
            background-color: var(--success-bg) !important;
            color: var(--success-color) !important;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .badge-rejected {
            background-color: var(--danger-bg) !important;
            color: var(--danger-color) !important;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .badge.bg-secondary {
            background-color: #f1f5f9 !important;
            color: #475569 !important;
            border: 1px solid #e2e8f0;
        }
        
        .badge.bg-primary {
            background-color: var(--info-bg) !important;
            color: var(--info-color) !important;
            border: 1px solid rgba(59, 130, 246, 0.25);
        }

        .badge.bg-danger {
            background-color: var(--danger-bg) !important;
            color: var(--danger-color) !important;
            border: 1px solid rgba(239, 68, 68, 0.25);
        }

        /* Detail info rows */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .status-card-results .info-box {
            background: #ffffff;
            padding: 1.25rem 1.5rem;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            border-left: 4px solid var(--nsti-blue);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.01), 0 2px 4px -1px rgba(0, 0, 0, 0.006);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .status-card-results .info-grid .info-box:nth-child(2n) {
            border-left-color: var(--nsti-magenta);
        }

        .status-card-results .info-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 20px -3px rgba(15, 48, 87, 0.08);
            border-color: rgba(15, 48, 87, 0.15);
        }

        /* Stepper pulse border animation for active step */
        .step-item.active .step-icon {
            animation: pulse-border 2s infinite;
        }

        @keyframes pulse-border {
            0% {
                box-shadow: 0 0 0 0 rgba(15, 48, 87, 0.4);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(15, 48, 87, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(15, 48, 87, 0);
            }
        }

        .info-title {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.75px;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .info-title i {
            color: var(--nsti-magenta);
            font-size: 0.9rem;
        }

        .info-value {
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--text-dark);
        }

        .complaint-description {
            background: #ffffff;
            padding: 1.75rem;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.01);
            margin-bottom: 2.5rem;
        }

        .description-header {
            border-bottom: 1px solid #f1f5f9;
            padding-bottom: 1rem;
        }

        .description-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--nsti-blue);
            margin: 0.25rem 0 0 0;
        }

        .description-body {
            padding-top: 0.5rem;
        }

        .description-text {
            color: #334155;
            line-height: 1.7;
            font-size: 0.95rem;
            margin: 0.5rem 0 0 0;
            white-space: pre-line;
        }

        /* Timeline section */
        .timeline-section {
            border-top: 2px solid #f1f5f9;
            padding-top: 2.5rem;
            margin-top: 2.5rem;
        }

        .timeline-title {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--nsti-blue);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .timeline-title i {
            color: var(--nsti-magenta);
        }

        .timeline-container {
            position: relative;
            padding-left: 2.5rem;
        }

        .timeline-container::before {
            content: '';
            position: absolute;
            left: 9px;
            top: 10px;
            bottom: 10px;
            width: 3px;
            background: linear-gradient(180deg, var(--nsti-blue) 0%, #e2e8f0 100%);
            border-radius: 2px;
        }

        .timeline-card {
            position: relative;
            background: #ffffff;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.75rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.01);
            transition: all 0.3s ease;
        }

        .timeline-card:hover {
            transform: translateX(3px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.04);
            border-color: var(--nsti-blue-glow);
        }

        .timeline-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            width: 4px;
            border-radius: 16px 0 0 16px;
            background-color: var(--text-muted);
        }

        .timeline-card::before {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #ffffff;
            border: 4px solid var(--text-muted);
            left: -39px;
            top: 24px;
            box-shadow: 0 0 0 4px #ffffff;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .timeline-card.Pending::after { background-color: var(--warning-color); }
        .timeline-card.Pending::before { border-color: var(--warning-color); }

        .timeline-card.In_Progress::after { background-color: var(--info-color); }
        .timeline-card.In_Progress::before { border-color: var(--info-color); }

        .timeline-card.Resolved::after { background-color: var(--success-color); }
        .timeline-card.Resolved::before { border-color: var(--success-color); }

        .timeline-card.Rejected::after { background-color: var(--danger-color); }
        .timeline-card.Rejected::before { border-color: var(--danger-color); }

        .timeline-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 0.75rem;
            font-weight: 500;
        }

        .timeline-updater {
            font-weight: 700;
            color: var(--nsti-blue);
            font-size: 0.95rem;
        }

        .timeline-msg {
            font-size: 0.95rem;
            color: #334155;
            line-height: 1.6;
            margin: 0;
        }

        .footer-bar {
            background-color: var(--nsti-blue);
            color: #ffffff;
            padding: 1.5rem 5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            border-top: 4px solid var(--nsti-magenta);
            margin-top: 4rem;
        }

        @media (max-width: 768px) {
            .custom-navbar {
                padding: 1rem 2rem;
            }
            .logo-text {
                font-size: 1.15rem;
            }
            .nav-links .btn-home {
                padding: 0.5rem 1.2rem;
                font-size: 0.85rem;
            }
            .main-container {
                padding: 2rem 1rem;
            }
            .status-card {
                padding: 2rem 1.5rem;
            }
            .info-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            .footer-bar {
                padding: 1.2rem 2rem;
                flex-direction: column;
                gap: 0.5rem;
                text-align: center;
            }
            
            /* Responsive stepper adjustments */
            .step-tracker {
                flex-direction: column;
                align-items: flex-start;
                gap: 2rem;
                padding-left: 2.5rem;
                margin: 2.5rem 0;
            }
            .step-tracker::before {
                left: 36px;
                top: 0;
                bottom: 0;
                width: 6px;
                height: 100%;
            }
            .step-progress {
                left: 36px;
                top: 0;
                width: 6px !important; /* Forces vertical height instead of width */
                border-radius: 3px;
                transition: height 0.8s ease;
            }
            .step-item {
                flex-direction: row;
                width: 100% !important;
                gap: 1.5rem;
                align-items: center;
            }
            .step-label {
                margin-top: 0;
                text-align: left;
            }
        }
    </style>
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Header Navigation -->
    <header class="custom-navbar">
        <a href="index.php" class="logo-section">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="36" height="36" class="logo-img">
            <span class="logo-text">NSTI R-HYDERABAD</span>
        </a>
        <nav class="nav-links">
            <a href="index.php" class="btn-home"><i class="fas fa-home me-2"></i><span class="notranslate custom-translate-home">Home</span></a>
        </nav>
    </header>

    <!-- Main Container -->
    <main class="main-container">
        <!-- Tracker Search Form -->
        <div class="status-card status-card-search">
            <!-- Mockup Header Icon -->
            <div class="status-header-icon-wrapper">
                <div class="status-header-icon">
                    <i class="fas fa-check"></i>
                </div>
            </div>
            
            <h1 class="form-title">CHECK GRIEVANCE STATUS</h1>
            <p class="form-subtitle">Check status using grievance id and registered phone number</p>

            <?php if ($error): ?>
                <div class="alert alert-danger rounded-3 p-3 mb-4" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="check_status.php" method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label" for="complaint_id">Grievance ID *</label>
                        <div class="input-group-custom">
                            <input type="text" id="complaint_id" name="complaint_id" class="form-control-custom" placeholder="e.g. GRV202606041234" value="<?php echo htmlspecialchars($complaint_id); ?>" required>
                            <span class="input-icon"><i class="fas fa-hashtag"></i></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="contact">Registered Phone Number *</label>
                        <div class="input-group-custom">
                            <input type="text" id="contact" name="contact" class="form-control-custom" placeholder="Enter 10-digit number" value="<?php echo htmlspecialchars($contact); ?>" required>
                            <span class="input-icon"><i class="fas fa-phone-alt"></i></span>
                        </div>
                    </div>
                </div>
                <div class="mt-4">
                    <button type="submit" class="btn-track"><i class="fas fa-search me-2"></i>Check Status</button>
                </div>
            </form>
        </div>

        <?php if ($grievance): ?>
            <!-- Tracker Search Results -->
            <div class="status-card status-card-results">
                <div class="result-header">
                    <div>
                        <span class="info-title"><i class="fas fa-fingerprint"></i> Complaint Reference</span>
                        <div class="d-flex align-items-center gap-2 mt-1">
                            <h2 class="result-id" id="grievance_id_text"><?php echo htmlspecialchars($grievance['complaint_id']); ?></h2>
                            <button type="button" class="btn-copy" onclick="copyGrievanceId()" title="Copy ID">
                                <i class="far fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    <div>
                        <?php 
                        $status = $grievance['status'];
                        $badge_class = 'bg-secondary';
                        $status_text = getStatusLabel($status);
                        if ($status === 'Pending') $badge_class = 'badge-pending';
                        elseif ($status === 'In Progress') $badge_class = 'badge-progress';
                        elseif ($status === 'Resolved') $badge_class = 'badge-resolved';
                        elseif ($status === 'Rejected') $badge_class = 'badge-rejected';
                        ?>
                        <span class="badge-custom <?php echo $badge_class; ?>"><i class="fas fa-circle-info"></i> <?php echo $status_text; ?></span>
                    </div>
                </div>

                <!-- Step Timeline Progress Bar -->
                <?php
                // Map status progress percentage
                $percent = '12.5%';
                $height_percent = '12.5%';
                $step1 = 'completed'; // Pending is always completed
                $step2 = '';
                $step3 = '';
                $step4 = '';

                if ($status === 'In Progress') {
                    $percent = '50%';
                    $height_percent = '50%';
                    $step2 = 'active';
                } elseif ($status === 'Resolved') {
                    $percent = '100%';
                    $height_percent = '100%';
                    $step2 = 'completed';
                    $step3 = 'completed';
                } elseif ($status === 'Rejected') {
                    $percent = '100%';
                    $height_percent = '100%';
                    $step2 = 'completed';
                    $step4 = 'rejected';
                }
                ?>
                
                <!-- Dynamic Style injected for progress tracker transition -->
                <style>
                    @media (min-width: 769px) {
                        .step-progress { width: <?php echo $percent; ?>; }
                    }
                    @media (max-width: 768px) {
                        .step-progress { height: <?php echo $height_percent; ?>; width: 6px; }
                    }
                </style>

                <div class="step-tracker">
                    <div class="step-progress"></div>
                    
                    <div class="step-item <?php echo $step1; ?>">
                        <div class="step-icon">
                            <i class="fas fa-file-signature"></i>
                        </div>
                        <div class="step-label">Submitted</div>
                    </div>

                    <div class="step-item <?php echo $step2; ?> <?php echo ($status === 'In Progress') ? 'active' : ''; ?> <?php echo ($status === 'Resolved' || $status === 'Rejected') ? 'completed' : ''; ?>">
                        <div class="step-icon">
                            <i class="fas fa-spinner <?php echo ($status === 'In Progress') ? 'fa-spin' : ''; ?>"></i>
                        </div>
                        <div class="step-label">Under Process</div>
                    </div>

                    <?php if ($status !== 'Rejected'): ?>
                        <div class="step-item <?php echo $step3; ?> <?php echo ($status === 'Resolved') ? 'completed active' : ''; ?>" style="width: 50%;">
                            <div class="step-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="step-label">Resolved</div>
                        </div>
                    <?php else: ?>
                        <div class="step-item <?php echo $step4; ?> active" style="width: 50%;">
                            <div class="step-icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <div class="step-label">Rejected</div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Details Info -->
                <div class="info-grid mt-4">
                    <div class="info-box">
                        <div class="info-title"><i class="fas fa-user"></i> Complainant Name</div>
                        <div class="info-value"><?php echo htmlspecialchars($grievance['complainant_name']); ?></div>
                    </div>
                    <div class="info-box">
                        <div class="info-title"><i class="fas fa-tags"></i> Grievance Category</div>
                        <div class="info-value"><?php echo htmlspecialchars($grievance['category']); ?></div>
                    </div>
                    <div class="info-box">
                        <div class="info-title"><i class="fas fa-calendar-alt"></i> Lodged On</div>
                        <div class="info-value"><?php echo date('d M Y, h:i A', strtotime($grievance['created_at'])); ?></div>
                    </div>
                    <div class="info-box">
                        <div class="info-title"><i class="fas fa-flag"></i> Priority Level</div>
                        <div class="info-value">
                            <span class="badge <?php echo getPriorityBadge($grievance['priority']); ?> px-3 py-2 rounded-pill"><?php echo htmlspecialchars($grievance['priority']); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Complaint Details (Title & Description) -->
                <div class="complaint-description">
                    <div class="description-header">
                        <span class="info-title"><i class="fas fa-bullhorn"></i> Grievance Subject</span>
                        <h4 class="description-title"><?php echo htmlspecialchars($grievance['title']); ?></h4>
                    </div>
                    <div class="description-body mt-3">
                        <span class="info-title"><i class="fas fa-align-left"></i> Description</span>
                        <p class="description-text"><?php echo htmlspecialchars($grievance['description']); ?></p>
                    </div>
                </div>

                <!-- Timeline Updates -->
                <div class="timeline-section">
                    <h4 class="timeline-title"><i class="fas fa-history"></i> Grievance Action History</h4>
                    
                    <div class="timeline-container">
                        <!-- Initial Submission Entry -->
                        <div class="timeline-card Pending">
                            <div class="timeline-meta">
                                <span class="timeline-updater"><i class="fas fa-laptop-code me-1 text-primary"></i> System Auto-Gen</span>
                                <span><?php echo date('d M Y, h:i A', strtotime($grievance['created_at'])); ?></span>
                            </div>
                            <p class="timeline-msg">Grievance successfully submitted and registered. Reference ID is <strong><?php echo htmlspecialchars($grievance['complaint_id']); ?></strong>. Assigned to Department Administrator for review.</p>
                        </div>

                        <!-- User/Admin Remarks Entries -->
                        <?php if (empty($updates)): ?>
                            <?php if ($status === 'Pending'): ?>
                                <div class="text-muted small ps-2"><i class="fas fa-info-circle me-1 text-info"></i> Awaiting administrative review. Updates will appear here.</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php foreach ($updates as $up): ?>
                                <?php
                                $up_status = $up['status'] ?? 'Pending';
                                $up_status_clean = str_replace(' ', '_', $up_status);
                                
                                $icon = '<i class="fas fa-user-tie me-1 text-primary"></i> ';
                                if (strtolower($up['updater_role']) === 'admin') {
                                    $icon = '<i class="fas fa-user-shield me-1 text-danger"></i> ';
                                }
                                ?>
                                <div class="timeline-card <?php echo $up_status_clean; ?>">
                                    <div class="timeline-meta">
                                        <span class="timeline-updater"><?php echo $icon; ?><?php echo htmlspecialchars($up['updater_name']); ?> (<?php echo ucfirst($up['updater_role']); ?>)</span>
                                        <span><?php echo date('d M Y, h:i A', strtotime($up['created_at'])); ?></span>
                                    </div>
                                    <p class="timeline-msg">
                                        <strong>Status changed to: </strong><span class="small badge <?php echo getStatusBadge($up_status); ?>"><?php echo getStatusLabel($up_status); ?></span>
                                        <?php if (!empty($up['message'])): ?>
                                            <br><span class="d-block mt-2 text-secondary"><?php echo htmlspecialchars($up['message']); ?></span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <!-- Footer Bar -->
    <footer class="footer-bar">
        <div>
            <span>Grievance Management System</span>
        </div>
        <div>
            <span>&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</span>
        </div>
    </footer>

    <!-- Copy to Clipboard and Micro-interactions Script -->
    <script>
        function copyGrievanceId() {
            const idText = document.getElementById('grievance_id_text').innerText;
            navigator.clipboard.writeText(idText).then(() => {
                const copyBtn = document.querySelector('.btn-copy');
                copyBtn.innerHTML = '<i class="fas fa-check text-success"></i>';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="far fa-copy"></i>';
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    </script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>







