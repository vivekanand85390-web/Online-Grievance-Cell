<?php
require_once 'config/db.php';

try {
    $sql = "ALTER TABLE users ADD COLUMN roll_no VARCHAR(100) DEFAULT NULL";
    $pdo->exec($sql);
    echo "Column roll_no added successfully.\n";
} catch (PDOException $e) {
    echo "Error adding column: " . $e->getMessage() . "\n";
}
?>
