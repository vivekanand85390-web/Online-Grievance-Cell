<?php
include_once 'includes/functions.php';

// Ensure session is active for Captcha validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isLoggedIn()) {
    header("Location: user/dashboard.php");
    exit();
}

// Generate captcha code dynamically
if (isset($_GET['refresh_captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
    echo $_SESSION['captcha'];
    exit();
}

if (!isset($_SESSION['captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
}

$error   = '';
$success = '';
$step    = 1; // 1=verify identity, 2=new password

// â”€â”€ Cancel / restart â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
if (isset($_GET['cancel'])) {
    unset($_SESSION['reset_user_id'], $_SESSION['reset_user_name']);
    header("Location: forgot_password.php");
    exit();
}

// â”€â”€ Restore step from session â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
if (isset($_SESSION['reset_user_id'])) {
    $step = 2; // Password reset
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  AJAX: Verify Identity (Step 1 â†’ 2)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_identity') {
    header('Content-Type: application/json');

    $role    = sanitize($_POST['role']    ?? '');
    $email   = sanitize($_POST['email']   ?? '');
    $captcha = sanitize($_POST['captcha'] ?? '');

    if (empty($role) || empty($email) || empty($captcha)) {
        echo json_encode(['success' => false, 'message' => 'Please fill in all fields.']);
        exit();
    }

    if ($captcha !== ($_SESSION['captcha'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid Captcha code.']);
        exit();
    }

    // Verify in database
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ? AND role = ?");
    $stmt->execute([$email, $role]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'No account found with this Email and User Role.']);
        exit();
    }

    // Store in session
    $_SESSION['reset_user_id']    = $user['id'];
    $_SESSION['reset_user_name']  = $user['name'];

    // Generate new captcha just in case
    $_SESSION['captcha'] = strval(rand(1000, 9999));

    echo json_encode([
        'success' => true,
        'message' => 'Identity verified successfully.',
    ]);
    exit();
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  POST: Reset Password (Step 2)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset') {
    if (!isset($_SESSION['reset_user_id'])) {
        $error = "Session expired. Please start over.";
        $step  = 1;
    } else {
        $password         = $_POST['password']         ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($password) || empty($confirm_password)) {
            $error = "Please fill in all fields."; $step = 2;
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match."; $step = 2;
        } elseif (strlen($password) < 6) {
            $error = "Password must be at least 6 characters."; $step = 2;
        } else {
            $user_id         = $_SESSION['reset_user_id'];
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($stmt->execute([$hashed_password, $user_id])) {
                unset($_SESSION['reset_user_id'], $_SESSION['reset_user_name']);
                $_SESSION['msg']      = "Password reset successful! Please login.";
                $_SESSION['msg_type'] = "success";
                header("Location: login.php");
                exit();
            } else {
                $error = "Failed to update password. Please try again."; $step = 2;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recover Password - Online Grievance Redressal System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Accessibility Styles & Script -->
    <link rel="stylesheet" href="assets/css/accessibility.css">
    <script src="assets/js/accessibility.js" defer></script>
    
    <style>
        :root {
            --bg-base: #f7f9fc;
            --nsti-blue: #0f3057;
            --nsti-magenta: #b01c70;
            --text-dark: #2d3748;
            --text-muted: #718096;
            --card-border: rgba(0, 0, 0, 0.06);
            --bg-light: #ffffff;
        }

        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Header Branding Section */
                        .header-branding {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 1rem;
            width: 100%;
            padding: 1rem 2rem;
        }





        .header-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            justify-self: start;
        }


        .header-logo img {
            width: 110px;
            height: auto;
            object-fit: contain;
        }

        .logo-caption {
            margin: 0;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--nsti-blue);
            text-align: center;
            white-space: nowrap;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-top: 2px solid var(--nsti-magenta);
            padding: 0.4rem 0.5rem 0 0.5rem;
        }

        .logo-caption .caption-location {
            color: var(--nsti-magenta);
            font-weight: 800;
        }

        .header-titles {
            text-align: center;
            justify-self: center;
        }





        .header-titles .main-title {
            font-size: 3.8rem;
            font-weight: 900;
            color: var(--nsti-blue);
            margin: 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .header-titles .sub-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--nsti-magenta);
            margin: 0.25rem 0 0 0;
            white-space: nowrap;
        }

        .header-right-logo {
            justify-self: end;
        }


        @media (max-width: 1400px) {
            .header-titles .main-title { font-size: 3.2rem; }
            .header-titles .sub-title { font-size: 1.8rem; }
            .header-branding { padding: 1rem; }
        }

        @media (max-width: 1200px) {
            .header-titles .main-title { font-size: 2.8rem; }
            .header-titles .sub-title { font-size: 1.6rem; }
        }

        @media (max-width: 991px) {
            .header-branding {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
                text-align: center;
                padding: 1rem;
            }
            .header-titles .main-title {
                font-size: 2.8rem;
                white-space: nowrap;
            }
            .header-titles .sub-title {
                font-size: 1.6rem;
                white-space: nowrap;
                margin-top: 0.25rem;
            }
        }
        
        @media (max-width: 576px) {
            .header-titles .main-title {
                font-size: 2.2rem;
                white-space: normal;
                line-height: 1.2;
            }
            .header-titles .sub-title {
                font-size: 1.4rem;
                white-space: normal;
                line-height: 1.3;
            }
        }

        /* Navigation Bar Styles */
        .custom-navbar {
            background-color: var(--nsti-blue);
            box-shadow: 0 4px 15px rgba(15, 48, 87, 0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            transition: all 0.3s ease;
        }

        .menu-toggle {
            display: none;
            background: transparent;
            border: none;
            color: #ffffff;
            font-size: 1.35rem;
            cursor: pointer;
            padding: 0.5rem;
            align-items: center;
            justify-content: center;
        }

        .mobile-brand {
            display: none;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.95rem;
            text-transform: uppercase;
            text-decoration: none;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            justify-content: center;
            list-style: none;
            flex-wrap: wrap;
            margin: 0;
            padding: 0;
        }

        .nav-menu li {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            color: #ffffff;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.9rem 1.2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            text-transform: capitalize;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #ffe600;
            border-bottom-color: var(--nsti-magenta);
        }

        .nav-menu .separator {
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.9rem;
            user-select: none;
        }

        @media (max-width: 768px) {
            .navbar-container {
                justify-content: flex-end;
                flex-wrap: wrap;
                padding: 0.5rem 1rem;
            }

            .menu-toggle {
                display: flex;
            }

            .mobile-brand {
                display: none;
            }

            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding-top: 0.5rem;
            }

            .nav-menu.show {
                display: flex;
            }

            .nav-menu li {
                width: 100%;
                flex-direction: column;
            }

            .nav-menu a {
                padding: 0.6rem 2rem;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                border-bottom: none;
                border-left: 3px solid transparent;
            }
            .nav-menu a:hover, .nav-menu a.active {
                border-left-color: var(--nsti-magenta);
                border-bottom-color: transparent;
                background-color: rgba(255, 255, 255, 0.05);
            }
            .nav-menu .separator {
                display: none;
            }
        }

        /* Custom Dropdown Styling */
        .nav-menu .dropdown {
            position: relative;
        }

        .nav-menu .dropdown-toggle::after {
            display: none;
        }

        .nav-menu .dropdown-toggle i {
            font-size: 0.75rem;
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            margin-left: 0.35rem;
        }

        .nav-menu .dropdown:hover .dropdown-toggle i,
        .nav-menu .dropdown-toggle[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        .nav-menu .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%) translateY(15px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            background-color: #0b223e;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border-radius: 12px;
            padding: 0.6rem 0;
            margin-top: 0;
            min-width: 220px;
            overflow: hidden;
            flex-direction: column;
            z-index: 1000;
        }

        .nav-menu .dropdown-menu li {
            display: block !important;
            width: 100% !important;
        }

        .nav-menu .dropdown-item {
            display: block !important;
            width: 100% !important;
            text-align: left;
            color: #ffffff !important;
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.75rem 1.6rem !important;
            border-left: 3px solid transparent !important;
            border-bottom: none !important;
            transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
            text-transform: capitalize;
        }

        .nav-menu .dropdown-item:hover,
        .nav-menu .dropdown-item:focus,
        .nav-menu .dropdown-item.active {
            color: #ffe600 !important;
            background-color: var(--nsti-magenta) !important;
            border-left-color: #ffe600 !important;
            padding-left: 1.9rem !important;
        }

        @media (min-width: 769px) {
            .nav-menu .dropdown:hover .dropdown-menu {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateX(-50%) translateY(0) !important;
            }
            .nav-menu .dropdown-menu {
                display: flex !important;
                opacity: 0;
                visibility: hidden;
                transform: translateX(-50%) translateY(15px);
                transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
        }

        @media (max-width: 768px) {
            .nav-menu .dropdown {
                width: 100%;
                text-align: center;
            }
            .nav-menu .dropdown-toggle {
                width: 100%;
                justify-content: center;
            }
            .nav-menu .dropdown-menu {
                position: relative !important;
                left: auto !important;
                transform: none !important;
                float: none !important;
                width: 100% !important;
                background-color: rgba(0, 0, 0, 0.15) !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
                margin: 0 !important;
                padding: 0.5rem 0 !important;
                display: none !important;
            }
            .nav-menu .dropdown-menu.open {
                display: flex !important;
                opacity: 1 !important;
                visibility: visible !important;
            }
            .nav-menu .dropdown-item {
                text-align: center;
                color: rgba(255, 255, 255, 0.8) !important;
                padding: 0.6rem 2rem !important;
                background: transparent !important;
                border-left: 3px solid transparent !important;
            }
            .nav-menu .dropdown-item:hover,
            .nav-menu .dropdown-item:focus,
            .nav-menu .dropdown-item.active {
                color: #ffe600 !important;
                border-left-color: var(--nsti-magenta) !important;
                background-color: rgba(255, 255, 255, 0.05) !important;
                padding-left: 2rem !important;
            }
        }

        /* Main Content Wrapper */
        .forgot-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            padding: 4rem 1.5rem; /* Spacious padding */
            background-color: var(--bg-base);
        }

        /* Orange wrapper surrounding the card */
        .orange-wrapper {
            background-color: #e05e19;
            padding: 3.5rem 3rem; /* Thick orange border */
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        /* Centered White Card */
        .form-card {
            background-color: #ffffff;
            border-radius: 0px; /* Sharp corners like screenshot */
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 400px;
        }

        /* Site Footer */
        .site-footer {
            background-color: #0c1e35;
            color: #94a3b8;
            padding-top: 4rem;
            border-top: 5px solid var(--nsti-magenta);
            width: 100%;
            margin-top: auto;
        }

        .footer-links-grid {
            margin-bottom: 3rem;
        }

        .footer-grid-title {
            font-size: 1.05rem;
            position: relative;
            padding-bottom: 0.75rem;
            color: #ffffff;
        }

        .footer-grid-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 35px;
            height: 3px;
            background-color: var(--nsti-magenta);
            border-radius: 2px;
        }

        .footer-links-list li {
            font-size: 0.9rem;
            color: #cbd5e1;
        }

        .footer-link {
            color: #cbd5e1;
            transition: all 0.2s ease;
        }

        .footer-link:hover {
            color: #ffe600;
            padding-left: 4px;
        }

        .footer-contact-list {
            font-size: 0.9rem;
        }

        .footer-contact-list li i {
            color: var(--nsti-magenta);
            font-size: 0.95rem;
            width: 20px;
        }

        .footer-watermark {
            background-color: #06101e;
            padding: 1.2rem 2rem;
            text-align: center;
        }

        .watermark-text {
            margin: 0;
            font-size: 0.85rem;
            color: #64748b;
        }

        .form-card-title {
            font-size: 1.6rem;
            font-weight: 800;
            color: #000000;
            text-align: center;
            text-transform: uppercase;
            line-height: 1.4;
            margin-bottom: 2rem;
            letter-spacing: 0.5px;
        }

        .form-group {
            margin-bottom: 1.25rem;
            position: relative;
        }

        /* Inputs & Select */
        .form-input {
            width: 100%;
            background-color: #ffffff;
            border: 1.5px solid #cbd5e1;
            color: #0f172a;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            border-radius: 4px;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-input::placeholder {
            color: #94a3b8;
        }

        .form-input:focus {
            border-color: #7fc3ff;
            box-shadow: 0 0 0 3px rgba(127, 195, 255, 0.25);
        }

        /* Dropdown style with blue border */
        select.form-input {
            border-color: #7fc3ff;
            color: #495057;
            appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23475569' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 11px;
        }

        /* Captcha Styles */
        .captcha-container {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.25rem;
        }

        .captcha-canvas {
            background-color: #f1f5f9;
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            width: 150px;
            height: 42px;
        }

        /* Orange rounded square refresh button */
        .btn-refresh-captcha {
            background-color: #e05e19;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            height: 42px;
            width: 42px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.15rem;
            transition: background-color 0.2s;
            cursor: pointer;
        }

        .btn-refresh-captcha:hover {
            background-color: #c04e12;
            color: #ffffff;
        }

        /* Pill styled submit button */
        .btn-submit {
            background-color: #0f3057;
            color: #ffffff;
            font-weight: 700;
            font-size: 1.15rem;
            border: none;
            border-radius: 2rem;
            padding: 0.8rem;
            width: 100%;
            text-transform: capitalize;
            letter-spacing: 0.5px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(15, 48, 87, 0.25);
            margin-top: 1.5rem;
            cursor: pointer;
            display: block;
            text-align: center;
            text-decoration: none;
        }

        .btn-submit:hover {
            background-color: #091c34;
            color: #ffffff;
            box-shadow: 0 6px 15px rgba(15, 48, 87, 0.35);
        }

        .btn-submit:disabled {
            opacity: 0.65;
            cursor: not-allowed;
        }

        /* Blue Back Link */
        .link-back {
            color: #0000ff;
            font-weight: 600;
            font-size: 0.95rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            transition: color 0.2s;
        }

        .link-back i {
            color: #0000ff;
        }

        .link-back:hover {
            text-decoration: underline;
            color: #0000cc;
        }

        .otp-error {
            color: #ef4444;
            font-size: 0.88rem;
            font-weight: 600;
            text-align: center;
            min-height: 20px;
        }

        /* Spinner */
        .spinner-sm {
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.4);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.7s linear infinite;
            display: inline-block;
            margin-right: 6px;
            vertical-align: middle;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <?php include_once 'includes/accessibility_bar.php'; ?>

    <!-- Top Header Branding Section -->
    <header class="header-branding">
        <a href="index.php" class="header-logo">
            <img src="assets/images/nsti_logo.png?v=2" alt="NSTI Logo" width="78" height="78">
            <p class="logo-caption">National Skill Training Institute<span class="caption-location"> - Ramanthapur</span></p>
        </a>
        <div class="header-titles">
            <h1 class="main-title">NSTI R-HYDERABAD</h1>
            <h2 class="sub-title">Online Grievance Redressal System</h2>
        </div>
        <div class="header-right-logo d-none d-lg-flex">
            <img src="assets/images/committee_illustration.png" alt="Committee Illustration" style="height: 65px; width: auto; object-fit: contain;">
        </div>
    </header>

    <!-- Horizontal Navbar -->
    <nav class="custom-navbar">
        <div class="container navbar-container">
            <a href="index.php" class="mobile-brand">NSTI R-HYDERABAD</a>
            <button class="menu-toggle" id="mobile-menu-toggle" aria-label="Toggle Menu">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="index.php"><span class="notranslate custom-translate-home">Home</span></a></li>
                <li class="separator">|</li>
                <li><a href="about.php">About</a></li>
                <li class="separator">|</li>
                <li><a href="contact.php">Contact</a></li>
                <li class="separator">|</li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" id="grievanceDropdown" role="button" aria-expanded="false">
                        Help & Support <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="grievanceDropdown">
                        <li><a class="dropdown-item" href="check_status.php">Track Status</a></li>
                        <li><a class="dropdown-item" href="steps_to_lodge.php">Steps to Lodge</a></li>
                        <li><a class="dropdown-item" href="team_members.php">Project Team</a></li>
                    </ul>
                </li>
                <li class="separator">|</li>
                <li><a href="feedback.php">Feedback</a></li>
                <li class="separator">|</li>
                <li><a href="login.php" class="active">Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Content Section -->
    <div class="forgot-container">
        <div class="orange-wrapper">
            <div class="form-card">
                <h3 class="form-card-title">RECOVER YOUR PASSWORD</h3>

                <?php if ($error): ?>
                    <div class="alert alert-danger rounded-3 py-2 px-3 mb-3" style="font-size:0.88rem;" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                    </div>
                <?php endif; ?>

                <!-- â•â• STEP 1: Verify Identity â•â• -->
                <?php if ($step === 1): ?>
                    <div id="step1Error" class="otp-error mb-3"></div>
                    
                    <div class="form-group">
                        <select id="fp_role" class="form-input" required>
                            <option value="" disabled selected>-Select User-</option>
                            <option value="student">Student/Trainee</option>
                            <option value="parent">Parent</option>
                            <option value="staff">Staff/Faculty</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="email" id="fp_email" class="form-input" placeholder="Email ID" required autocomplete="off">
                    </div>

                    <!-- Captcha Container -->
                    <div class="captcha-container">
                        <canvas id="captchaCanvas" width="150" height="42" class="captcha-canvas"></canvas>
                        <button type="button" class="btn-refresh-captcha" onclick="refreshCaptcha()" title="Refresh Captcha">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>

                    <div class="form-group">
                        <input type="text" id="fp_captcha" class="form-input" placeholder="Enter Captcha" required autocomplete="off">
                    </div>

                    <button type="button" class="btn-submit" id="btnVerifyIdentity" onclick="verifyIdentity()">
                        Submit
                    </button>

                <!-- â•â• STEP 2: New Password â•â• -->
                <?php elseif ($step === 2): ?>
                    <p class="text-muted text-center mb-4" style="font-size:0.92rem;">
                        Welcome, <strong><?= htmlspecialchars($_SESSION['reset_user_name'] ?? 'User') ?></strong>.<br>
                        Choose a new secure password.
                    </p>
                    <form action="forgot_password.php" method="POST">
                        <input type="hidden" name="action" value="reset">
                        
                        <div class="form-group">
                            <input type="password" name="password" class="form-input" placeholder="New Password" required minlength="6">
                        </div>
                        
                        <div class="form-group">
                            <input type="password" name="confirm_password" class="form-input" placeholder="Confirm New Password" required>
                        </div>
                        
                        <button type="submit" class="btn-submit">Submit</button>
                    </form>
                <?php endif; ?>

                <div class="text-center mt-4">
                    <?php if ($step === 1): ?>
                        <a href="login.php" class="link-back">
                            <i class="fas fa-arrow-left"></i> Back to login page
                        </a>
                    <?php else: ?>
                        <a href="forgot_password.php?cancel=1" class="link-back">
                            <i class="fas fa-arrow-left"></i> Cancel Reset
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Site Footer -->
    <footer class="site-footer" id="footer-sections">
        <div class="footer-links-grid container">
            <div class="row g-4">
                <!-- Column 1: About NSTI R-Hyderabad -->
                <div class="col-md-6 col-lg-4">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-info-circle" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>About System</h5>
                    <p class="footer-grid-text mb-4" style="text-align: justify; line-height: 1.65; color: #cbd5e1;">
                        The Online Grievance Redressal System is a digital initiative at NSTI Ramanthapur, Hyderabad, dedicated to establishing a transparent and fair environment. Our platform ensures that every concern is registered, tracked, and resolved efficiently and confidentially.
                    </p>
                </div>
                
                <!-- Column 2: Our Team -->
                <div class="col-md-6 col-lg-4">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-users" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>Our Team</h5>
                    <ul class="list-unstyled footer-links-list ps-2 text-secondary-white" style="font-size: 0.9rem; line-height: 1.8;">
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-user-tie mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">Aakanksha Netam</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">Team Leader</span>
                            </div>
                        </li>
                        <li class="mb-2.5 d-flex align-items-start gap-2">
                            <i class="fas fa-tasks mt-1" style="color: #a855f7; font-size: 0.85rem;"></i>
                            <div>
                                <span class="d-block fw-bold text-white" style="font-size: 0.9rem;">VIVEKANAND</span>
                                <span style="color: #cbd5e1; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; display: block; margin-top: 1px;">Project Manager</span>
                            </div>
                        </li>
                    </ul>
                </div>
                
                <!-- Column 3: Contact Us -->
                <div class="col-md-6 col-lg-4" id="contact">
                    <h5 class="footer-grid-title text-uppercase mb-4 fw-bold text-white"><i class="fas fa-envelope-open-text" style="color: #2e7d32; margin-right: 10px; font-size: 0.9em; vertical-align: middle;"></i>Contact Us</h5>
                    <ul class="list-unstyled footer-contact-list">
                        <li class="mb-3 text-secondary-white d-flex align-items-start gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-map-marker-alt mt-1"></i>
                            <span>Uppal Road, Ramanthapur, Rahat Nagar, Amberpet, Hyderabad, Telangana 500013</span>
                        </li>
                        <li class="mb-3 text-secondary-white d-flex align-items-center gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-phone-alt"></i>
                            <span>040-27037266, 040-27038982</span>
                        </li>
                        <li class="mb-3 text-secondary-white d-flex align-items-center gap-2" style="color: #cbd5e1;">
                            <i class="fas fa-envelope"></i>
                            <span>nsti-hyderabad2@dgt.gov.in</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Footer Branding Watermark -->
                    <div class="footer-watermark">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <p class="watermark-text mb-0 text-center text-md-start" style="font-size: 0.85rem;">&copy; <?php echo date('Y'); ?> Online Grievance Redressal System. All Rights Reserved.</p>
            <div class="d-flex justify-content-center justify-content-md-end align-items-center" style="font-size: 0.75rem; color: #64748b; padding: 5px 0;">
    <span style="opacity: 0.7; margin-right: 4px;">Developed By:</span>
    <span style="color: rgba(255,255,255,0.7); font-weight: 400;">Vivekanand & Aakanksha</span>
</div>
        </div>
    </div>
    </footer>

    <!-- SweetAlert2 and Script dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if (isset($_SESSION['msg'])): ?>
        <script>
            Swal.fire({
                icon: '<?php echo $_SESSION['msg_type']; ?>',
                title: '<?php echo $_SESSION['msg']; ?>',
                timer: 3000,
                showConfirmButton: false,
                background: '#ffffff',
                color: '#1e293b'
            });
        </script>
        <?php 
        unset($_SESSION['msg']); 
        unset($_SESSION['msg_type']); 
        ?>
    <?php endif; ?>

    <script>
    // Captcha drawing function
    let currentCaptcha = "<?php echo $_SESSION['captcha'] ?? ''; ?>";

    function drawCaptcha(code) {
        const canvas = document.getElementById('captchaCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw background
        ctx.fillStyle = '#f1f5f9';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Add grid lines for noise
        for (let i = 0; i < 6; i++) {
            ctx.strokeStyle = `rgba(224, 94, 25, ${Math.random() * 0.3 + 0.1})`;
            ctx.lineWidth = Math.random() * 2 + 1;
            ctx.beginPath();
            ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.stroke();
        }
        
        // Add noise dots
        for (let i = 0; i < 45; i++) {
            ctx.fillStyle = `rgba(15, 48, 87, ${Math.random() * 0.4})`;
            ctx.beginPath();
            ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, Math.random() * 2, 0, 2 * Math.PI);
            ctx.fill();
        }
        
        // Draw text with distortions
        ctx.font = 'bold 24px "Outfit", sans-serif';
        ctx.textBaseline = 'middle';
        
        const chars = code.toString().split('');
        let xOffset = 25;
        
        chars.forEach((char, index) => {
            ctx.save();
            ctx.fillStyle = index % 2 === 0 ? '#0f3057' : '#e05e19';
            
            const angle = (Math.random() - 0.5) * 0.4; // between -11 and 11 deg
            const yOffset = 21 + (Math.random() - 0.5) * 6; // random vertical shift
            
            ctx.translate(xOffset, yOffset);
            ctx.rotate(angle);
            ctx.fillText(char, 0, 0);
            ctx.restore();
            
            xOffset += 28;
        });
    }

    function refreshCaptcha() {
        fetch('forgot_password.php?refresh_captcha=1')
            .then(response => response.text())
            .then(code => {
                currentCaptcha = code;
                drawCaptcha(code);
            });
    }

    // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
    //  STEP 1 â€” Verify Identity
    // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
    function verifyIdentity() {
        const role    = document.getElementById('fp_role')?.value;
        const email   = document.getElementById('fp_email')?.value.trim();
        const captcha = document.getElementById('fp_captcha')?.value.trim();
        const errEl   = document.getElementById('step1Error');
        const btn     = document.getElementById('btnVerifyIdentity');

        if (!role) { errEl.textContent = 'Please select a user role.'; return; }
        if (!email) { errEl.textContent = 'Please enter your email ID.'; return; }
        if (!captcha) { errEl.textContent = 'Please enter the Captcha.'; return; }
        
        errEl.textContent = '';
        btn.disabled  = true;
        btn.innerHTML = '<span class="spinner-sm"></span> Submitting...';

        const fd = new FormData();
        fd.append('action',  'verify_identity');
        fd.append('role',    role);
        fd.append('email',   email);
        fd.append('captcha', captcha);

        fetch('forgot_password.php', { method: 'POST', body: fd })
            .then(r => r.json())
            .then(data => {
                if (!data.success) {
                    btn.disabled  = false;
                    btn.innerHTML = 'Submit';
                    errEl.textContent = data.message;
                    refreshCaptcha();
                    // Clear captcha input
                    const captchaInput = document.getElementById('fp_captcha');
                    if (captchaInput) captchaInput.value = '';
                    return;
                }
                // Reload to show step 2
                window.location.reload();
            })
            .catch(() => {
                btn.disabled  = false;
                btn.innerHTML = 'Submit';
                errEl.textContent = 'Network error. Please try again.';
            });
    }

    // Mobile Navigation Toggle
    document.addEventListener("DOMContentLoaded", function() {
        const toggleBtn = document.getElementById("mobile-menu-toggle");
        const navMenu = document.getElementById("navMenu");
        
        if (toggleBtn && navMenu) {
            toggleBtn.addEventListener("click", function() {
                navMenu.classList.toggle("show");
                const icon = toggleBtn.querySelector("i");
                if (icon) {
                    if (navMenu.classList.contains("show")) {
                        icon.classList.remove("fa-bars");
                        icon.classList.add("fa-times");
                    } else {
                        icon.classList.remove("fa-times");
                        icon.classList.add("fa-bars");
                    }
                }
            });
        }
    });

    // Initial draw
    window.addEventListener('load', () => {
        drawCaptcha(currentCaptcha);
    });
    </script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>




















