-- Online Grievance Cell Management System Database Schema
-- NSTI-R Hyderabad

CREATE DATABASE IF NOT EXISTS grievance_db;
USE grievance_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE DEFAULT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'staff', 'admin', 'parent') DEFAULT 'student',
    contact VARCHAR(15),
    department VARCHAR(100),
    profile_pic VARCHAR(255) DEFAULT 'default_profile.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- Insert Default Categories
INSERT IGNORE INTO categories (name) VALUES 
('Financial Services (Banking Division)'), 
('Labour and Employment'), 
('Central Board of Direct Taxes (Income Tax)'), 
('Posts'), 
('Telecommunications'), 
('Home Affairs'), 
('Housing and Urban Affairs'), 
('Personnel and Training'), 
('Health & Family Welfare'), 
('Financial Services (Insurance Division)'), 
('Other Ministries/Departments');

-- Grievances Table
CREATE TABLE IF NOT EXISTS grievances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id VARCHAR(20) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    priority ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
    attachment VARCHAR(255),
    status ENUM('Pending', 'In Progress', 'Resolved', 'Rejected') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Grievance Updates Table (Timeline/Chat)
CREATE TABLE IF NOT EXISTS grievance_updates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grievance_id INT NOT NULL,
    updated_by INT NOT NULL,
    status ENUM('Pending', 'In Progress', 'Resolved', 'Rejected'),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (grievance_id) REFERENCES grievances(id) ON DELETE CASCADE,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Admin Table (Optional, but using 'role' in users table for simplicity or separate admin for higher security)
-- For this project, we'll use the 'role' column in 'users' table but can add a default admin.
INSERT IGNORE INTO users (username, name, email, password, role, profile_pic) VALUES 
('admin', 'NSTI ADMIN', 'admin@nsti.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'admin_avatar.png'); 
-- Default password: password
