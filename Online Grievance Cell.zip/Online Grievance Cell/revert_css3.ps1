$files = @('about.php','contact.php','forgot_password.php','index.php','steps_to_lodge.php','submit_grievance.php','team_members.php')
foreach($f in $files) {
    $path = "c:\xampp\htdocs\Online Grievance Cell\" + $f
    $c = Get-Content $path -Raw

    $c = $c -replace '(?s)\.header-branding\s*\{.*?\}(?=\s*\.header-logo)', ".header-branding {`r`n            display: grid;`r`n            grid-template-columns: 1fr auto 1fr;`r`n            align-items: center;`r`n            gap: 1rem;`r`n            width: 100%;`r`n            padding: 1rem 2rem;`r`n        }`r`n"
    
    $c = $c -replace 'flex:\s*0 0 auto;', 'justify-self: start;'
    # We replaced justify-self: end with flex: 0 0 auto as well, let's just replace both carefully
    
    $c = $c -replace '(?s)\.header-logo\s*\{.*?\}(?=\s*\.header-logo img)', ".header-logo {`r`n            display: flex;`r`n            flex-direction: column;`r`n            align-items: center;`r`n            justify-content: center;`r`n            gap: 0.4rem;`r`n            justify-self: start;`r`n        }`r`n"

    $c = $c -replace '(?s)\.header-right-logo\s*\{.*?\}(?=\s*@media|\z)', ".header-right-logo {`r`n            justify-self: end;`r`n        }`r`n"

    $c = $c -replace '(?s)\.header-titles\s*\{.*?\}(?=\s*\.header-titles \.main-title)', ".header-titles {`r`n            text-align: center;`r`n            justify-self: center;`r`n        }`r`n"

    $c = $c -replace 'font-size:\s*clamp\(.*?\);\s*line-height:\s*1\.[12];', 'font-size: 3.8rem;'
    # Fix subtitle font size
    $c = $c -replace '(?s)(\.header-titles \.sub-title\s*\{.*?)font-size:\s*3\.8rem;', "`$1font-size: 2.2rem;"

    $c = $c -replace 'white-space: normal; word-wrap: break-word;', 'white-space: nowrap;'

    Set-Content -Path $path -Value $c
    Write-Host "Reverted $f"
}
