<?php
require_once 'config/db.php';

try {
    $sql = "ALTER TABLE users 
            ADD COLUMN room_no VARCHAR(20) DEFAULT NULL, 
            ADD COLUMN trade VARCHAR(100) DEFAULT NULL";
    $pdo->exec($sql);
    echo "Columns added successfully.\n";
} catch (PDOException $e) {
    echo "Error adding columns: " . $e->getMessage() . "\n";
}
?>
