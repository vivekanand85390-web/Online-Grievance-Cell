<?php
// chat_api.php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$message = $data['message'] ?? '';
$history = $data['history'] ?? [];

if (empty($message)) {
    echo json_encode(['error' => 'Message cannot be empty.']);
    exit;
}

// Prepare the system prompt
$systemPrompt = "You are 'NSTI Copilot', an advanced, empathetic, and highly efficient AI Assistant for the NSTI Ramanthapur (Online Grievance Redressal System). Your primary goal is to help students, staff, and parents lodge their complaints, track their status, and resolve queries instantly. You must act professional, polite, and helpful.\n\n"
. "CRITICAL RULE 1: Whenever a user asks how to complain about something, you MUST provide a clear, step-by-step guide on what exactly they should write in the complaint form (e.g., Step 1: Your details, Step 2: Date & time, Step 3: Exact issue, Step 4: Proof). Give them a proper template.\n"
. "CRITICAL RULE 2: Whatever question the user asks, you MUST answer it directly, clearly, and step-by-step. Do not give vague answers.\n"
. "Process to Lodge Complaint: Guide them to Register -> Login -> Go to Dashboard -> Click 'Lodge Complaint' -> Select Category -> Submit.\n"
. "Track Status: Instruct users to track grievances using their ID in the Track Grievance section.\n"
. "Language: Always reply in the language the user speaks (English, Hindi, or Hinglish). Use simple words.\n"
. "Limitations: You cannot resolve grievances directly. You are a guide. Do NOT invent contact numbers.\n"
. "Formatting: ALWAYS use Markdown formatting (bullet points, numbered lists, bold text) to make your answers easy to read.";

// Limit history to the last 6 messages to save bandwidth
if (is_array($history) && count($history) > 6) {
    $history = array_slice($history, -6);
}

// Format history for OpenAI format (used by Free API)
$openAiMessages = [];
$openAiMessages[] = [
    "role" => "system",
    "content" => $systemPrompt
];

foreach ($history as $msg) {
    $openAiMessages[] = [
        "role" => $msg['role'] === 'user' ? 'user' : 'assistant',
        "content" => $msg['content']
    ];
}

// Add the current message
$openAiMessages[] = [
    "role" => "user",
    "content" => $message
];

$postData = [
    "messages" => $openAiMessages,
    "temperature" => 0.7,
    "model" => "openai"
];

// Pollinations API endpoint
$url = "https://text.pollinations.ai/";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
// Disable SSL verification for local XAMPP environments
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
// Add a strict timeout so the user doesn't wait forever if the API is down
curl_setopt($ch, CURLOPT_TIMEOUT, 15); 

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Basic Markdown to HTML parser
function parseMarkdown($text) {
    $text = htmlspecialchars($text);
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);
    $text = preg_replace('/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" style="color:#38bdf8;">$1</a>', $text);
    $text = preg_replace('/\n/', '<br>', $text);
    return $text;
}

// Intelligent Fallback System
function getFallbackResponse($msg) {
    $msg = strtolower($msg);
    if (strpos($msg, 'complain') !== false || strpos($msg, 'lodge') !== false || strpos($msg, 'issue') !== false || strpos($msg, 'problem') !== false || strpos($msg, 'register') !== false) {
        return "**How to Lodge a Complaint:**\n1. **Login** or **Register** an account.\n2. Go to your **Dashboard**.\n3. Click on **Lodge Complaint**.\n4. Select your grievance category, fill in the details, and submit.";
    } elseif (strpos($msg, 'track') !== false || strpos($msg, 'status') !== false || strpos($msg, 'check') !== false) {
        return "**How to Track Status:**\n1. Go to the **Track Grievance** page from the top menu.\n2. Enter your unique **Grievance Tracking ID**.\n3. Click Submit to see real-time updates.";
    } elseif (strpos($msg, 'hello') !== false || strpos($msg, 'hi') !== false || strpos($msg, 'hey') !== false) {
        return "Hello! I am currently operating in offline-lite mode due to high server traffic. However, I can still guide you on how to **lodge** or **track** complaints!";
    } elseif (strpos($msg, 'contact') !== false || strpos($msg, 'help') !== false || strpos($msg, 'admin') !== false) {
        return "You can reach out to our administration directly via the **Contact Us** page, or email us at info@nsti-ramanthapur.edu.in.";
    } elseif (strpos($msg, 'hindi') !== false || strpos($msg, 'telugu') !== false) {
        return "You can translate this entire website using the **Language Selector** at the top right of the page!";
    } else {
        return "I am experiencing heavy network traffic and my advanced AI core is temporarily resting. However, you can use the menus above to **Lodge Complaints**, **Track Status**, or **Contact Us** directly!";
    }
}

if ($httpCode == 200 && $response) {
    $responseData = json_decode($response, true);
    
    // Check if it's JSON (OpenAI compatible mode)
    if (json_last_error() === JSON_ERROR_NONE && isset($responseData['choices'][0]['message']['content'])) {
        $reply = $responseData['choices'][0]['message']['content'];
        echo json_encode(['reply' => parseMarkdown($reply)]);
    } 
    // Or if it returned plain text directly
    elseif (!empty($response)) {
        echo json_encode(['reply' => parseMarkdown($response)]);
    } 
    else {
        // Fallback
        echo json_encode(['reply' => parseMarkdown(getFallbackResponse($message))]);
    }
} else {
    // 504 Timeout, 429 Rate Limit, or curl error (0)
    // Instantly switch to offline fallback AI
    echo json_encode(['reply' => parseMarkdown(getFallbackResponse($message))]);
}
?>
