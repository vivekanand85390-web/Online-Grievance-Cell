<?php
include_once 'includes/functions.php';

// Ensure session is active for Captcha validation
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isLoggedIn()) {
    header("Location: user/dashboard.php");
    exit();
}

// Generate captcha code dynamically
if (isset($_GET['refresh_captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
    echo $_SESSION['captcha'];
    exit();
}

if (!isset($_SESSION['captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
}

$selected_role = isset($_GET['role']) ? sanitize($_GET['role']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $role = isset($_POST['role']) ? sanitize($_POST['role']) : '';
    $captcha = isset($_POST['captcha']) ? sanitize($_POST['captcha']) : '';

    if ($captcha !== $_SESSION['captcha']) {
        $_SESSION['msg'] = "Invalid Captcha code. Please try again.";
        $_SESSION['msg_type'] = "error";
    } elseif (empty($role)) {
        $_SESSION['msg'] = "Please select a portal role.";
        $_SESSION['msg_type'] = "error";
    } else {
        // Reset Captcha code to prevent reuse
        $_SESSION['captcha'] = strval(rand(1000, 9999));
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if (!empty($user['is_disabled'])) {
                $_SESSION['msg'] = "Your account has been disabled by an administrator.";
                $_SESSION['msg_type'] = "error";
            } elseif ($user['role'] !== $role) {
                $_SESSION['msg'] = "Role mismatch. Please select the correct role.";
                $_SESSION['msg_type'] = "error";
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'];

                if ($user['role'] === 'admin') {
                    $_SESSION['admin_type'] = $user['admin_type'];
                    $_SESSION['msg'] = "Welcome back, Administrator " . $user['name'] . "!";
                    $_SESSION['msg_type'] = "success";
                    header("Location: admin/dashboard.php");
                    exit();
                } else {
                    $_SESSION['msg'] = "Welcome back, " . $user['name'] . "!";
                    $_SESSION['msg_type'] = "success";
                    header("Location: user/dashboard.php");
                    exit();
                }
            }
        } else {
            $_SESSION['msg'] = "Invalid email or password.";
            $_SESSION['msg_type'] = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Online Grievance Redressal System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Google Fonts: Outfit -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Outfit', sans-serif;
            background-color: #f7f9fc;
            overflow: hidden;
        }

        .split-container {
            display: flex;
            height: 100vh;
            width: 100vw;
        }

        /* Left Side: Brand side */
        .brand-side {
            flex: 1.3;
            background-color: #0f3057;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 3rem;
            position: relative;
            overflow: hidden;
        }

        /* Arcs at bottom left */
        .brand-side::before {
            content: '';
            position: absolute;
            bottom: -150px;
            left: -150px;
            width: 380px;
            height: 380px;
            border-radius: 50%;
            background-color: #e05e19;
            z-index: 1;
            transform-origin: center;
            animation: pulseBottomLeft 10s ease-in-out infinite;
        }
        .brand-side::after {
            content: '';
            position: absolute;
            bottom: -130px;
            left: -130px;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background-color: #ffffff;
            z-index: 2;
            transform-origin: center;
            animation: pulseBottomLeft 10s ease-in-out infinite 1s;
        }

        /* Arcs at top right */
        .top-right-arc-1 {
            position: absolute;
            top: -220px;
            right: -220px;
            width: 520px;
            height: 520px;
            border-radius: 50%;
            background-color: #e05e19;
            z-index: 1;
            transform-origin: center;
            animation: pulseTopRight 12s ease-in-out infinite;
        }
        .top-right-arc-2 {
            position: absolute;
            top: -200px;
            right: -200px;
            width: 440px;
            height: 440px;
            border-radius: 50%;
            background-color: #0f3057;
            z-index: 2;
            transform-origin: center;
            animation: pulseTopRight 12s ease-in-out infinite 1.5s;
        }

        .brand-content {
            z-index: 5;
            text-align: center;
            max-width: 600px;
        }

        .welcome-tag {
            color: #e05e19;
            font-size: 1.8rem;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 0.5rem;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s cubic-bezier(0.25, 1, 0.5, 1) forwards;
            animation-delay: 0.2s;
        }

        .main-title {
            color: #ffffff;
            font-size: clamp(2.2rem, 3.5vw, 4.0rem);
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 1rem;
            letter-spacing: 0.5px;
            opacity: 0;
            transform: translateY(35px);
            animation: fadeInUp 0.8s cubic-bezier(0.25, 1, 0.5, 1) forwards;
            animation-delay: 0.4s;
            white-space: nowrap;
        }

        .sub-title {
            color: #ffcc00;
            font-size: clamp(1.6rem, 2.5vw, 2.6rem);
            font-weight: 800;
            line-height: 1.3;
            margin: 0;
            opacity: 0;
            transform: translateY(50px);
            animation: fadeInUp 0.8s cubic-bezier(0.25, 1, 0.5, 1) forwards;
            animation-delay: 0.6s;
        }

        @keyframes pulseBottomLeft {
            0%, 100% {
                transform: scale(1) translate(0, 0);
            }
            50% {
                transform: scale(1.05) translate(8px, 8px);
            }
        }

        @keyframes pulseTopRight {
            0%, 100% {
                transform: scale(1) translate(0, 0);
            }
            50% {
                transform: scale(1.04) translate(-8px, -8px);
            }
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .back-arrow {
            position: absolute;
            left: 40px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 2rem;
            color: rgba(255, 255, 255, 0.4);
            transition: all 0.3s ease;
            z-index: 10;
            text-decoration: none;
        }
        .back-arrow:hover {
            color: #ffffff;
            left: 32px;
        }

        /* Right Side: Form side */
        .form-side {
            flex: 0.9;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2.5rem;
            position: relative;
            z-index: 5;
            overflow-y: auto;
        }

        /* Form Card */
        .form-card {
            background-color: #ffffff;
            border-radius: 16px;
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.18);
            opacity: 0;
            transform: translateY(30px);
            animation: formCardFadeIn 0.8s cubic-bezier(0.25, 1, 0.5, 1) forwards;
            animation-delay: 0.5s;
        }

        @keyframes formCardFadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-card-title {
            font-size: 1.35rem;
            font-weight: 800;
            color: #121824;
            text-align: center;
            text-transform: uppercase;
            line-height: 1.4;
            margin-bottom: 2rem;
            letter-spacing: 0.3px;
        }

        .form-group {
            margin-bottom: 1.25rem;
            position: relative;
        }

        .form-input {
            width: 100%;
            background-color: #f8fafc;
            border: 1.5px solid #e2e8f0;
            color: #0f172a;
            padding: 0.7rem 1rem;
            font-size: 0.95rem;
            border-radius: 10px;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-input::placeholder {
            color: #94a3b8;
        }

        .form-input:focus {
            border-color: #0f3057;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(15, 48, 87, 0.12);
        }

        /* Dropdown styling */
        select.form-input {
            background-color: #f8fafc !important;
            color: #0f172a !important;
            appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23475569' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 10px;
            padding-right: 2.5rem;
        }

        /* Captcha and refresh styles */
        .captcha-canvas {
            background-color: #f1f5f9;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
        }
        .btn-refresh-captcha {
            background-color: #e05e19;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            height: 42px;
            width: 42px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.1rem;
            transition: background-color 0.2s;
        }
        .btn-refresh-captcha:hover {
            background-color: #c04e12;
            color: #ffffff;
        }

        .btn-login {
            background-color: #0f3057;
            color: #ffffff;
            font-weight: 800;
            font-size: 1rem;
            border: none;
            border-radius: 2rem;
            padding: 0.8rem;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(15, 48, 87, 0.2);
            margin-top: 1rem;
        }
        .btn-login:hover {
            background-color: #091c34;
            transform: translateY(-1px);
            box-shadow: 0 6px 15px rgba(15, 48, 87, 0.3);
        }

        /* Mobile layout adaptations */
        @media (max-width: 991px) {
            .brand-side {
                display: none;
            }
            .form-side {
                width: 100%;
                flex: 1;
                padding: 2rem 1rem;
            }
            body, html {
                overflow: auto;
            }
        }
    </style>
</head>
<body>

<div class="split-container">
    <!-- Left Side: Brand side -->
    <div class="brand-side">
        <!-- Corner decorations -->
        <div class="top-right-arc-1"></div>
        <div class="top-right-arc-2"></div>

        <!-- Float back button -->
        <a href="index.php" class="back-arrow">
            <i class="fas fa-chevron-left"></i>
        </a>

        <div class="brand-content">
            <p class="welcome-tag">WELCOME TO</p>
            <h1 class="main-title">NSTI R-HYDERABAD</h1>
            <h2 class="sub-title">Online Grievance Redressal System</h2>
        </div>
    </div>

    <!-- Right Side: Form side -->
    <div class="form-side">
        <div class="form-card">
            <h3 class="form-card-title">Login To Register A Grievance</h3>
            
            <form action="login.php" method="POST" id="loginForm">
                <div class="form-group">
                    <select name="role" id="role" class="form-input" required>
                        <option value="" disabled selected>-Select User-</option>
                        <option value="student" <?php echo $selected_role === 'student' ? 'selected' : ''; ?>>Student/Trainee</option>
                        <option value="parent" <?php echo $selected_role === 'parent' ? 'selected' : ''; ?>>Parent</option>
                        <option value="staff" <?php echo $selected_role === 'staff' ? 'selected' : ''; ?>>Staff/Faculty</option>
                        <option value="admin" <?php echo $selected_role === 'admin' ? 'selected' : ''; ?>>Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <input type="text" name="email" class="form-input" placeholder="Username/Email" required>
                </div>

                <div class="form-group">
                    <input type="password" name="password" class="form-input" placeholder="Password" required>
                </div>

                <!-- Captcha container -->
                <div class="form-group">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <canvas id="captchaCanvas" width="130" height="42" class="captcha-canvas"></canvas>
                        <button type="button" class="btn-refresh-captcha" onclick="refreshCaptcha()">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                    <input type="text" name="captcha" class="form-input" placeholder="Enter Captcha" required autocomplete="off">
                </div>

                <button type="submit" class="btn-login">Login</button>
            </form>

            <div class="text-center mt-4" style="font-size: 0.95rem;">
                <p class="mb-1 text-secondary" style="color: #64748b; font-weight: 500;">
                    Don't have an account? <a href="register.php?role=<?php echo $selected_role; ?>" style="color: #0f3057; font-weight: 700; text-decoration: none;">Register</a>
                </p>
                <a href="forgot_password.php" style="color: #0f3057; font-weight: 700; text-decoration: none;">Forgot Password?</a>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 and scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($_SESSION['msg'])): ?>
    <script>
        Swal.fire({
            icon: '<?php echo $_SESSION['msg_type']; ?>',
            title: '<?php echo $_SESSION['msg']; ?>',
            timer: 3000,
            showConfirmButton: false,
            background: '#ffffff',
            color: '#1e293b'
        });
    </script>
    <?php 
    unset($_SESSION['msg']); 
    unset($_SESSION['msg_type']); 
    ?>
<?php endif; ?>

<script>
// Captcha drawing function
let currentCaptcha = "<?php echo $_SESSION['captcha']; ?>";

function drawCaptcha(code) {
    const canvas = document.getElementById('captchaCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background
    ctx.fillStyle = '#f1f5f9';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add grid lines for noise
    for (let i = 0; i < 6; i++) {
        ctx.strokeStyle = `rgba(224, 94, 25, ${Math.random() * 0.3 + 0.1})`;
        ctx.lineWidth = Math.random() * 2 + 1;
        ctx.beginPath();
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.stroke();
    }
    
    // Add noise dots
    for (let i = 0; i < 40; i++) {
        ctx.fillStyle = `rgba(15, 48, 87, ${Math.random() * 0.4})`;
        ctx.beginPath();
        ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, Math.random() * 2, 0, 2 * Math.PI);
        ctx.fill();
    }
    
    // Draw text with distortions
    ctx.font = 'bold 24px "Outfit", sans-serif';
    ctx.textBaseline = 'middle';
    
    const chars = code.toString().split('');
    let xOffset = 20;
    
    chars.forEach((char, index) => {
        ctx.save();
        ctx.fillStyle = index % 2 === 0 ? '#0f3057' : '#e05e19';
        
        const angle = (Math.random() - 0.5) * 0.4; // between -11 and 11 deg
        const yOffset = 21 + (Math.random() - 0.5) * 6; // random vertical shift
        
        ctx.translate(xOffset, yOffset);
        ctx.rotate(angle);
        ctx.fillText(char, 0, 0);
        ctx.restore();
        
        xOffset += 24;
    });
}

function refreshCaptcha() {
    fetch('login.php?refresh_captcha=1')
        .then(response => response.text())
        .then(code => {
            currentCaptcha = code;
            drawCaptcha(code);
        });
}

// Dropdown change listener to reload page with selected role
const roleSelect = document.getElementById('role');
if (roleSelect) {
    roleSelect.addEventListener('change', function() {
        window.location.href = 'login.php?role=' + this.value;
    });
}

// Initial draw
window.addEventListener('load', () => {
    drawCaptcha(currentCaptcha);
});

// Form validation
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        const role = document.getElementById('role').value;
        const email = document.querySelector('input[name="email"]').value.trim();
        const password = document.querySelector('input[name="password"]').value.trim();
        const captcha = document.querySelector('input[name="captcha"]').value.trim();

        if (!role || email === '' || password === '' || captcha === '') {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Validation Error',
                text: 'Please fill in all the required fields correctly.',
                confirmButtonColor: '#0f3057',
                background: '#ffffff',
                color: '#1e293b'
            });
            return false;
        }
    });
}
</script>


<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>





