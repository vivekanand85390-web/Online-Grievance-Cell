<?php
include_once 'includes/functions.php';
include_once 'config/mail.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'includes/PHPMailer/PHPMailer.php';
require_once 'includes/PHPMailer/SMTP.php';
require_once 'includes/PHPMailer/Exception.php';

if (session_status() === PHP_SESSION_NONE) session_start();

if (isLoggedIn()) {
    header("Location: user/dashboard.php");
    exit();
}

// Generate captcha
if (isset($_GET['refresh_captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
    echo $_SESSION['captcha'];
    exit();
}
if (!isset($_SESSION['captcha'])) {
    $_SESSION['captcha'] = strval(rand(1000, 9999));
}

$selected_role = isset($_GET['role']) ? sanitize($_GET['role']) : 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username         = sanitize($_POST['username']         ?? '');
    $name             = sanitize($_POST['name']             ?? '');
    $email            = sanitize($_POST['email']            ?? '');
    $password         = $_POST['password']                  ?? '';
    $confirm_password = $_POST['confirm_password']          ?? '';
    $role             = sanitize($_POST['role']             ?? 'student');
    $gender           = sanitize($_POST['gender']           ?? '');
    $contact          = sanitize($_POST['contact']          ?? '');
    $dob              = sanitize($_POST['dob']              ?? '');
    $address          = sanitize($_POST['address']          ?? '');
    $city             = sanitize($_POST['city']             ?? '');
    $pincode          = sanitize($_POST['pincode']          ?? '');
    $state            = sanitize($_POST['state']            ?? '');
    $roll_no          = sanitize($_POST['roll_no']          ?? '');
    $trade            = sanitize($_POST['trade']            ?? '');
    $captcha          = sanitize($_POST['captcha']          ?? '');

    // Validations
    if ($captcha !== ($_SESSION['captcha'] ?? '')) {
        $_SESSION['msg'] = 'Invalid Captcha. Please try again.';
        $_SESSION['msg_type'] = 'error';
    } elseif ($password !== $confirm_password) {
        $_SESSION['msg'] = 'Passwords do not match.';
        $_SESSION['msg_type'] = 'error';
    } elseif (empty($username)||empty($name)||empty($email)||empty($password)||empty($gender)||empty($contact)||empty($dob)||empty($address)||empty($city)||empty($pincode)||empty($state)||empty($trade)) {
        $_SESSION['msg'] = 'Please fill all required fields.';
        $_SESSION['msg_type'] = 'error';
    } elseif (!preg_match('/^[a-zA-Z0-9_ ]{3,20}$/', $username)) {
        $_SESSION['msg'] = 'User ID must be 3-20 characters long and contain only letters, numbers, spaces, and underscores.';
        $_SESSION['msg_type'] = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['msg'] = 'Invalid email address.';
        $_SESSION['msg_type'] = 'error';
    } else {
        // Check duplicate username
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $_SESSION['msg'] = 'This User ID / Username is already taken.';
            $_SESSION['msg_type'] = 'error';
        } else {
            // Check duplicate email
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $_SESSION['msg'] = 'This email is already registered.';
                $_SESSION['msg_type'] = 'error';
            } else {
                // Create account
                if (!in_array($role, ['student','staff','parent','admin'])) $role = 'student';
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $admin_type = ($role === 'admin') ? 'department' : null;

                $stmt = $pdo->prepare("INSERT INTO users (username,name,email,gender,password,role,contact,dob,address,city,pincode,state,admin_type,roll_no,trade) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                if ($stmt->execute([$username,$name,$email,$gender,$hashed,$role,$contact,$dob,$address,$city,$pincode,$state,$admin_type,$roll_no,$trade])) {
                    $_SESSION['msg'] = 'Registration successful! Please login.';
                    $_SESSION['msg_type'] = 'success';
                    $_SESSION['captcha'] = strval(rand(1000, 9999)); // reset captcha
                    header("Location: login.php?role=" . $role);
                    exit();
                } else {
                    $_SESSION['msg'] = 'Registration failed. Please try again.';
                    $_SESSION['msg_type'] = 'error';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Online Grievance Redressal System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-image: linear-gradient(rgba(15,48,87,0.88), rgba(30,27,75,0.93)), url('assets/images/grievance_keyboard_bg.png');
            background-size: cover; background-position: center;
            background-repeat: no-repeat; background-attachment: fixed;
            min-height: 100vh; display: flex; align-items: center;
            justify-content: center; padding: 2.5rem 1rem;
            color: #1e293b; overflow-x: hidden;
            position: relative;
        }

        /* Glowing Background Blobs */
        .bg-blob {
            position: absolute;
            width: 450px;
            height: 450px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(224,94,25,0.2) 0%, rgba(176,28,112,0.05) 70%);
            filter: blur(80px);
            z-index: 1;
            pointer-events: none;
            animation: pulseBlob 15s ease-in-out infinite;
        }
        .bg-blob-1 {
            top: 5%;
            left: -10%;
        }
        .bg-blob-2 {
            bottom: 5%;
            right: -10%;
            animation-delay: -5s;
            background: radial-gradient(circle, rgba(15,48,87,0.25) 0%, rgba(30,27,75,0.05) 70%);
        }
        @keyframes pulseBlob {
            0%, 100% { transform: scale(1) translate(0, 0); }
            50% { transform: scale(1.1) translate(20px, 30px); }
        }

        .btn-corner-home {
            position: absolute; top: 2rem; left: 2rem;
            background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.25);
            padding: 0.6rem 1.5rem; border-radius: 2rem; text-decoration: none;
            color: #ffffff; font-weight: 600; display: inline-flex;
            align-items: center; gap: 0.5rem; transition: all 0.25s ease;
            backdrop-filter: blur(10px); z-index: 10;
        }
        .btn-corner-home:hover { color:#fff; background:rgba(255,255,255,0.25); border-color:#e05e19; transform:translateX(-3px); }
        
        .register-container { width:100%; max-width:980px; margin:auto; position:relative; z-index:5; }
        
        .register-card {
            background-color: rgba(255,255,255,0.95); backdrop-filter: blur(15px);
            border-radius: 24px; padding: 3.5rem 3rem;
            box-shadow: 0 20px 60px rgba(0,0,0,0.35);
            border: 1px solid rgba(255,255,255,0.3);
            opacity: 0; transform: translateY(40px);
            animation: cardFadeIn 0.8s cubic-bezier(0.25,1,0.5,1) forwards;
        }
        .page-title {
            background: linear-gradient(135deg,#e05e19,#b01c70);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            font-size: 2.5rem; font-weight: 800; text-align: center;
            margin-bottom: 0.5rem; opacity: 0; transform: translateY(20px);
            animation: textFadeIn 0.8s cubic-bezier(0.25,1,0.5,1) forwards 0.3s;
        }
        @keyframes cardFadeIn { to { opacity:1; transform:translateY(0); } }
        @keyframes textFadeIn  { to { opacity:1; transform:translateY(0); } }
        
        .title-divider {
            height: 3px;
            background: linear-gradient(90deg,transparent,#e05e19,#b01c70,transparent);
            margin-bottom: 2.5rem; border-radius: 2px;
        }
        
        .section-header-custom {
            color: #0f3057; font-size: 1.25rem; font-weight: 800;
            margin-top: 2rem; margin-bottom: 1.5rem;
            padding-left: 12px; border-left: 4px solid #e05e19;
            text-transform: uppercase; letter-spacing: 0.5px;
        }

        .section-header-custom.accent-purple {
            border-left-color: #b01c70;
        }

        .form-label { font-weight:700; font-size:0.88rem; color:#0f3057; margin-bottom:0.5rem; }
        .text-danger-custom { color:#ef4444; font-weight:bold; margin-left:2px; }
        
        .input-wrapper-custom {
            position: relative;
            display: flex;
            align-items: center;
            width: 100%;
        }
        .input-wrapper-custom i {
            position: absolute;
            left: 16px;
            color: #94a3b8;
            font-size: 0.95rem;
            transition: color 0.25s ease, transform 0.25s ease;
            pointer-events: none;
            z-index: 5;
        }

        .form-control-custom {
            width:100%; height:48px; padding:10px 16px 10px 42px; font-size:0.95rem;
            color:#1e293b; background-color:#f8fafc; border:1.5px solid #cbd5e1;
            border-radius:12px; transition:all 0.25s ease-in-out;
        }
        .form-control-custom:focus {
            outline:none; border-color:#e05e19; background:#fff;
            box-shadow:0 0 0 4px rgba(224,94,25,0.15);
        }
        .form-control-custom:focus + i {
            color: #e05e19;
            transform: scale(1.1);
        }
        .form-control-custom::placeholder { color:#94a3b8; }
        
        select.form-control-custom {
            appearance:none;
            background-image:url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%230f3057' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat:no-repeat; background-position:right 1rem center; background-size:12px; padding-right:2.5rem;
        }
        
        .textarea-custom { height:48px; resize:none; line-height:1.4; }
        .captcha-canvas-custom { border:1.5px solid #cbd5e1; border-radius:10px; background-color:#f8fafc; }
        .btn-refresh-custom {
            background-color:#e05e19; color:#ffffff; border:none; border-radius:10px;
            height:42px; width:42px; display:flex; justify-content:center;
            align-items:center; font-size:1.05rem; transition:background-color 0.2s;
        }
        .btn-refresh-custom:hover { background-color:#c04e12; }
        
        .btn-submit-custom {
            background: linear-gradient(135deg,#e05e19,#b01c70);
            color:#ffffff; font-weight:800; font-size:1.1rem; border:none;
            border-radius:2rem; padding:0.95rem 3rem; width:auto;
            min-width:320px; max-width:100%; transition:all 0.3s ease;
            box-shadow:0 8px 25px rgba(224,94,25,0.35);
            margin:2.5rem auto 0 auto; display:block;
            text-transform:uppercase; letter-spacing:1px; cursor:pointer;
        }
        .btn-submit-custom:hover { transform:translateY(-2px); box-shadow:0 12px 30px rgba(224,94,25,0.5); filter:brightness(1.08); }
        .btn-submit-custom:disabled { opacity:0.65; cursor:not-allowed; transform:none; }
        
        .back-link-container { text-align:center; margin-top:1.5rem; font-weight:500; }
        .back-link-container a { color:#e05e19; font-weight:700; text-decoration:none; }
        .back-link-container a:hover { text-decoration:underline; }

        @media (max-width:991px) {
            body { padding-top:6rem; }
            .btn-corner-home { top:1.5rem; left:1.5rem; }
            .register-card { padding:2.5rem 2rem; }
        }
    </style>
</head>
<body>

    <!-- Glowing Background Blobs -->
    <div class="bg-blob bg-blob-1"></div>
    <div class="bg-blob bg-blob-2"></div>

    <a href="index.php" class="btn-corner-home">
        <i class="fas fa-chevron-left"></i> <span class="notranslate custom-translate-home">Home</span>
    </a>

    <div class="register-container">
        <div class="register-card">
            <h1 class="page-title">Registration</h1>
            <div class="title-divider"></div>

            <form action="register.php" method="POST" id="registerForm">
                
                <div class="section-header-custom">Account Credentials:</div>
                
                <!-- Stakeholder, User ID, Email -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <label class="form-label" for="role">Stakeholder<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <select name="role" id="role" class="form-control-custom" required>
                                <option value="student" <?= $selected_role==='student'?'selected':'' ?>>Student</option>
                                <option value="parent"  <?= $selected_role==='parent' ?'selected':'' ?>>Parent</option>
                                <option value="staff"   <?= $selected_role==='staff'  ?'selected':'' ?>>Staff</option>
                                <option value="admin"   <?= $selected_role==='admin'  ?'selected':'' ?>>Admin</option>
                            </select>
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="username">User ID (Username)<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="username" id="username" class="form-control-custom" placeholder="Choose User ID" required autocomplete="off" pattern="[a-zA-Z0-9_ ]{3,20}" title="3-20 characters: letters, numbers, spaces, and underscores only">
                            <i class="fas fa-user-tag"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="email">Email Id<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="email" name="email" id="email" class="form-control-custom" placeholder="Student Email Id" required>
                            <i class="fas fa-envelope"></i>
                        </div>
                    </div>
                </div>

                <!-- Password & Confirm Password -->
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <label class="form-label" for="password">Password<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="password" name="password" id="password" class="form-control-custom" placeholder="Enter Password" required minlength="6">
                            <i class="fas fa-lock"></i>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="confirm_password">Confirm Password<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="password" name="confirm_password" id="confirm_password" class="form-control-custom" placeholder="Confirm Password" required>
                            <i class="fas fa-lock"></i>
                        </div>
                    </div>
                </div>

                <div class="section-header-custom accent-purple">Personal Details:</div>

                <!-- Name, Gender, DOB -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <label class="form-label" for="name">Full Name<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="name" id="name" class="form-control-custom" placeholder="Student Name" required>
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="gender">Gender<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <select name="gender" id="gender" class="form-control-custom" required>
                                <option value="" disabled selected>--Select--</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                            <i class="fas fa-venus-mars"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="dob">Date of Birth<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="date" name="dob" id="dob" class="form-control-custom" required>
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                    </div>
                </div>

                <!-- Mobile, City, Pincode -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <label class="form-label" for="contact">Mobile No<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="contact" id="contact" class="form-control-custom" placeholder="Mobile No" required pattern="\d{10}" title="Please enter a valid 10-digit mobile number">
                            <i class="fas fa-phone"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="city">City<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="city" id="city" class="form-control-custom" placeholder="City" required>
                            <i class="fas fa-city"></i>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="pincode">Pin Code<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="pincode" id="pincode" class="form-control-custom" placeholder="Pin Code" required pattern="\d{6}" title="Please enter a valid 6-digit pin code">
                            <i class="fas fa-map-pin"></i>
                        </div>
                    </div>
                </div>

                <!-- Roll No and Trade -->
                <div class="row g-4 mb-4" id="academic_details_row">
                    <div class="col-md-6">
                        <label class="form-label" for="roll_no">Roll No</label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="roll_no" id="roll_no" class="form-control-custom" placeholder="Roll No">
                            <i class="fas fa-id-card"></i>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="trade">Trade<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <input type="text" name="trade" id="trade" class="form-control-custom" placeholder="Trade (e.g., CSA)" required>
                            <i class="fas fa-briefcase"></i>
                        </div>
                    </div>
                </div>

                <!-- State & Address -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <label class="form-label" for="state">State<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <select name="state" id="state" class="form-control-custom" required>
                                <option value="">Select State</option>
                                <option>Andaman and Nicobar Islands</option><option>Andhra Pradesh</option>
                                <option>Arunachal Pradesh</option><option>Assam</option><option>Bihar</option>
                                <option>Chandigarh</option><option>Chhattisgarh</option>
                                <option>Dadra and Nagar Haveli and Daman and Diu</option><option>Delhi</option>
                                <option>Goa</option><option>Gujarat</option><option>Haryana</option>
                                <option>Himachal Pradesh</option><option>Jammu and Kashmir</option>
                                <option>Jharkhand</option><option>Karnataka</option><option>Kerala</option>
                                <option>Ladakh</option><option>Lakshadweep</option>
                                <option>Madhya Pradesh</option><option>Maharashtra</option><option>Manipur</option>
                                <option>Meghalaya</option><option>Mizoram</option><option>Nagaland</option>
                                <option>Odisha</option><option>Puducherry</option><option>Punjab</option>
                                <option>Rajasthan</option><option>Sikkim</option><option>Tamil Nadu</option>
                                <option>Telangana</option><option>Tripura</option><option>Uttar Pradesh</option>
                                <option>Uttarakhand</option><option>West Bengal</option>
                            </select>
                            <i class="fas fa-map"></i>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label" for="address">Address<span class="text-danger-custom">*</span></label>
                        <div class="input-wrapper-custom">
                            <textarea name="address" id="address" class="form-control-custom textarea-custom" placeholder="Address" required></textarea>
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                    </div>
                </div>

                <!-- Captcha -->
                <div class="row mb-4">
                    <div class="col-md-6 mx-auto text-center">
                        <label class="form-label d-block">Captcha Code<span class="text-danger-custom">*</span></label>
                        <div class="d-flex align-items-center justify-content-center gap-3">
                            <canvas id="captchaCanvas" width="130" height="42" class="captcha-canvas-custom" style="flex-shrink:0;"></canvas>
                            <button type="button" class="btn-refresh-custom" onclick="refreshCaptcha()" style="flex-shrink:0;">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                            <div class="input-wrapper-custom" style="width: 160px;">
                                <input type="text" name="captcha" class="form-control-custom" placeholder="Enter Captcha" required autocomplete="off"
                                       style="height:42px;text-align:center;border-radius:10px;padding-left:10px !important;">
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit-custom" id="btnSubmit">Register Now</button>
            </form>

            <div class="back-link-container">
                Already have an account? <a href="login.php" id="login_link">Login</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if (isset($_SESSION['msg'])): ?>
    <script>
        Swal.fire({
            icon: '<?= $_SESSION['msg_type'] ?>',
            title: '<?= $_SESSION['msg'] ?>',
            timer: 3000,
            showConfirmButton: false,
            background: '#ffffff',
            color: '#1e293b'
        });
    </script>
    <?php 
    unset($_SESSION['msg']); 
    unset($_SESSION['msg_type']); 
    ?>
    <?php endif; ?>

    <script>
    // â”€â”€ Captcha â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    let currentCaptcha = "<?= $_SESSION['captcha'] ?>";
    function drawCaptcha(code) {
        const canvas = document.getElementById('captchaCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#f8fafc'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < 6; i++) {
            ctx.strokeStyle = `rgba(224,94,25,${Math.random()*0.3+0.1})`;
            ctx.lineWidth = Math.random()*2+1; ctx.beginPath();
            ctx.moveTo(Math.random()*canvas.width, Math.random()*canvas.height);
            ctx.lineTo(Math.random()*canvas.width, Math.random()*canvas.height); ctx.stroke();
        }
        for (let i = 0; i < 40; i++) {
            ctx.fillStyle = `rgba(15,48,87,${Math.random()*0.4})`; ctx.beginPath();
            ctx.arc(Math.random()*canvas.width, Math.random()*canvas.height, Math.random()*2, 0, 2*Math.PI); ctx.fill();
        }
        ctx.font = 'bold 24px "Outfit",sans-serif'; ctx.textBaseline = 'middle';
        let x = 20;
        code.toString().split('').forEach((ch, i) => {
            ctx.save(); ctx.fillStyle = i%2===0?'#0f3057':'#e05e19';
            ctx.translate(x, 21+(Math.random()-0.5)*6); ctx.rotate((Math.random()-0.5)*0.4);
            ctx.fillText(ch, 0, 0); ctx.restore(); x += 24;
        });
    }
    function refreshCaptcha() {
        fetch('register.php?refresh_captcha=1').then(r=>r.text()).then(code=>{ currentCaptcha=code; drawCaptcha(code); });
    }

    // â”€â”€ Role placeholders â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    const roleEl = document.getElementById('role');
    const nameEl = document.getElementById('name');
    const emailEl= document.getElementById('email');
    const usernameEl = document.getElementById('username');
    const llEl   = document.getElementById('login_link');
    
    function updateMeta() {
        const role = roleEl?.value;
        const t = role==='staff'?'Staff':role==='parent'?'Parent':role==='admin'?'Admin':'Student';
        if (nameEl) nameEl.placeholder = t + ' Name';
        if (emailEl) emailEl.placeholder = t + ' Email Id';
        if (usernameEl) usernameEl.placeholder = 'Choose ' + t + ' User ID';
        if (llEl) llEl.href = 'login.php?role=' + role;

        // Roll No & Trade dynamic labels
        const rollLabel = document.querySelector('label[for="roll_no"]');
        const tradeLabel = document.querySelector('label[for="trade"]');
        const rollInput = document.getElementById('roll_no');
        const tradeInput = document.getElementById('trade');

        if (role === 'staff') {
            if (rollLabel) rollLabel.innerHTML = 'Employee ID';
            if (tradeLabel) tradeLabel.innerHTML = 'Designation<span class="text-danger-custom">*</span>';
            if (rollInput) {
                rollInput.placeholder = 'Employee ID';
                if (!rollInput.value.startsWith('EMP')) {
                    rollInput.value = 'EMP' + Math.floor(100000 + Math.random() * 900000);
                }
                rollInput.readOnly = true;
                rollInput.style.backgroundColor = '#e2e8f0';
                rollInput.style.cursor = 'not-allowed';
            }
            if (tradeInput) tradeInput.placeholder = 'e.g. M.T.S, Clerk, etc.';
        } else {
            if (rollLabel) rollLabel.innerHTML = 'Roll No';
            if (tradeLabel) tradeLabel.innerHTML = 'Trade<span class="text-danger-custom">*</span>';
            if (rollInput) {
                rollInput.placeholder = 'Roll No';
                if (rollInput.value.startsWith('EMP')) {
                    rollInput.value = '';
                }
                rollInput.readOnly = false;
                rollInput.style.backgroundColor = '';
                rollInput.style.cursor = '';
            }
            if (tradeInput) tradeInput.placeholder = 'Trade (e.g., CSA)';
        }
    }
    
    roleEl?.addEventListener('change', () => { window.location.href = 'register.php?role=' + roleEl.value; });
    window.addEventListener('load', () => { drawCaptcha(currentCaptcha); updateMeta(); });

    // Form Validation
    document.getElementById('registerForm').addEventListener('submit', function(e) {
        const password = document.getElementById('password').value;
        const confirm_password = document.getElementById('confirm_password').value;

        if (password !== confirm_password) {
            e.preventDefault();
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                text: 'Passwords do not match.',
                confirmButtonColor: '#e05e19'
            });
        }
    });
    </script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script src="assets/js/chatbot.js"></script>

</body>
</html>





