// assets/js/chatbot.js

let chatHistory = [];

function toggleChatbot() {
    const container = document.getElementById('chatbotContainer');
    container.classList.toggle('active');
}

function handleChatKeypress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendChatMessage();
    }
}

async function sendChatMessage() {
    const inputField = document.getElementById('chatInput');
    const message = inputField.value.trim();
    if (!message) return;

    // Clear input
    inputField.value = '';

    // Append user message to UI
    appendMessage(message, 'user');

    // Show loading
    const loadingEl = document.getElementById('chatLoading');
    loadingEl.classList.add('show');

    // Scroll to bottom
    scrollToBottom();

    try {
        // Send to API
        const response = await fetch(window.chatApiPath || 'chat_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message, history: chatHistory })
        });

        const data = await response.json();
        
        // Hide loading
        loadingEl.classList.remove('show');

        if (data.reply) {
            appendMessage(data.reply, 'bot');
            
            // Save to history
            chatHistory.push({ role: 'user', content: message });
            chatHistory.push({ role: 'bot', content: data.reply });
        } else if (data.error) {
            appendMessage("Error: " + data.error, 'bot');
            
            // If it's a rate limit error, disable input and start countdown
            if (data.error.includes("Rate Limit")) {
                let timeLeft = 60;
                inputField.disabled = true;
                const sendBtn = document.querySelector('.chatbot-input button');
                sendBtn.disabled = true;
                
                const countdownInterval = setInterval(() => {
                    inputField.placeholder = "Please wait " + timeLeft + "s...";
                    timeLeft--;
                    
                    if (timeLeft < 0) {
                        clearInterval(countdownInterval);
                        inputField.disabled = false;
                        sendBtn.disabled = false;
                        inputField.placeholder = "Type your message...";
                    }
                }, 1000);
            }
        } else {
            appendMessage("Sorry, I couldn't understand that.", 'bot');
        }

    } catch (error) {
        loadingEl.classList.remove('show');
        appendMessage("Network error. Please try again later.", 'bot');
        console.error('Chatbot API Error:', error);
    }
}

function appendMessage(text, sender) {
    const chatBody = document.getElementById('chatBody');
    const loadingEl = document.getElementById('chatLoading');
    
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${sender}`;
    msgDiv.innerHTML = text; // Using innerHTML because API returns simple parsed HTML (like bold, links, br)

    // Insert before the loading animation
    chatBody.insertBefore(msgDiv, loadingEl);
    
    scrollToBottom();
}

function scrollToBottom() {
    const chatBody = document.getElementById('chatBody');
    chatBody.scrollTop = chatBody.scrollHeight;
}

