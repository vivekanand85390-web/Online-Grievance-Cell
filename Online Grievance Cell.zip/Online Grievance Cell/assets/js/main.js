// assets/js/main.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Online Grievance System Initialized');

    // Tooltips initialization
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alert messages if any
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle delete confirmations with SweetAlert
    window.confirmDelete = (url, message = 'Are you sure you want to delete this?') => {
        Swal.fire({
            title: 'Wait!',
            text: message,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#6366f1',
            cancelButtonColor: '#94a3b8',
            confirmButtonText: 'Yes, proceed'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    };

    // Portal Sidebar Responsive Toggle logic for mobile viewports
    const toggleBtn = document.getElementById("sidebarCollapse");
    const sidebar = document.querySelector(".portal-sidebar");
    
    if (toggleBtn && sidebar) {
        // Create backdrop dynamically so we don't have to duplicate HTML across portals
        const backdrop = document.createElement("div");
        backdrop.className = "portal-backdrop";
        document.body.appendChild(backdrop);
        
        toggleBtn.addEventListener("click", function(e) {
            e.preventDefault();
            sidebar.classList.toggle("show");
            backdrop.classList.toggle("show");
        });
        
        backdrop.addEventListener("click", function() {
            sidebar.classList.remove("show");
            backdrop.classList.remove("show");
        });
        
        // Auto-close sidebar on menu link clicks
        const menuLinks = document.querySelectorAll(".portal-menu-link");
        menuLinks.forEach(link => {
            link.addEventListener("click", function() {
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove("show");
                    backdrop.classList.remove("show");
                }
            });
        });
    }
});
