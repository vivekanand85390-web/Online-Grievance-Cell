// assets/js/accessibility.js

document.addEventListener('DOMContentLoaded', function() {
    const decBtn = document.getElementById('decText');
    const resBtn = document.getElementById('resText');
    const incBtn = document.getElementById('incText');
    const htmlElement = document.documentElement;

    // Load saved font size from localStorage
    const savedSize = localStorage.getItem('siteFontSize');
    if (savedSize) {
        applyFontSize(savedSize);
    } else {
        updateActiveState('md'); // Default state highlight
    }

    if (decBtn) {
        decBtn.addEventListener('click', function(e) {
            e.preventDefault();
            applyFontSize('sm');
        });
    }

    if (resBtn) {
        resBtn.addEventListener('click', function(e) {
            e.preventDefault();
            applyFontSize('md');
        });
    }

    if (incBtn) {
        incBtn.addEventListener('click', function(e) {
            e.preventDefault();
            applyFontSize('lg');
        });
    }

    function applyFontSize(size) {
        // Remove all size classes first
        htmlElement.classList.remove('font-size-sm', 'font-size-md', 'font-size-lg');
        
        // Add the target size class
        if (size === 'sm') {
            htmlElement.classList.add('font-size-sm');
        } else if (size === 'md') {
            htmlElement.classList.add('font-size-md');
        } else if (size === 'lg') {
            htmlElement.classList.add('font-size-lg');
        }
        
        // Save to localStorage
        localStorage.setItem('siteFontSize', size);

        // Highlight active link/button
        updateActiveState(size);
    }

    function updateActiveState(activeSize) {
        const buttons = [
            { el: decBtn, size: 'sm' },
            { el: resBtn, size: 'md' },
            { el: incBtn, size: 'lg' }
        ];

        buttons.forEach(btn => {
            if (btn.el) {
                if (btn.size === activeSize) {
                    btn.el.classList.add('active');
                } else {
                    btn.el.classList.remove('active');
                }
            }
        });
    }
});
