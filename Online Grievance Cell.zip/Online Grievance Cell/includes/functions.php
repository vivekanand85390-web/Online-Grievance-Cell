<?php
// includes/functions.php - Global utility functions

session_start();

// Include database configuration
include_once __DIR__ . '/../config/db.php';

// Global handler to mark notifications as read
if (isset($_SESSION['user_id']) && isset($_GET['clear_notifications'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $url = strtok($_SERVER["REQUEST_URI"], '?');
    header("Location: $url");
    exit();
}

/**
 * Sanitize input to prevent XSS
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if logged in user is admin
 */
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Redirect with a message
 */
function redirect($url, $msg = '', $type = 'info') {
    if ($msg) {
        $_SESSION['msg'] = $msg;
        $_SESSION['msg_type'] = $type;
    }
    header("Location: $url");
    exit();
}

/**
 * Generate a unique complaint ID
 */
function generateComplaintID() {
    return 'GRV' . date('Ymd') . rand(1000, 9999);
}

/**
 * Get status badge class
 */
function getStatusBadge($status) {
    switch ($status) {
        case 'Pending': return 'badge bg-warning text-dark';
        case 'In Progress': return 'badge bg-info';
        case 'Resolved': return 'badge bg-success';
        case 'Rejected': return 'badge bg-danger';
        default: return 'badge bg-secondary';
    }
}

/**
 * Get priority badge class
 */
function getPriorityBadge($priority) {
    switch ($priority) {
        case 'Low': return 'badge bg-secondary';
        case 'Medium': return 'badge bg-primary';
        case 'High': return 'badge bg-danger';
        default: return 'badge bg-info';
    }
}

/**
 * Map internal DB status to displayed status name from flow diagram
 */
function getStatusLabel($status) {
    switch ($status) {
        case 'Pending': return 'Not Processed';
        case 'In Progress': return 'Under Process';
        case 'Resolved': return 'Resolved Complaint';
        case 'Rejected': return 'Rejected Complaint';
        default: return $status;
    }
}

/**
 * Dynamic calculation of the current level of a complaint based on age.
 * - Under 7 days: Department Admin
 * - 7 to 13 days: College Admin
 * - 14 days and older: University Admin
 */
function getComplaintEscalationLevel($created_at, $status) {
    $created_time = strtotime($created_at);
    $days_old = floor((time() - $created_time) / (60 * 60 * 24));
    
    if ($days_old >= 14) {
        return 'university';
    } elseif ($days_old >= 7) {
        return 'college';
    } else {
        return 'department';
    }
}

/**
 * Get visual badge for the escalation level
 */
function getEscalationBadge($level) {
    switch ($level) {
        case 'department': return 'badge bg-info text-dark';
        case 'college': return 'badge bg-warning text-dark';
        case 'university': return 'badge bg-danger';
        default: return 'badge bg-secondary';
    }
}

/**
 * Get human-readable name for the escalation level
 */
function getEscalationLabel($level) {
    switch ($level) {
        case 'department': return 'Department Level';
        case 'college': return 'College Level';
        case 'university': return 'University Level';
        default: return 'Main Admin';
    }
}
?>
