<?php
// ─────────────────────────────────────────────
//  SMS Helper — Fast2SMS API
//  Sends OTP SMS to Indian mobile numbers
// ─────────────────────────────────────────────

require_once __DIR__ . '/../config/sms_config.php';

/**
 * Send OTP via Fast2SMS
 *
 * @param  string $phone  10-digit Indian mobile number (no +91)
 * @param  string $otp    6-digit OTP
 * @return array  ['success' => bool, 'message' => string]
 */
function sendOtpSms($phone, $otp) {

    // Clean phone number — strip +91, spaces, dashes
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) === 12 && substr($phone, 0, 2) === '91') {
        $phone = substr($phone, 2); // strip leading 91
    }

    if (strlen($phone) !== 10) {
        return ['success' => false, 'message' => 'Invalid phone number format.'];
    }

    $apiKey = FAST2SMS_API_KEY;
    if (empty($apiKey) || $apiKey === 'YOUR_FAST2SMS_API_KEY_HERE') {
        return ['success' => false, 'message' => 'SMS API Key is not configured in config/sms_config.php.'];
    }

    // Fast2SMS DLT / Quick SMS endpoint
    $url = 'https://www.fast2sms.com/dev/bulkV2';

    $message = "Your OTP for NSTI Grievance Portal password reset is: {$otp}. Valid for 10 minutes. Do not share with anyone.";

    $fields = [
        'route'        => FAST2SMS_ROUTE,
        'sender_id'    => FAST2SMS_SENDER_ID,
        'message'      => $message,
        'language'     => 'english',
        'flash'        => 0,
        'numbers'      => $phone,
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($fields),
        CURLOPT_HTTPHEADER     => [
            'authorization: ' . $apiKey,
            'Content-Type: application/json',
            'Accept: */*',
            'Cache-Control: no-cache',
        ],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        error_log("Fast2SMS cURL error: " . $curlError);
        return ['success' => false, 'message' => 'SMS service unavailable. Please try again.'];
    }

    $result = json_decode($response, true);

    if (isset($result['return']) && $result['return'] === true) {
        return ['success' => true, 'message' => 'OTP sent successfully.'];
    }

    // Log the failure for debugging
    error_log("Fast2SMS API error: " . $response);
    $errMsg = 'Failed to send OTP. Please try again.';
    if (isset($result['message'])) {
        if (is_array($result['message'])) {
            $errMsg = $result['message'][0] ?? $errMsg;
        } else {
            $errMsg = $result['message'];
        }
    }
    return ['success' => false, 'message' => $errMsg];
}
