<?php
// includes/accessibility_bar.php
if (!isset($base_path)) {
    $current_dir = basename(dirname($_SERVER['PHP_SELF']));
    $base_path = ($current_dir === 'user' || $current_dir === 'admin') ? '../' : '';
}

// Check if we are inside a portal dashboard or standard layout
$is_portal = ($current_dir === 'user' || $current_dir === 'admin') && isLoggedIn();
$container_class = $is_portal ? 'container-fluid px-4' : 'container';
?>
<div class="accessibility-bar" style="position: relative; z-index: 9999;">
    <div id="google_translate_element" style="display:none;"></div>
    <div class="<?php echo $container_class; ?> d-flex justify-content-end align-items-center gap-3">
        <!-- Text Size Controls -->
        <div class="text-size-controls notranslate d-flex align-items-center" title="Text Size">
            <span class="me-2" style="color: #ffffff; font-size: 0.85rem; font-weight: 500; letter-spacing: 0.5px;">Text Size:</span>
            <a href="#" class="text-size-btn" id="decText" aria-label="Decrease text size">A-</a>
            <a href="#" class="text-size-btn active" id="resText" aria-label="Normal text size">A</a>
            <a href="#" class="text-size-btn" id="incText" aria-label="Increase text size">A+</a>
        </div>
        
        <div class="d-flex align-items-center gap-2 notranslate" title="Select Language">
            
            <div class="dropdown custom-lang-dropdown notranslate">
                <button class="btn btn-sm dropdown-toggle d-flex align-items-center gap-2 notranslate premium-glass-btn" type="button" id="languageDropdownBtn" data-bs-toggle="dropdown" aria-expanded="false" style="background: transparent; color: #ffffff !important; border: none; border-radius: 50px; padding: 5px 16px; font-weight: 500; font-size: 0.85rem; letter-spacing: 0.5px; transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);">
                    <!-- Custom SVG Translate Icon -->
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style="filter: drop-shadow(0 2px 2px rgba(0,0,0,0.1));">
                        <path d="M4.545 6.714 4.11 8H3l1.862-5h1.284L8 8H6.833l-.435-1.286H4.545zm1.634-.736L5.5 3.956h-.049l-.679 2.022H6.18z"/>
                        <path d="M0 2a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v3h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-3H2a2 2 0 0 1-2-2V2zm2-1a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H2zm7.138 9.995c.193.301.402.583.63.846-.748.575-1.673 1.001-2.768 1.292.178.217.451.635.555.867 1.125-.359 2.08-.844 2.886-1.494.777.665 1.739 1.165 2.93 1.472.133-.254.414-.673.629-.89-1.125-.253-2.057-.694-2.82-1.284.681-.747 1.222-1.651 1.621-2.757H14V8h-3v1.047h.765c-.318.844-.74 1.546-1.272 2.13a6.066 6.066 0 0 1-.415-.492 1.988 1.988 0 0 1-.94.31z"/>
                    </svg>
                    <span id="currentLangText" style="color: #ffffff !important; text-transform: none !important; text-shadow: 0 1px 2px rgba(0,0,0,0.1);">English</span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 notranslate" aria-labelledby="languageDropdownBtn" style="background-color: #ffffff !important; min-width: 140px; border-radius: 12px; overflow: hidden; padding: 6px 0; margin-top: 8px; animation: dropdownFadeIn 0.2s ease-out;">
                    <li><a class="dropdown-item lang-option notranslate" href="#" data-value="en" data-text="English" style="padding: 10px 18px; font-weight: 500; font-size: 0.9rem; transition: all 0.2s; color: #333333 !important; text-transform: none !important;">English</a></li>
                    <li><a class="dropdown-item lang-option notranslate" href="#" data-value="hi" data-text="Hindi" style="padding: 10px 18px; font-weight: 500; font-size: 0.9rem; transition: all 0.2s; color: #333333 !important; text-transform: none !important;">Hindi</a></li>
                    <li><a class="dropdown-item lang-option notranslate" href="#" data-value="te" data-text="Telugu" style="padding: 10px 18px; font-weight: 500; font-size: 0.9rem; transition: all 0.2s; color: #333333 !important; text-transform: none !important;">Telugu</a></li>
                    <li><a class="dropdown-item lang-option notranslate" href="#" data-value="ml" data-text="Malayalam" style="padding: 10px 18px; font-weight: 500; font-size: 0.9rem; transition: all 0.2s; color: #333333 !important; text-transform: none !important;">Malayalam</a></li>
                </ul>
            </div>
            
        </div>

    </div>
</div>

<style>
/* Dropdown Animations and Hover Effects */
@keyframes dropdownFadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.custom-lang-dropdown .dropdown-item:hover {
    background-color: #fff0e6 !important;
    color: #e65c00 !important;
    padding-left: 22px !important;
}
.custom-lang-dropdown .dropdown-item.active {
    background-color: #e65c00 !important;
    color: #ffffff !important;
}
.premium-glass-btn:hover {
    background: rgba(255,255,255,0.25) !important;
    border-color: rgba(255,255,255,0.6) !important;
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.1) !important;
}
.premium-glass-btn:active {
    transform: translateY(0);
}


</style>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
      pageLanguage: 'en', 
      includedLanguages: 'en,hi,te,ml', 
      autoDisplay: false
  }, 'google_translate_element');
}

document.addEventListener('DOMContentLoaded', function() {
    const langOptions = document.querySelectorAll('.lang-option');
    const currentLangText = document.getElementById('currentLangText');
    
    if (langOptions.length > 0) {
        // Function to read cookie
        function readCookie(name) {
            let match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
            if (match) return match[2];
            return null;
        }

        // Set initial value based on cookie
        const transCookie = readCookie('googtrans');
        let currentLang = 'en';
        
        if (transCookie) {
            const langCode = transCookie.split('/').pop();
            if (langCode && langCode !== 'en') {
                currentLang = langCode;
            }
        }
        
        // Add language class to body for language-specific CSS fixes
        document.body.classList.add('lang-' + currentLang);
        
        // Custom Translations overrides for specific words that Google translates poorly
        const customHomeElements = document.querySelectorAll('.custom-translate-home');
        if (currentLang === 'hi') {
            customHomeElements.forEach(el => el.textContent = 'होम');
        } else if (currentLang === 'te') {
            customHomeElements.forEach(el => el.textContent = 'హోమ్');
        } else if (currentLang === 'ml') {
            customHomeElements.forEach(el => el.textContent = 'ഹോം');
        } else {
            customHomeElements.forEach(el => el.textContent = 'Home');
        }
        
        // Update UI to reflect current lang
        langOptions.forEach(opt => {
            if (opt.getAttribute('data-value') === currentLang) {
                opt.classList.add('active');
                currentLangText.textContent = opt.getAttribute('data-text');
            } else {
                opt.classList.remove('active');
            }
            
            // Handle click
            opt.addEventListener('click', function(e) {
                e.preventDefault();
                const lang = this.getAttribute('data-value');
                if (lang === currentLang) return; // Do nothing if same
                
                // Set cookie for both domain and root path
                if (lang === 'en') {
                    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; domain=' + window.location.hostname + '; path=/;';
                } else {
                    document.cookie = 'googtrans=/en/' + lang + '; path=/;';
                    document.cookie = 'googtrans=/en/' + lang + '; domain=' + window.location.hostname + '; path=/;';
                }
                
                // Reload page
                window.location.reload();
            });
        });
    }
});
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<style>
/* Ultimate Google Translate Banner Hider */
.goog-te-banner-frame.skiptranslate,
.goog-te-banner-frame,
.goog-tooltip,
.goog-tooltip:hover,
.goog-text-highlight,
#goog-gt-tt,
.VIpgJd-ZVi9od-ORHb-OEVmcd,
.VIpgJd-ZVi9od-aZ2wEe-wOHMyf,
iframe.goog-te-banner-frame {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    height: 0 !important;
    width: 0 !important;
}

body {
    top: 0px !important;
    position: static !important;
}

/* Hide any skiptranslate wrapper that is a direct child of body (usually the banner wrapper) */
body > .skiptranslate {
    display: none !important;
}
</style>

<script type="text/javascript">
// Nuclear option to force remove Google translate banner from DOM
setInterval(function() {
    // Force body top to 0
    if (document.body && document.body.style.top !== '0px') {
        document.body.style.top = '0px';
    }
    
    // Hide all iframes associated with google translate banner
    var iframes = document.querySelectorAll('iframe.goog-te-banner-frame, iframe.skiptranslate');
    for (var i = 0; i < iframes.length; i++) {
        iframes[i].style.display = 'none';
        iframes[i].style.visibility = 'hidden';
    }
    
    // Hide the skiptranslate divs
    var skipTranslateDivs = document.querySelectorAll('body > .skiptranslate');
    for (var j = 0; j < skipTranslateDivs.length; j++) {
        // Only hide if it's not our accessibility bar (our bar doesn't have skiptranslate directly on it, but just in case)
        if (skipTranslateDivs[j].id !== 'google_translate_element' && !skipTranslateDivs[j].classList.contains('accessibility-bar')) {
            skipTranslateDivs[j].style.display = 'none';
            skipTranslateDivs[j].style.height = '0px';
        }
    }
}, 50);
</script>

<style>
/* Responsive layout adjustments specifically for translated languages */
body.lang-hi .header-branding,
body.lang-te .header-branding,
body.lang-ml .header-branding {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
}

body.lang-hi .header-logo,
body.lang-te .header-logo,
body.lang-ml .header-logo {
    flex: 0 0 auto !important;
}

body.lang-hi .header-right-logo,
body.lang-te .header-right-logo,
body.lang-ml .header-right-logo {
    flex: 0 0 auto !important;
}

body.lang-hi .header-titles,
body.lang-te .header-titles,
body.lang-ml .header-titles {
    flex: 1 1 auto !important;
    min-width: 0 !important;
    padding: 0 1rem !important;
}

body.lang-hi .header-titles .main-title,
body.lang-te .header-titles .main-title,
body.lang-ml .header-titles .main-title {
    font-size: clamp(1.8rem, 3.5vw, 2.8rem) !important;
    white-space: normal !important;
    word-wrap: break-word !important;
    line-height: 1.2 !important;
}

body.lang-hi .header-titles .sub-title,
body.lang-te .header-titles .sub-title,
body.lang-ml .header-titles .sub-title {
    font-size: clamp(1.2rem, 2vw, 1.8rem) !important;
    white-space: normal !important;
    word-wrap: break-word !important;
    line-height: 1.3 !important;
}
</style>
