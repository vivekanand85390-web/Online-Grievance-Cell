﻿<?php
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$is_portal = ($current_dir === 'user' || $current_dir === 'admin') && isLoggedIn();
$base_path = ($current_dir === 'user' || $current_dir === 'admin') ? '../' : '';
?>

<?php if ($is_portal): ?>
        </div> <!-- End of portal-content -->
    </div> <!-- End of portal-body -->
</div> <!-- End of portal-container -->
<?php else: ?>
</div> <!-- End of container from header -->

<footer class="mt-auto py-4 glass-nav">
    <div class="container text-center">
        <p class="text-muted mb-0">Copyright &copy; <?php echo date('Y'); ?> NSTI R-Hyderabad</p>
        <div class="mt-2">
            <a href="#" class="text-muted me-3"><i class="fab fa-facebook"></i></a>
            <a href="#" class="text-muted me-3"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-muted"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</footer>
<?php endif; ?>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo $base_path; ?>assets/js/main.js"></script>

<!-- Custom AI Chatbot UI -->
<link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/chatbot.css">
<div class="chatbot-container" id="chatbotContainer">
    <div class="chatbot-window">
        <div class="chatbot-header">
            <div class="chatbot-header-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="chatbot-header-info">
                <h4>NSTI Copilot</h4>
                <p>AI Support Assistant</p>
            </div>
        </div>
        <div class="chatbot-body" id="chatBody">
            <div class="chat-msg bot">Hello! I am NSTI Copilot, the AI assistant for NSTI. How can I help you today?</div>
            <div class="chat-loading" id="chatLoading">
                <span></span><span></span><span></span>
            </div>
        </div>
        <div class="chatbot-input">
            <textarea id="chatInput" placeholder="Type your message..." onkeypress="handleChatKeypress(event)"></textarea>
            <button onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
    <div class="chatbot-toggler" onclick="toggleChatbot()">
        <i class="fas fa-comment-dots"></i>
        <i class="fas fa-times"></i>
    </div>
</div>
<script>
    // Set global base path for JS to know where to send fetch
    window.chatApiPath = "<?php echo $base_path; ?>chat_api.php";
</script>
<script src="<?php echo $base_path; ?>assets/js/chatbot.js"></script>

</body>
</html>



