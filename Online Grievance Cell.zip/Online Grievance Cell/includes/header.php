<?php
include_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/functions.php';

$unread_notifications = [];
$unread_count = 0;
$profile_pic = 'default_profile.png';
if (isLoggedIn()) {
    $stmt_notif = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 5");
    $stmt_notif->execute([$_SESSION['user_id']]);
    $unread_notifications = $stmt_notif->fetchAll();
    
    $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt_count->execute([$_SESSION['user_id']]);
    $unread_count = $stmt_count->fetchColumn();

    $stmt_user = $pdo->prepare("SELECT profile_pic, role FROM users WHERE id = ?");
    $stmt_user->execute([$_SESSION['user_id']]);
    $curr_user = $stmt_user->fetch();
    if ($curr_user) {
        if (!empty($curr_user['profile_pic'])) {
            $profile_pic = $curr_user['profile_pic'];
        }
        $role = $curr_user['role'];
    } else {
        $role = $_SESSION['role'] ?? 'student';
    }

    if ($profile_pic === 'default_profile.png') {
        if ($role === 'admin') {
            $profile_pic = 'admin_avatar.png';
        } elseif ($role === 'parent') {
            $profile_pic = 'parent_avatar.png';
        } elseif ($role === 'staff') {
            $profile_pic = 'staff_avatar.png';
        } else {
            $profile_pic = 'student_avatar.png';
        }
    }

    $profile_pic_path = __DIR__ . '/../uploads/' . $profile_pic;
    $profile_pic_version = file_exists($profile_pic_path) ? filemtime($profile_pic_path) : time();
}

$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$base_path = ($current_dir === 'user' || $current_dir === 'admin') ? '../' : '';
$is_portal = ($current_dir === 'user' || $current_dir === 'admin') && isLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Grievance Cell - NSTI-R Hyderabad</title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Secure platform for students and staff of NSTI-R Hyderabad to submit and track grievances.">
    <meta name="keywords" content="NSTI, Hyderabad, Grievance Cell, Student Complaint, NSTI-R">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/accessibility.css?v=<?php echo time(); ?>">
    
    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
    <!-- Accessibility Logic (Language & Text Size) -->
    <script src="<?php echo $base_path; ?>assets/js/accessibility.js" defer></script>
    
    <!-- Theme Toggle Logic (Synchronous to prevent FOUC) -->
    <script>
        const savedTheme = localStorage.getItem('theme') || 'light';
        if (savedTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            const themeBtn = document.getElementById('themeToggleBtn');
            if (themeBtn) {
                const icon = themeBtn.querySelector('i');
                if (savedTheme === 'dark') {
                    icon.classList.replace('fa-moon', 'fa-sun');
                } else {
                    icon.classList.replace('fa-sun', 'fa-moon');
                }
                
                themeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    let currentTheme = document.documentElement.getAttribute('data-theme');
                    if (currentTheme === 'dark') {
                        document.documentElement.removeAttribute('data-theme');
                        localStorage.setItem('theme', 'light');
                        icon.classList.replace('fa-sun', 'fa-moon');
                    } else {
                        document.documentElement.setAttribute('data-theme', 'dark');
                        localStorage.setItem('theme', 'dark');
                        icon.classList.replace('fa-moon', 'fa-sun');
                    }
                });
            }
        });
    </script>
</head>
<body>
<?php include_once __DIR__ . '/accessibility_bar.php'; ?>

<?php if ($is_portal): ?>
<div class="portal-container">
    <!-- Sidebar -->
    <div class="portal-sidebar">
            <div class="portal-sidebar-profile">
                <div class="d-flex align-items-center gap-3">
                    <?php if ($profile_pic === 'student_avatar.png'): ?>
                        <div class="rounded-circle d-flex align-items-center justify-content-center bg-white" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <i class="fas fa-user-graduate" style="font-size: 1.8rem; background: linear-gradient(135deg, #7e22ce, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                        </div>
                    <?php elseif ($profile_pic === 'staff_avatar.png'): ?>
                        <div class="rounded-circle d-flex align-items-center justify-content-center bg-white" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <i class="fas fa-user-tie" style="font-size: 1.8rem; background: linear-gradient(135deg, #334155, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                        </div>
                    <?php elseif ($profile_pic === 'parent_avatar.png'): ?>
                        <div class="rounded-circle d-flex align-items-center justify-content-center bg-white" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <svg viewBox="0 0 100 100" style="width: 1.8rem; height: 1.8rem;" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="50" cy="50" r="45" fill="none" stroke="#334155" stroke-width="8"/>
                              <circle cx="50" cy="28" r="8" fill="#334155"/>
                              <path d="M 50 40 Q 25 45 10 75 Q 20 90 30 75 Q 35 65 40 60 L 35 100 L 65 100 L 60 60 Q 65 65 70 75 Q 80 90 90 75 Q 75 45 50 40 Z" fill="#334155"/>
                              <g fill="#334155" stroke="#ffffff" stroke-width="3" stroke-linejoin="round">
                                <circle cx="25" cy="58" r="6"/>
                                <path d="M 25 66 Q 12 70 8 95 L 42 95 Q 38 70 25 66 Z"/>
                                <circle cx="75" cy="58" r="6"/>
                                <path d="M 75 66 Q 62 70 58 95 L 92 95 Q 88 70 75 66 Z"/>
                              </g>
                            </svg>
                        </div>
                    <?php elseif ($profile_pic === 'admin_avatar.png'): ?>
                        <div class="rounded-circle d-flex align-items-center justify-content-center bg-white" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <i class="fas fa-user-cog" style="font-size: 1.8rem; color: #374151;"></i>
                        </div>
                    <?php elseif ($profile_pic === 'default_profile.png'): ?>
                        <div class="rounded-circle d-flex align-items-center justify-content-center bg-warning text-dark fw-bold" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); font-size: 1.35rem; flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?>
                        </div>
                    <?php else: ?>
                        <img src="<?php echo $base_path; ?>uploads/<?php echo $profile_pic; ?>?v=<?php echo $profile_pic_version; ?>" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover; border: 2px solid rgba(255,255,255,0.2); flex-shrink: 0;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="rounded-circle align-items-center justify-content-center bg-warning text-dark fw-bold" style="width: 50px; height: 50px; border: 2px solid rgba(255,255,255,0.2); font-size: 1.35rem; flex-shrink: 0; display: none; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                    <div class="text-start" style="min-width: 0; line-height: 1.2;">
                        <div style="font-size: 0.72rem; color: #38bdf8; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">
                            <?php 
                            if ($role === 'staff') echo 'Faculty/Staff';
                            elseif ($role === 'parent') echo 'Parent';
                            elseif ($role === 'admin') echo 'Admin';
                            else echo 'Student';
                            ?>
                        </div>
                        <div class="fw-bold" style="color: var(--sidebar-text-main); font-size: 0.95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 150px;"><?php echo (isAdmin() && $_SESSION['name'] === 'Admin') ? 'NSTI ADMIN' : $_SESSION['name']; ?></div>
                    </div>
                </div>
            </div>
            
            <div class="sidebar-section-header"><?php echo isAdmin() ? 'Admin Side' : 'User Side'; ?></div>
            
            <ul class="portal-sidebar-menu">
                <?php if (isAdmin()): ?>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>admin/dashboard.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'manage_grievances.php' || basename($_SERVER['PHP_SELF']) === 'view_grievance.php' ? 'active' : ''; ?>" data-bs-toggle="collapse" href="#grievancesSubmenu" role="button" aria-expanded="<?php echo basename($_SERVER['PHP_SELF']) === 'manage_grievances.php' ? 'true' : 'false'; ?>" aria-controls="grievancesSubmenu">
                            <i class="fas fa-list"></i> Grievances
                            <i class="fas fa-chevron-down ms-auto" style="font-size: 0.8rem; transition: transform 0.3s;"></i>
                        </a>
                        <div class="collapse <?php echo basename($_SERVER['PHP_SELF']) === 'manage_grievances.php' || basename($_SERVER['PHP_SELF']) === 'view_grievance.php' ? 'show' : ''; ?>" id="grievancesSubmenu">
                            <ul class="portal-sidebar-menu mt-2" style="padding-left: 2rem;">
                                <li class="portal-menu-item">
                                    <a href="<?php echo $base_path; ?>admin/manage_grievances.php" class="portal-menu-link <?php echo empty($_GET['role']) && basename($_SERVER['PHP_SELF']) === 'manage_grievances.php' ? 'active' : ''; ?>" style="padding: 0.6rem 1rem; font-size: 0.9rem;">
                                        All Grievances
                                    </a>
                                </li>
                                <li class="portal-menu-item">
                                    <a href="<?php echo $base_path; ?>admin/manage_grievances.php?role=student" class="portal-menu-link <?php echo (isset($_GET['role']) && $_GET['role'] === 'student') ? 'active' : ''; ?>" style="padding: 0.6rem 1rem; font-size: 0.9rem;">
                                        Students / Trainees
                                    </a>
                                </li>
                                <li class="portal-menu-item">
                                    <a href="<?php echo $base_path; ?>admin/manage_grievances.php?role=staff" class="portal-menu-link <?php echo (isset($_GET['role']) && $_GET['role'] === 'staff') ? 'active' : ''; ?>" style="padding: 0.6rem 1rem; font-size: 0.9rem;">
                                        Staff / Faculty
                                    </a>
                                </li>
                                <li class="portal-menu-item">
                                    <a href="<?php echo $base_path; ?>admin/manage_grievances.php?role=parent" class="portal-menu-link <?php echo (isset($_GET['role']) && $_GET['role'] === 'parent') ? 'active' : ''; ?>" style="padding: 0.6rem 1rem; font-size: 0.9rem;">
                                        Parents
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>admin/manage_users.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'manage_users.php' ? 'active' : ''; ?>">
                            <i class="fas fa-users"></i> Users
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>admin/reports.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : ''; ?>">
                            <i class="fas fa-file-invoice"></i> Reports
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>admin/manage_notices.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'manage_notices.php' ? 'active' : ''; ?>">
                            <i class="fas fa-bullhorn"></i> Manage Notices
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>admin/profile.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : ''; ?>">
                            <i class="fas fa-user-cog"></i> Account Setting
                        </a>
                    </li>
                    <?php if (($_SESSION['admin_type'] ?? '') === 'main'): ?>
                        <li class="portal-menu-item">
                            <a href="<?php echo $base_path; ?>admin/manage_database.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'manage_database.php' ? 'active' : ''; ?>">
                                <i class="fas fa-database"></i> Database
                            </a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/dashboard.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/submit_grievance.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'submit_grievance.php' ? 'active' : ''; ?>">
                            <i class="fas fa-file-signature"></i> Lodge Complaint
                        </a>
                    </li>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/track_grievance.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'track_grievance.php' || basename($_SERVER['PHP_SELF']) === 'view_grievance.php' ? 'active' : ''; ?>">
                            <i class="fas fa-list"></i> Track Grievances
                        </a>
                    </li>

                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/notice_board.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'notice_board.php' ? 'active' : ''; ?>">
                            <i class="fas fa-bullhorn"></i> Notice Board
                        </a>
                    </li>
                    <?php if (($_SESSION['role'] ?? '') === 'staff'): ?>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/manage_notices.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'manage_notices.php' ? 'active' : ''; ?>">
                            <i class="fas fa-bullhorn"></i> Post Notice
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="portal-menu-item">
                        <a href="<?php echo $base_path; ?>user/profile.php" class="portal-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : ''; ?>">
                            <i class="fas fa-user-cog"></i> Account Setting
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        
    <!-- Main Content Area -->
    <div class="portal-main">
        <!-- Portal Topbar -->
        <div class="portal-topbar">
            <div class="portal-topbar-title">
                <div id="sidebarCollapse" class="topbar-btn" style="cursor: pointer; width: 36px; height: 36px; border-radius: 8px; margin-right: 0.5rem;">
                    <i class="fas fa-align-left"></i>
                </div>
                <span class="text-gradient">Dashboard</span>
            </div>
            <div class="d-flex align-items-center gap-4">
                <!-- Theme Toggle Button -->
                <a href="#" id="themeToggleBtn" class="text-decoration-none topbar-btn" style="width: 36px; height: 36px; border-radius: 50%;">
                    <i class="fas fa-moon fa-lg"></i>
                </a>

                <!-- Notifications Dropdown -->
                <div class="dropdown">
                    <a class="position-relative text-decoration-none topbar-btn" href="#" role="button" data-bs-toggle="dropdown" style="width: 36px; height: 36px; border-radius: 8px;">
                        <i class="fas fa-bell fa-lg"></i>
                        <?php if ($unread_count > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem; padding: 0.25em 0.5em;">
                                <?php echo $unread_count; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end py-2 shadow" style="width: 280px; font-size: 0.9rem; margin-top: 10px; background: var(--bg-portal) !important; border: 1px solid var(--border-glass) !important; border-radius: 12px;">
                        <li class="dropdown-header border-bottom pb-2 d-flex justify-content-between align-items-center" style="border-color: var(--border-glass) !important;">
                            <span class="fw-bold" style="color: var(--text-heading) !important; font-size: 0.95rem;">Notifications</span>
                            <?php if ($unread_count > 0): ?>
                                <a href="?clear_notifications=1" class="text-decoration-none small fw-semibold" style="color: #38bdf8 !important;">Clear All</a>
                            <?php endif; ?>
                        </li>
                        <?php if (empty($unread_notifications)): ?>
                            <li class="text-center py-3" style="color: var(--text-muted) !important;">No notifications</li>
                        <?php else: ?>
                            <?php foreach ($unread_notifications as $n): ?>
                                <li style="border-bottom: 1px solid var(--border-glass);">
                                    <div class="dropdown-item text-wrap py-2.5 px-3 <?php echo !$n['is_read'] ? 'fw-bold' : ''; ?>" style="white-space: normal; color: var(--text-main); <?php echo !$n['is_read'] ? 'background-color: var(--menu-hover-bg);' : 'background: transparent;'; ?>">
                                        <span style="font-size: 0.88rem; line-height: 1.4; display: block; color: inherit;"><?php echo htmlspecialchars($n['message']); ?></span>
                                        <span class="d-block small mt-1" style="color: var(--text-muted); font-size: 0.75rem;"><?php echo date('d M, h:i A', strtotime($n['created_at'])); ?></span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Profile Dropdown -->
                <div class="dropdown">
                    <a class="text-decoration-none dropdown-toggle topbar-btn gap-2" href="#" role="button" data-bs-toggle="dropdown" style="padding: 6px 14px; border-radius: 8px;">
                        <i class="fas fa-user-circle fa-lg"></i>
                        <span class="d-none d-sm-inline fw-semibold" style="font-size: 0.85rem;">Account</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end py-0 shadow" style="min-width: 180px; font-size: 0.9rem; background: var(--bg-portal) !important; border: 1px solid var(--border-glass) !important; border-radius: 8px; overflow: hidden; margin-top: 10px;">
                        <li><a class="dropdown-item py-2 px-3 dropdown-hover" style="color: var(--text-main);" href="<?php echo $base_path; ?><?php echo isAdmin() ? 'admin' : 'user'; ?>/profile.php"><i class="fas fa-edit fa-fw me-2"></i>Edit Profile</a></li>
                        <?php if (isAdmin()): ?>
                        <li><a class="dropdown-item py-2 px-3 dropdown-hover border-top" style="color: var(--text-main); border-color: var(--border-glass) !important;" href="<?php echo $base_path; ?>admin/profile.php#password-section"><i class="fas fa-lock fa-fw me-2"></i>Change Password</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item py-2 px-3 dropdown-hover border-top" style="border-color: var(--border-glass) !important; color: #ef4444 !important; font-weight: 600;" href="<?php echo $base_path; ?>logout.php"><i class="fas fa-power-off fa-fw me-2"></i>Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Portal Content Area -->
        <div class="portal-content">

<?php else: ?>
<nav class="navbar navbar-expand-lg glass-nav">
    <div class="container">
        <a class="navbar-brand" href="<?php echo $base_path; ?>index.php">
            <i class="fas fa-balance-scale me-2"></i>NSTI-R Grievance
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo $base_path; ?>index.php"><span class="notranslate custom-translate-home">Home</span></a></li>
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo $base_path; ?>login.php">Login</a></li>
                <li class="nav-item"><a class="btn btn-premium ms-lg-3" href="<?php echo $base_path; ?>register.php">Register</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4 mb-5">
<?php endif; ?>

<?php if (isset($_SESSION['msg'])): ?>
    <script>
        window.onload = () => {
            Swal.fire({
                icon: '<?php echo $_SESSION['msg_type']; ?>',
                title: '<?php echo $_SESSION['msg']; ?>',
                timer: 3000,
                showConfirmButton: false,
                background: '#1a1c22',
                color: '#fff'
            });
        }
    </script>
    <?php 
    unset($_SESSION['msg']); 
    unset($_SESSION['msg_type']); 
    ?>
<?php endif; ?>
