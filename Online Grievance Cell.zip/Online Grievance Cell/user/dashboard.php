<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Fetch additional user details for the welcome card
$stmt_user = $pdo->prepare("SELECT username, department, room_no, trade, roll_no FROM users WHERE id = ?");
$stmt_user->execute([$user_id]);
$user_info = $stmt_user->fetch();

$roll_no = !empty($user_info['roll_no']) ? $user_info['roll_no'] : ($user_info['username'] ?? 'N/A');
$room_no = $user_info['room_no'] ?? 'N/A';
$trade = $user_info['trade'] ?? ($user_info['department'] ?? 'N/A');

// Handle Actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $id = (int)$_GET['id'];
    
    if ($action === 'remove') {
        $stmt = $pdo->prepare("DELETE FROM grievances WHERE id = ?");
        $stmt->execute([$id]);
        redirect('dashboard.php', 'Grievance removed successfully!', 'success');
    } elseif ($action === 'disable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 1 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('dashboard.php', 'Grievance disabled.', 'success');
    } elseif ($action === 'enable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 0 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('dashboard.php', 'Grievance enabled.', 'success');
    }
}

$type = $_GET['type'] ?? 'my';

if ($user_role === 'staff' && $type === 'student') {
    // Staff statistics for Student complaints
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM grievances g JOIN users u ON g.user_id = u.id WHERE u.role = 'student'");
    $stmt->execute();
    $total = $stmt->fetch()['total'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as pending FROM grievances g JOIN users u ON g.user_id = u.id WHERE u.role = 'student' AND g.status = 'Pending'");
    $stmt->execute();
    $pending = $stmt->fetch()['pending'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as inprocess FROM grievances g JOIN users u ON g.user_id = u.id WHERE u.role = 'student' AND g.status = 'In Progress'");
    $stmt->execute();
    $inprocess = $stmt->fetch()['inprocess'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as closed FROM grievances g JOIN users u ON g.user_id = u.id WHERE u.role = 'student' AND g.status IN ('Resolved', 'Rejected')");
    $stmt->execute();
    $closed = $stmt->fetch()['closed'];

    // Get recent activity of students
    $stmt = $pdo->prepare("SELECT g.*, c.name as category, u.name as complainant_name 
                           FROM grievances g 
                           JOIN categories c ON g.category_id = c.id 
                           JOIN users u ON g.user_id = u.id
                           WHERE u.role = 'student' 
                           ORDER BY g.created_at DESC LIMIT 5");
    $stmt->execute();
    $recent_complaints = $stmt->fetchAll();
} else {
    // Personal statistics (Student, or Staff viewing their own grievances)
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM grievances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total = $stmt->fetch()['total'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as pending FROM grievances WHERE user_id = ? AND status = 'Pending'");
    $stmt->execute([$user_id]);
    $pending = $stmt->fetch()['pending'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as inprocess FROM grievances WHERE user_id = ? AND status = 'In Progress'");
    $stmt->execute([$user_id]);
    $inprocess = $stmt->fetch()['inprocess'];

    $stmt = $pdo->prepare("SELECT COUNT(*) as closed FROM grievances WHERE user_id = ? AND status IN ('Resolved', 'Rejected')");
    $stmt->execute([$user_id]);
    $closed = $stmt->fetch()['closed'];

    // Get recent activity
    $stmt = $pdo->prepare("SELECT g.*, c.name as category 
                           FROM grievances g 
                           JOIN categories c ON g.category_id = c.id 
                           WHERE g.user_id = ? 
                           ORDER BY g.created_at DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $recent_complaints = $stmt->fetchAll();
}

// Staff member's own grievances count for sidebar card
$own_count = 0;
if ($user_role === 'staff') {
    $stmt_own = $pdo->prepare("SELECT COUNT(*) as total FROM grievances WHERE user_id = ?");
    $stmt_own->execute([$user_id]);
    $own_count = $stmt_own->fetch()['total'];
}

include_once '../includes/header.php';
?>

<div class="fade-in">
    <style>
        .action-buttons {
            display: flex;
            gap: 4px;
            justify-content: flex-end;
        }
        .btn-action {
            display: inline-block;
            padding: 5px 12px;
            color: #ffffff !important;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            border-radius: 4px;
            transition: opacity 0.2s;
            text-align: center;
        }
        .btn-action:hover {
            opacity: 0.85;
        }
        .btn-view { background-color: #22c55e; }
        .btn-edit { background-color: #06b6d4; }
        .btn-remove { background-color: #ef4444; }
        .btn-disable { background-color: #f59e0b; }
        .dashboard-hero-icon {
            width: 200px;
            height: auto;
            max-height: 140px;
            object-fit: contain;
            display: block;
            transform: scale(1.05) translateY(-5px);
            transition: all 0.3s ease;
        }
        
        [data-theme="dark"] .dashboard-hero-icon {
            /* Add a soft white glow behind the dark icon so it's clearly visible in dark mode without altering the image colors */
            filter: drop-shadow(0 0 15px rgba(255,255,255,0.8)) drop-shadow(0 0 5px rgba(255,255,255,0.8));
        }
    </style>
    <div class="row mb-4">
        <div class="col-12">
            <div class="portal-card theme-hero-card position-relative overflow-hidden" style="border: none; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                <div class="card-body p-4 d-flex justify-content-between align-items-center">
                    <div style="z-index: 2;">
                        <p class="theme-hero-text-accent fw-bold mb-1" style="font-size: 1rem;">Welcome Back,</p>
                        <h2 class="theme-hero-text-main fw-bolder mb-3" style="text-transform: uppercase; font-size: 2.2rem; letter-spacing: -0.5px;"><?php echo htmlspecialchars($_SESSION['name'] ?? 'USER'); ?></h2>
                        
                        <div class="d-flex flex-column gap-2 theme-hero-text-sub" style="font-size: 0.95rem;">
                            <div class="d-flex align-items-center">
                                <i class="<?php echo ($user_role === 'staff') ? 'fas fa-id-card' : 'fas fa-id-badge'; ?> text-primary" style="width: 20px;"></i> 
                                <span><?php echo ($user_role === 'staff') ? 'Employee ID' : 'Roll No'; ?> : <?php echo htmlspecialchars($roll_no); ?></span>
                            </div>
                            <div class="d-flex align-items-center">
                                <i class="<?php echo ($user_role === 'staff') ? 'fas fa-briefcase' : 'fas fa-graduation-cap'; ?> text-primary" style="width: 20px;"></i> 
                                <span><?php echo ($user_role === 'staff') ? 'Designation' : 'Trade'; ?> : <?php echo htmlspecialchars($trade); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-none d-md-block text-end" style="z-index: 1; padding-right: 20px;">
                        <img src="../assets/images/committee_icon.png" alt="Grievance Committee" class="dashboard-hero-icon">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Staff Tab Selector -->
    <?php if ($user_role === 'staff'): ?>
        <div class="d-flex gap-3 mb-4">
            <a href="?type=student" class="btn <?php echo $type === 'student' ? 'btn-premium' : 'btn-outline-primary'; ?> rounded-pill px-4 text-uppercase fw-bold" style="letter-spacing: 0.5px;">Student Grievances</a>
            <a href="?type=my" class="btn <?php echo $type === 'my' ? 'btn-premium' : 'btn-outline-primary'; ?> rounded-pill px-4 text-uppercase fw-bold" style="letter-spacing: 0.5px;">My Personal Grievances</a>
        </div>
    <?php endif; ?>

    <!-- Quick Stats Row (similar to Admin Dashboard) -->
    <div class="row mb-4">
        <!-- Total Complaints -->
        <div class="col-md-3 col-sm-6 mb-4">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="theme-text-muted text-uppercase fw-bold mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Total Complaints</h6>
                            <h2 class="mb-0 fw-bolder theme-text-main" style="font-size: 2.5rem; line-height: 1;"><?php echo $total; ?></h2>
                        </div>
                        <div class="d-flex align-items-center justify-content-center" style="width: 55px; height: 55px; border-radius: 16px; background-color: #e0e7ff;">
                            <i class="fas fa-file-alt" style="color: #4f46e5; font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <a href="track_grievance.php" class="btn btn-sm text-white px-4 fw-bold border-0 mt-auto" style="background-color: #4f46e5; border-radius: 8px; width: fit-content;">View</a>
                </div>
            </div>
        </div>
        <!-- Pending Complaints -->
        <div class="col-md-3 col-sm-6 mb-4">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="theme-text-muted text-uppercase fw-bold mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Pending</h6>
                            <h2 class="mb-0 fw-bolder theme-text-main" style="font-size: 2.5rem; line-height: 1;"><?php echo $pending; ?></h2>
                        </div>
                        <div class="d-flex align-items-center justify-content-center" style="width: 55px; height: 55px; border-radius: 16px; background-color: #ffedd5;">
                            <i class="fas fa-clock" style="color: #ea580c; font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <a href="track_grievance.php?status=Pending" class="btn btn-sm text-white px-4 fw-bold border-0 mt-auto" style="background-color: #ea580c; border-radius: 8px; width: fit-content;">View</a>
                </div>
            </div>
        </div>
        <!-- Inprocess Complaints -->
        <div class="col-md-3 col-sm-6 mb-4">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="theme-text-muted text-uppercase fw-bold mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">In Process</h6>
                            <h2 class="mb-0 fw-bolder theme-text-main" style="font-size: 2.5rem; line-height: 1;"><?php echo $inprocess; ?></h2>
                        </div>
                        <div class="d-flex align-items-center justify-content-center" style="width: 55px; height: 55px; border-radius: 16px; background-color: #e0f2fe;">
                            <i class="fas fa-spinner" style="color: #0284c7; font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <a href="track_grievance.php?status=In Progress" class="btn btn-sm text-white px-4 fw-bold border-0 mt-auto" style="background-color: #0284c7; border-radius: 8px; width: fit-content;">View</a>
                </div>
            </div>
        </div>
        <!-- Closed Complaints -->
        <div class="col-md-3 col-sm-6 mb-4">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="theme-text-muted text-uppercase fw-bold mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Closed</h6>
                            <h2 class="mb-0 fw-bolder theme-text-main" style="font-size: 2.5rem; line-height: 1;"><?php echo $closed; ?></h2>
                        </div>
                        <div class="d-flex align-items-center justify-content-center" style="width: 55px; height: 55px; border-radius: 16px; background-color: #dcfce7;">
                            <i class="fas fa-check-circle" style="color: #16a34a; font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    <a href="track_grievance.php?status=Resolved" class="btn btn-sm text-white px-4 fw-bold border-0 mt-auto" style="background-color: #16a34a; border-radius: 8px; width: fit-content;">View</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Action Cards -->
    <div class="row mb-4">
        <!-- Complaint Action -->
        <div class="col-md-4 mb-3">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column align-items-start">
                    <div class="mb-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background-color: #ff4d4f; border-radius: 50%;">
                        <i class="fas fa-file-signature text-white" style="font-size: 1.2rem;"></i>
                    </div>
                    <h5 class="fw-bold mb-2 theme-text-main">Lodge Complaint</h5>
                    <p class="theme-text-muted small mb-4 flex-grow-1">Easily file a new grievance and track its progress.</p>
                    <a href="submit_grievance.php" class="btn btn-sm text-white px-4 fw-bold border-0" style="background-color: #ff4d4f; border-radius: 8px;">Open</a>
                </div>
            </div>
        </div>
        <!-- Notice Board Action -->
        <div class="col-md-4 mb-3">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column align-items-start">
                    <div class="mb-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background-color: #00cec9; border-radius: 50%;">
                        <i class="fas fa-bullhorn text-white" style="font-size: 1.2rem;"></i>
                    </div>
                    <h5 class="fw-bold mb-2 theme-text-main">Notice Board</h5>
                    <p class="theme-text-muted small mb-4 flex-grow-1">View latest notices and updates.</p>
                    <a href="notice_board.php" class="btn btn-sm text-white px-4 fw-bold border-0" style="background-color: #00cec9; border-radius: 8px;">Open</a>
                </div>
            </div>
        </div>
        <!-- Track Status Action -->
        <div class="col-md-4 mb-3">
            <div class="card theme-card border-0 h-100" style="border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                <div class="card-body p-4 d-flex flex-column align-items-start">
                    <div class="mb-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background-color: #6c5ce7; border-radius: 50%;">
                        <i class="fas fa-search text-white" style="font-size: 1.3rem;"></i>
                    </div>
                    <h5 class="fw-bold mb-2 theme-text-main">Track Status</h5>
                    <p class="theme-text-muted small mb-4 flex-grow-1">Check the current status of your submitted grievances.</p>
                    <a href="check_status.php" class="btn btn-sm text-white px-4 fw-bold border-0" style="background-color: #64748b; border-radius: 8px;">Open</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Left: Recent Activity Table -->
        <div class="col-lg-8 mb-4">
            <div class="glass-card h-100 p-0 overflow-hidden">
                <div class="d-flex justify-content-between align-items-center p-4 border-bottom" style="border-color: var(--border-glass) !important;">
                    <h4 class="mb-0 fw-bold" style="font-size: 1.3rem; color: var(--text-heading);">
                        <?php echo ($user_role === 'staff' && $type === 'student') ? 'Recent Student Complaints' : 'Recent Complaints'; ?>
                    </h4>
                    <a href="track_grievance.php?type=<?php echo $type; ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table portal-table table-hover align-middle mb-0">
                        <thead>
                            <tr class="border-secondary">
                                <th class="ps-4">ID</th>
                                <?php if ($user_role === 'staff' && $type === 'student'): ?>
                                    <th>Student</th>
                                <?php endif; ?>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Status</th>
                                <th class="pe-4 text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_complaints)): ?>
                                <tr>
                                    <td colspan="<?php echo ($user_role === 'staff' && $type === 'student') ? '6' : '5'; ?>" class="text-center py-5 text-muted">No complaints found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_complaints as $complaint): ?>
                                    <tr class="border-secondary">
                                        <td class="ps-4 py-3 fw-bold text-primary"><?php echo $complaint['complaint_id']; ?></td>
                                        <?php if ($user_role === 'staff' && $type === 'student'): ?>
                                            <td class="small fw-semibold" style="color: var(--text-muted);"><?php echo htmlspecialchars($complaint['complainant_name']); ?></td>
                                        <?php endif; ?>
                                        <td><span class="badge bg-secondary opacity-75"><?php echo $complaint['category']; ?></span></td>
                                        <td class="text-truncate" style="max-width: 250px; color: var(--text-main);"><?php echo htmlspecialchars($complaint['title']); ?></td>
                                        <td>
                                            <span class="<?php echo getStatusBadge($complaint['status']); ?>">
                                                <?php 
                                                $status_icon = 'fa-circle';
                                                if ($complaint['status'] === 'Pending') $status_icon = 'fa-clock';
                                                elseif ($complaint['status'] === 'In Progress') $status_icon = 'fa-spinner fa-spin';
                                                elseif ($complaint['status'] === 'Resolved') $status_icon = 'fa-check-circle';
                                                elseif ($complaint['status'] === 'Rejected') $status_icon = 'fa-times-circle';
                                                ?>
                                                <i class="fas <?php echo $status_icon; ?> me-1"></i><?php echo getStatusLabel($complaint['status']); ?>
                                            </span>
                                        </td>
                                        <td class="pe-4 text-end">
                                            <div class="action-buttons">
                                                <a href="view_grievance.php?id=<?php echo $complaint['id']; ?>" class="btn-action btn-view">View</a>
                                                <a href="view_grievance.php?id=<?php echo $complaint['id']; ?>#update-status-form" class="btn-action btn-edit">Edit</a>
                                                <a href="dashboard.php?action=remove&id=<?php echo $complaint['id']; ?>" class="btn-action btn-remove" onclick="return confirm('Are you sure you want to permanently remove this grievance?');">Remove</a>
                                                <?php if (isset($complaint['is_disabled']) && $complaint['is_disabled']): ?>
                                                    <a href="dashboard.php?action=enable&id=<?php echo $complaint['id']; ?>" class="btn-action btn-active" style="background-color: #6b7280;">Active</a>
                                                <?php else: ?>
                                                    <a href="dashboard.php?action=disable&id=<?php echo $complaint['id']; ?>" class="btn-action btn-disable" onclick="return confirm('Are you sure you want to disable this grievance?');">Disable</a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Right Side Panel Quick Actions -->
        <div class="col-lg-4 mb-4">
            <div class="glass-card text-center d-flex flex-column justify-content-center h-100 p-4" style="border-radius: 1.5rem; border: 2px solid transparent; min-height: 250px;">
                <?php if ($user_role === 'staff'): ?>
                    <i class="fas fa-user-shield fa-3x mb-3 text-primary" style="opacity: 0.85;"></i>
                    <h4 class="fw-bold mb-2" style="color: var(--text-heading);">Staff Grievance</h4>
                    <p class="small mb-3" style="color: var(--text-muted);">Need to lodge a personal complaint? File a grievance directly to the Administration.</p>
                    <a href="submit_grievance.php" class="btn btn-primary rounded-pill px-4 py-2 mx-auto">Lodge Staff Complaint</a>
                    <span class="d-block small mt-3" style="color: var(--text-muted);">Personal grievances: <?php echo $own_count; ?></span>
                <?php else: ?>
                    <i class="fas fa-plus-circle fa-3x mb-3 text-primary" style="opacity: 0.85;"></i>
                    <h4 class="fw-bold mb-2" style="color: var(--text-heading);">Need Help?</h4>
                    <p class="small mb-3" style="color: var(--text-muted);">Submit a new grievance and our team will get back to you shortly.</p>
                    <a href="submit_grievance.php" class="btn btn-primary rounded-pill px-4 py-2 mx-auto">Submit New Complaint</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
