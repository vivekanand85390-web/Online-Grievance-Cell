<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$grievance_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

if (!$grievance_id) {
    die('Invalid Grievance ID');
}

// Fetch grievance details
$stmt = $pdo->prepare("SELECT g.*, c.name as category, u.name as user_name, u.role as user_role, u.email, u.contact 
                       FROM grievances g 
                       JOIN categories c ON g.category_id = c.id 
                       JOIN users u ON g.user_id = u.id 
                       WHERE g.id = ?");
$stmt->execute([$grievance_id]);
$g = $stmt->fetch();

if (!$g) {
    die('Grievance not found.');
}

// Security check
$is_authorized = false;
if ($user_role === 'student' && $g['user_id'] == $user_id) {
    $is_authorized = true;
} elseif ($user_role === 'staff' && ($g['user_role'] === 'student' || $g['user_id'] == $user_id)) {
    $is_authorized = true;
} elseif ($user_role === 'admin') {
    $is_authorized = true;
}

if (!$is_authorized) {
    die('Unauthorized access.');
}

// Fetch timeline
$stmt_updates = $pdo->prepare("SELECT gu.*, u.name as updater_name, u.role as updater_role 
                               FROM grievance_updates gu 
                               JOIN users u ON gu.updated_by = u.id 
                               WHERE gu.grievance_id = ? 
                               ORDER BY gu.created_at ASC");
$stmt_updates->execute([$grievance_id]);
$updates = $stmt_updates->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print Grievance - <?php echo htmlspecialchars($g['complaint_id']); ?></title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');
        
        body {
            font-family: 'Roboto', Arial, sans-serif;
            color: #222;
            margin: 0;
            padding: 10px;
            background-color: #f4f4f4;
            line-height: 1.3;
        }
        .print-container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 25px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #0f3057;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .section-title {
            background-color: #0f3057;
            color: #fff;
            padding: 4px 10px;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            margin-top: 15px;
            margin-bottom: 5px;
            letter-spacing: 0.5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        th, td {
            border: 1px solid #d1d5db;
            padding: 5px 10px;
            text-align: left;
            font-size: 12px;
        }
        th {
            width: 28%;
            background-color: #f8fafc;
            color: #334155;
            font-weight: 600;
        }
        .description-box {
            border: 1px solid #d1d5db;
            padding: 10px;
            min-height: 60px;
            font-size: 12px;
            white-space: pre-wrap;
            background-color: #f8fafc;
            color: #1e293b;
        }
        .timeline {
            margin-top: 10px;
        }
        .timeline-item {
            margin-bottom: 10px;
            padding: 10px;
            border-left: 3px solid #0f3057;
            background-color: #f8fafc;
            border-radius: 0 4px 4px 0;
        }
        .timeline-item h4 {
            margin: 0 0 3px 0;
            font-size: 12px;
            color: #0f3057;
        }
        .timeline-item p {
            margin: 0;
            font-size: 11px;
            color: #475569;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #64748b;
            border-top: 1px solid #e2e8f0;
            padding-top: 10px;
        }
        .signature-section {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            padding: 0 20px;
        }
        .signature-box {
            width: 220px;
            text-align: center;
            border-top: 1px solid #334155;
            padding-top: 5px;
            font-weight: 500;
            font-size: 12px;
        }
        .no-print {
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 15px;
            text-align: right;
            position: sticky;
            top: 15px;
            z-index: 100;
            max-width: 800px;
            margin: 0 auto 15px auto;
        }
        .btn-print, .btn-close {
            padding: 6px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .btn-print {
            background-color: #0f3057;
            color: #fff;
            margin-right: 10px;
        }
        .btn-close {
            background-color: #e2e8f0;
            color: #475569;
        }
        
        @page {
            size: A4;
            margin: 10mm;
        }
        @media print {
            .no-print { display: none !important; }
            body { 
                padding: 0; 
                background-color: #fff; 
            }
            .print-container {
                box-shadow: none;
                padding: 0;
                max-width: 100%;
            }
            .section-title {
                background-color: #f1f5f9 !important;
                color: #0f3057 !important;
                border: 1px solid #cbd5e1;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            th {
                background-color: #f8fafc !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .description-box, .timeline-item {
                background-color: #f8fafc !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .timeline-item {
                border-left: 3px solid #0f3057 !important;
            }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print">
        <button class="btn-print" onclick="window.print()">Print Report</button>
        <button class="btn-close" onclick="window.close()">Close Window</button>
    </div>

<div class="print-container">
    <div class="header" style="border-bottom: 2px solid #0f3057; padding-bottom: 10px; margin-bottom: 15px;">
        <table style="width: 100%; border: none; margin-bottom: 0;">
            <tr style="border: none;">
                <td style="width: 20%; text-align: left; vertical-align: middle; border: none; padding: 0; background: transparent;">
                    <img src="../assets/images/nsti_logo.png" alt="NSTI Logo" style="max-height: 80px;">
                </td>
                <td style="width: 60%; text-align: center; vertical-align: middle; border: none; padding: 0; background: transparent;">
                    <img src="https://www.india.gov.in/sites/upload_files/npi/files/logo_1.png" alt="Govt of India" style="max-height: 55px; margin-bottom: 8px;" onerror="this.onerror=null; this.src='https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg';">
                    <div style="font-size: 13px; font-weight: bold; line-height: 1.4; color: #000;">
                        Government of India<br>
                        Ministry of Skill Development & Entrepreneurship<br>
                        Directorate General of Training<br>
                        Regional Directorate of Skill Development & Entrepreneurship, Telangana
                    </div>
                </td>
                <td style="width: 20%; text-align: right; vertical-align: middle; border: none; padding: 0; background: transparent;">
                    <img src="../assets/images/skill_india.png" alt="Skill India" style="max-height: 80px;">
                </td>
            </tr>
        </table>
        
        <div style="text-align: center; margin-top: 15px; border-top: 1px solid #0f3057; padding-top: 10px;">
            <h1 style="margin: 0; font-size: 18px; color: #0f3057; text-transform: uppercase;">National Skill Training Institute - Ramanthapur</h1>
            <p style="font-size: 13px; margin: 4px 0 8px 0; color: #000;">Hyderabad, 500013</p>
            <h2 style="margin: 0 0 5px 0; font-size: 15px; color: #000;">Online Grievance Cell</h2>
            <p style="font-size: 13px; margin: 0; color: #000;"><strong>OFFICIAL GRIEVANCE REPORT</strong></p>
        </div>
    </div>

    <div class="section-title">Complainant Details</div>
    <table>
        <tr>
            <th>Name</th>
            <td><?php echo htmlspecialchars($g['user_name']); ?> (<?php echo ucfirst(htmlspecialchars($g['user_role'])); ?>)</td>
        </tr>
        <tr>
            <th>Contact Number</th>
            <td><?php echo htmlspecialchars($g['contact'] ?? 'N/A'); ?></td>
        </tr>
        <tr>
            <th>Email Address</th>
            <td><?php echo htmlspecialchars($g['email'] ?? 'N/A'); ?></td>
        </tr>
    </table>

    <div class="section-title">Grievance Details</div>
    <table>
        <tr>
            <th>Grievance ID</th>
            <td><strong><?php echo htmlspecialchars($g['complaint_id']); ?></strong></td>
        </tr>
        <tr>
            <th>Date Submitted</th>
            <td><?php echo date('d M Y, h:i A', strtotime($g['created_at'])); ?></td>
        </tr>
        <tr>
            <th>Category</th>
            <td><?php echo htmlspecialchars($g['category']); ?></td>
        </tr>
        <tr>
            <th>Priority</th>
            <td><?php echo htmlspecialchars($g['priority']); ?></td>
        </tr>
        <tr>
            <th>Current Status</th>
            <td><strong><?php echo htmlspecialchars($g['status']); ?></strong></td>
        </tr>
        <tr>
            <th>Subject / Title</th>
            <td><?php echo htmlspecialchars($g['title']); ?></td>
        </tr>
    </table>

    <div class="section-title">Detailed Description</div>
    <div class="description-box">
<?php echo htmlspecialchars($g['description']); ?>
    </div>

    <?php if (!empty($updates)): ?>
    <div class="section-title">Resolution Timeline</div>
    <div class="timeline">
        <?php foreach ($updates as $u): ?>
            <div class="timeline-item">
                <h4>Status: <?php echo htmlspecialchars($u['status']); ?> - <?php echo date('d M Y, h:i A', strtotime($u['created_at'])); ?></h4>
                <p><strong>Message:</strong> <?php echo htmlspecialchars($u['message']); ?></p>
                <p><em>Updated By: <?php echo htmlspecialchars($u['updater_name']); ?> (<?php echo ucfirst(htmlspecialchars($u['updater_role'])); ?>)</em></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="signature-section">
        <div class="signature-box">
            Signature of Complainant<br>
            (<?php echo htmlspecialchars($g['user_name']); ?>)
        </div>
        <div class="signature-box">
            Signature of Receiving Officer<br>
            (Official Seal/Sign)
        </div>
    </div>

    <div class="footer">
        This is a system-generated document from the Online Grievance Cell, NSTI-R Hyderabad.
        <br>Generated on: <?php echo date('d M Y, h:i A'); ?>
    </div>

    </div>
</div>

</body>
</html>
