<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

// Fetch categories
$stmt = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
$categories = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $category_id = $_POST['category_id'];
    $priority = $_POST['priority'];
    $description = sanitize($_POST['description']);
    $user_id = $_SESSION['user_id'];
    $complaint_id = generateComplaintID();

    // Check if the selected category is "Other"
    $stmt_cat = $pdo->prepare("SELECT name FROM categories WHERE id = ?");
    $stmt_cat->execute([$category_id]);
    $cat_row = $stmt_cat->fetch();

    if ($cat_row && strtolower(trim($cat_row['name'])) === 'other' && isset($_POST['custom_category']) && !empty(trim($_POST['custom_category']))) {
        $custom_cat_name = substr(sanitize(trim($_POST['custom_category'])), 0, 50);

        // Check if this custom category name already exists (case-insensitively)
        $stmt_check = $pdo->prepare("SELECT id FROM categories WHERE LOWER(name) = ?");
        $stmt_check->execute([strtolower($custom_cat_name)]);
        $existing_cat = $stmt_check->fetch();

        if ($existing_cat) {
            $category_id = $existing_cat['id'];
        } else {
            // Insert new category
            $stmt_insert = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt_insert->execute([$custom_cat_name]);
            $category_id = $pdo->lastInsertId();
        }
    }

    // File Upload logic
    $attachment = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'docx'];
        $filename = $_FILES['attachment']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = $complaint_id . '.' . $ext;
            $upload_path = '../uploads/' . $new_filename;
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $upload_path)) {
                $attachment = $new_filename;
            }
        }
    }

    $stmt = $pdo->prepare("INSERT INTO grievances (complaint_id, user_id, category_id, title, description, priority, attachment) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$complaint_id, $user_id, $category_id, $title, $description, $priority, $attachment])) {
        
        // Add notification for admin
        $stmt_notif = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES ((SELECT id FROM users WHERE role='admin' LIMIT 1), ?)");
        $stmt_notif->execute(["New grievance submitted: $complaint_id"]);

        redirect('dashboard.php', 'Grievance submitted successfully! ID: ' . $complaint_id, 'success');
    } else {
        $_SESSION['msg'] = "Failed to submit grievance. Please try again.";
        $_SESSION['msg_type'] = "error";
    }
}

include_once '../includes/header.php';
?>

<style>
    .form-group-custom {
        position: relative;
        margin-bottom: 1.5rem;
    }
    .form-group-custom .icon-wrapper {
        position: absolute;
        left: 1rem;
        top: 2.3rem;
        color: #f472b6;
        font-size: 1.1rem;
        z-index: 5;
    }
    .form-group-custom .form-control {
        padding-left: 3rem;
        border-radius: 1rem;
        transition: all 0.3s ease;
    }
    .form-group-custom select.form-control {
        padding-left: 3rem;
        appearance: none;
        -webkit-appearance: none;
    }
    .form-group-custom textarea.form-control {
        padding-top: 1rem;
        padding-left: 3rem;
    }
    .form-group-custom .icon-wrapper-textarea {
        top: 2.5rem;
    }
    .form-label-custom {
        font-weight: 600;
        margin-bottom: 0.5rem;
        font-size: 0.95rem;
        letter-spacing: 0.5px;
        display: block;
    }
    .file-upload-wrapper {
        border: 2px dashed var(--glass-border, #cbd5e1);
        border-radius: 1rem;
        padding: 2rem;
        text-align: center;
        background: var(--card-bg, #f8fafc);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    .file-upload-wrapper:hover {
        border-color: #8b5cf6;
    }
    .file-upload-input {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0 !important;
        cursor: pointer;
        z-index: 10;
    }
    .btn-submit-custom {
        border-radius: 1rem;
        font-size: 1.1rem;
        letter-spacing: 1px;
        background: linear-gradient(135deg, #f472b6 0%, #8b5cf6 100%);
        border: none;
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    .btn-submit-custom:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 25px rgba(139, 92, 246, 0.4);
    }
</style>

<div class="row justify-content-center fade-in">
    <div class="col-lg-8">
        <div class="glass-card theme-card p-4 p-md-5 mb-5">
            <div class="d-flex align-items-center justify-content-between mb-5 border-bottom pb-3 theme-border">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-circle me-3 shadow-sm" style="background: linear-gradient(135deg, #8b5cf6, #f472b6);">
                        <i class="fas fa-file-signature text-white fs-4"></i>
                    </div>
                    <div>
                        <h2 class="mb-0 fw-bold theme-text-main">Lodge a Grievance</h2>
                        <p class="theme-text-muted mb-0 small">Please provide the details below</p>
                    </div>
                </div>
                <a href="dashboard.php" class="btn btn-outline-secondary btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fas fa-times"></i></a>
            </div>
            
            <form action="submit_grievance.php" method="POST" enctype="multipart/form-data">
                <div class="form-group-custom">
                    <label class="form-label-custom theme-text-main">Complaint Subject/Title <span class="text-danger">*</span></label>
                    <div class="icon-wrapper"><i class="fas fa-heading"></i></div>
                    <input type="text" name="title" class="form-control" placeholder="Brief summary of your issue" required>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group-custom">
                            <label class="form-label-custom theme-text-main">Category <span class="text-danger">*</span></label>
                            <div class="icon-wrapper"><i class="fas fa-tags"></i></div>
                            <select name="category_id" id="category_select" class="form-control theme-input" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group-custom">
                            <label class="form-label-custom theme-text-main">Priority Level</label>
                    <div class="icon-wrapper"><i class="fas fa-exclamation-circle"></i></div>
                            <select name="priority" class="form-control theme-input">
                                <option value="Low">Low</option>
                                <option value="Medium" selected>Medium</option>
                                <option value="High">High (Urgent)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="form-group-custom" id="custom_category_div" style="display: none;">
                    <label class="form-label-custom theme-text-main">Specify Category <span class="text-danger">*</span></label>
                    <div class="icon-wrapper"><i class="fas fa-pen"></i></div>
                    <input type="text" name="custom_category" id="custom_category" class="form-control theme-input" placeholder="Enter custom category name" maxlength="50">
                </div>

                <div class="form-group-custom">
                    <label class="form-label-custom theme-text-main">Detailed Description <span class="text-danger">*</span></label>
                    <div class="icon-wrapper icon-wrapper-textarea"><i class="fas fa-align-left"></i></div>
                    <textarea name="description" class="form-control theme-input" rows="5" placeholder="Please provide all details..." required></textarea>
                </div>

                <div class="form-group-custom mb-5">
                    <label class="form-label-custom theme-text-main">Attach Supporting Document <span class="theme-text-muted" style="font-weight: 400; font-size: 0.8rem;">(Optional)</span></label>
                    <div class="file-upload-wrapper mt-2">
                        <i class="fas fa-cloud-upload-alt fs-1 mb-3" style="color: #8b5cf6;"></i>
                        <h6 class="mb-1 theme-text-main">Click or drag file to upload</h6>
                        <p class="theme-text-muted small mb-0">Allowed types: JPG, PNG, PDF, DOCX (Max 2MB)</p>
                        <input type="file" name="attachment" id="attachment" class="file-upload-input" onchange="document.getElementById('file-name').textContent = this.files[0] ? this.files[0].name : ''">
                        <div id="file-name" class="mt-3 text-primary fw-bold small"></div>
                    </div>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-premium btn-submit-custom py-3 text-white fw-bold text-uppercase">
                        <i class="fas fa-paper-plane me-2"></i> Submit Complaint
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category_select');
    const customCategoryDiv = document.getElementById('custom_category_div');
    const customCategoryInput = document.getElementById('custom_category');

    function toggleCustomCategory() {
        const selectedOption = categorySelect.options[categorySelect.selectedIndex];
        const selectedText = selectedOption ? selectedOption.text.trim().toLowerCase() : '';
        
        if (selectedText === 'other') {
            customCategoryDiv.style.display = 'block';
            customCategoryInput.setAttribute('required', 'required');
        } else {
            customCategoryDiv.style.display = 'none';
            customCategoryInput.removeAttribute('required');
            customCategoryInput.value = '';
        }
    }

    if (categorySelect) {
        categorySelect.addEventListener('change', toggleCustomCategory);
        // Run on page load in case of browser form state restoration
        toggleCustomCategory();
    }
});
</script>

<?php include_once '../includes/footer.php'; ?>
