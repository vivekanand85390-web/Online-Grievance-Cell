<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Handle Actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $id = (int)$_GET['id'];
    
    if ($action === 'remove') {
        $stmt = $pdo->prepare("DELETE FROM grievances WHERE id = ?");
        $stmt->execute([$id]);
        redirect('track_grievance.php', 'Grievance removed successfully!', 'success');
    } elseif ($action === 'disable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 1 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('track_grievance.php', 'Grievance disabled.', 'success');
    } elseif ($action === 'enable') {
        $stmt = $pdo->prepare("UPDATE grievances SET is_disabled = 0 WHERE id = ?");
        $stmt->execute([$id]);
        redirect('track_grievance.php', 'Grievance enabled.', 'success');
    }
}

// Tab type determination (default to student complaints for staff, and own complaints for students)
$type = $_GET['type'] ?? 'my';

// Build query conditions
if ($user_role === 'staff' && $type === 'student') {
    $where = "WHERE u.role = 'student'";
} else {
    $where = "WHERE g.user_id = $user_id";
}

// Search and Filter
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $s = sanitize($_GET['search']);
    $where .= " AND (g.complaint_id LIKE '%$s%' OR g.title LIKE '%$s%')";
}
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $st = sanitize($_GET['status']);
    $where .= " AND g.status = '$st'";
}

$stmt = $pdo->query("SELECT g.*, c.name as category, u.name as complainant_name 
                       FROM grievances g 
                       JOIN categories c ON g.category_id = c.id 
                       JOIN users u ON g.user_id = u.id
                       $where 
                       ORDER BY g.created_at DESC");
$complaints = $stmt->fetchAll();

include_once '../includes/header.php';
?>

<div class="fade-in">
    <style>
        .action-buttons {
            display: flex;
            gap: 4px;
        }
        .btn-action {
            display: inline-block;
            padding: 5px 12px;
            color: #ffffff !important;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            border-radius: 4px;
            transition: opacity 0.2s;
            text-align: center;
        }
        .btn-action:hover {
            opacity: 0.85;
        }
        .btn-view { background-color: #22c55e; }
        .btn-edit { background-color: #06b6d4; }
        .btn-remove { background-color: #ef4444; }
        .btn-disable { background-color: #f59e0b; }
        .btn-active { background-color: #6b7280; }
    </style>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold theme-text-main">
                <?php echo ($user_role === 'staff' && $type === 'student') ? 'Student Complaints' : 'Track Grievances'; ?>
            </h2>
            <p class="theme-text-muted">
                <?php echo ($user_role === 'staff' && $type === 'student') 
                    ? 'Review and resolve complaints submitted by students.' 
                    : 'History of all grievances submitted by you.'; ?>
            </p>
        </div>
        <a href="submit_grievance.php" class="btn btn-premium"><i class="fas fa-plus me-2"></i>New Complaint</a>
    </div>

    <!-- Staff Tab Selector -->
    <?php if ($user_role === 'staff'): ?>
        <div class="d-flex gap-3 mb-4">
            <a href="?type=student" class="btn <?php echo $type === 'student' ? 'btn-premium' : 'btn-outline-primary'; ?> rounded-pill px-4 text-uppercase fw-bold" style="letter-spacing: 0.5px;">Student Grievances</a>
            <a href="?type=my" class="btn <?php echo $type === 'my' ? 'btn-premium' : 'btn-outline-primary'; ?> rounded-pill px-4 text-uppercase fw-bold" style="letter-spacing: 0.5px;">My Personal Grievances</a>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="glass-card p-3 mb-4">
        <form action="track_grievance.php" method="GET" class="row g-3">
            <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-secondary text-muted"><i class="fas fa-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Search by ID or Title..." value="<?php echo $_GET['search'] ?? ''; ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?php echo ($_GET['status'] ?? '') === 'Pending' ? 'selected' : ''; ?>>Not Processed</option>
                    <option value="In Progress" <?php echo ($_GET['status'] ?? '') === 'In Progress' ? 'selected' : ''; ?>>Under Process</option>
                    <option value="Resolved" <?php echo ($_GET['status'] ?? '') === 'Resolved' ? 'selected' : ''; ?>>Resolved Complaint</option>
                    <option value="Rejected" <?php echo ($_GET['status'] ?? '') === 'Rejected' ? 'selected' : ''; ?>>Rejected Complaint</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100 h-100 text-uppercase fw-bold">Filter</button>
            </div>
        </form>
    </div>

    <div class="glass-card theme-card p-0 overflow-hidden">
        <div class="table-responsive">
            <table class="table portal-table table-hover align-middle mb-0">
                <thead>
                    <tr class="border-secondary theme-text-muted">
                        <th class="ps-4 py-3">Complaint ID</th>
                        <th class="py-3">Date</th>
                        <?php if ($user_role === 'staff' && $type === 'student'): ?>
                            <th class="py-3">Student Name</th>
                        <?php endif; ?>
                        <th class="py-3">Category</th>
                        <th class="py-3">Title</th>
                        <th class="py-3">Priority</th>
                        <th class="py-3">Status</th>
                        <th class="py-3 pe-4 text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($complaints)): ?>
                        <tr>
                            <td colspan="<?php echo ($user_role === 'staff' && $type === 'student') ? '8' : '7'; ?>" class="text-center py-5 theme-text-muted">No records found matching your criteria.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $c): ?>
                            <tr class="border-secondary align-middle">
                                <td class="ps-4 fw-bold theme-text-main"><?php echo $c['complaint_id']; ?></td>
                                <td class="theme-text-muted small"><?php echo date('d M Y', strtotime($c['created_at'])); ?></td>
                                <?php if ($user_role === 'staff' && $type === 'student'): ?>
                                    <td class="small fw-semibold"><?php echo htmlspecialchars($c['complainant_name']); ?></td>
                                <?php endif; ?>
                                <td><span class="badge bg-secondary opacity-75"><?php echo $c['category']; ?></span></td>
                                <td class="text-truncate" style="max-width: 250px;"><?php echo htmlspecialchars($c['title']); ?></td>
                                <td><span class="<?php echo getPriorityBadge($c['priority']); ?>"><?php echo $c['priority']; ?></span></td>
                                <td><span class="<?php echo getStatusBadge($c['status']); ?>"><?php echo getStatusLabel($c['status']); ?></span></td>
                                <td class="pe-4 text-end">
                                    <div class="action-buttons" style="justify-content: flex-end;">
                                        <a href="view_grievance.php?id=<?php echo $c['id']; ?>" class="btn-action btn-view">View</a>
                                        <a href="view_grievance.php?id=<?php echo $c['id']; ?>#update-status-form" class="btn-action btn-edit">Edit</a>
                                        <a href="track_grievance.php?action=remove&id=<?php echo $c['id']; ?>" class="btn-action btn-remove" onclick="return confirm('Are you sure you want to permanently remove this grievance?');">Remove</a>
                                        <?php if (isset($c['is_disabled']) && $c['is_disabled']): ?>
                                            <a href="track_grievance.php?action=enable&id=<?php echo $c['id']; ?>" class="btn-action btn-active" style="background-color: #6b7280;">Active</a>
                                        <?php else: ?>
                                            <a href="track_grievance.php?action=disable&id=<?php echo $c['id']; ?>" class="btn-action btn-disable" onclick="return confirm('Are you sure you want to disable this grievance?');">Disable</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
