<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$user_id = $_SESSION['user_id'];

// Handle Avatar Upload Form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_pic'])) {
    if ($_FILES['profile_pic']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['profile_pic']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'user_' . $user_id . '_' . time() . '.' . $ext;
            $upload_path = '../uploads/' . $new_filename;
            
            if (!file_exists('../uploads')) {
                mkdir('../uploads', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $upload_path)) {
                $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
                if ($stmt->execute([$new_filename, $user_id])) {
                    $_SESSION['msg'] = "Profile picture updated successfully!";
                    $_SESSION['msg_type'] = "success";
                } else {
                    $_SESSION['msg'] = "Failed to update profile picture in database.";
                    $_SESSION['msg_type'] = "error";
                }
            } else {
                $_SESSION['msg'] = "Failed to move uploaded file.";
                $_SESSION['msg_type'] = "error";
            }
        } else {
            $_SESSION['msg'] = "Invalid file type. Only JPG, JPEG, and PNG are allowed.";
            $_SESSION['msg_type'] = "error";
        }
    } else {
        $_SESSION['msg'] = "File upload error code: " . $_FILES['profile_pic']['error'];
        $_SESSION['msg_type'] = "error";
    }
    header("Location: profile.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_details'])) {
    $name = sanitize($_POST['name']);
    $contact = sanitize($_POST['contact']);
    $trade = sanitize($_POST['trade'] ?? '');
    $roll_no = sanitize($_POST['roll_no'] ?? '');
    $university = sanitize($_POST['university'] ?? '');
    $college = sanitize($_POST['college'] ?? '');
    $year = sanitize($_POST['year'] ?? '');
    $state = sanitize($_POST['state'] ?? '');
    $country = sanitize($_POST['country'] ?? '');
    $pincode = sanitize($_POST['pincode'] ?? '');

    $stmt = $pdo->prepare("UPDATE users SET 
        name = ?, 
        contact = ?, 
        trade = ?, 
        roll_no = ?, 
        university = ?, 
        college = ?, 
        year = ?, 
        state = ?, 
        country = ?, 
        pincode = ?,
        updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?");
        
    if ($stmt->execute([
        $name, 
        $contact, 
        $trade, 
        $roll_no, 
        $university, 
        $college, 
        $year, 
        $state, 
        $country, 
        $pincode, 
        $user_id
    ])) {
        $_SESSION['name'] = $name;
        $_SESSION['msg'] = "Profile updated successfully!";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['msg'] = "Failed to update profile.";
        $_SESSION['msg_type'] = "error";
    }
    
    // Refresh to show changes and new update time
    header("Location: profile.php");
    exit();
}

// Fetch current user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$u = $stmt->fetch();

$profile_pic = !empty($u['profile_pic']) ? $u['profile_pic'] : '';
$profile_pic_path = '../uploads/' . $profile_pic;
$profile_pic_version = file_exists($profile_pic_path) ? filemtime($profile_pic_path) : time();

include_once '../includes/header.php';
?>

<div class="profile-wrapper" style="position: relative; padding: 2rem 1rem; min-height: calc(100vh - 60px); background: linear-gradient(135deg, #f8fafc, #f1f5f9); overflow: hidden;">
    <!-- Background Decor for Glassmorphism -->
    <div class="bg-orb orb-1"></div>
    <div class="bg-orb orb-2"></div>

    <div class="mb-5 position-relative z-1" style="text-align: center;">
        <h2 class="fw-bold" style="color: #1e293b; letter-spacing: -1px; font-size: 2.5rem;"><i class="fas fa-user-edit me-3" style="color: #a855f7;"></i>Profile Information</h2>
        <p style="color: #64748b; font-size: 1.15rem; font-weight: 500;">Review and update your educational and personal parameters.</p>
    </div>

    
        <style>
        .profile-wrapper {
            animation: fadeIn 0.6s ease-out;
        }
        .bg-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.5;
            z-index: 0;
            animation: float 10s infinite ease-in-out alternate;
        }
        .orb-1 { width: 500px; height: 500px; background: #c084fc; top: -150px; right: -100px; animation-delay: 0s; }
        .orb-2 { width: 450px; height: 450px; background: #60a5fa; bottom: -100px; left: -150px; animation-delay: -5s; }
        
        @keyframes float {
            0% { transform: translateY(0px) scale(1); }
            100% { transform: translateY(40px) scale(1.05); }
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            100% { background-position: 100% 50%; }
        }
        .profile-glass {
            background: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(25px);
            -webkit-backdrop-filter: blur(25px);
            border-radius: 28px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(255,255,255,0.6) inset;
            padding: 4rem;
            position: relative;
            z-index: 10;
            max-width: 1050px;
            margin: 0 auto;
        }
        .profile-glass::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 6px;
            background: linear-gradient(90deg, #6366f1, #a855f7, #ec4899, #6366f1);
            background-size: 300% 100%;
            animation: gradientMove 4s infinite linear;
        }
        .profile-header {
            display: flex;
            align-items: center;
            padding-bottom: 2.5rem;
            margin-bottom: 3rem;
            border-bottom: 2px dashed rgba(148, 163, 184, 0.3);
        }
        .profile-input-wrapper {
            position: relative;
            margin-bottom: 2.2rem;
        }
        .profile-input-wrapper i {
            position: absolute;
            left: 20px;
            top: 45px;
            color: #94a3b8;
            font-size: 1.15rem;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .profile-input {
            width: 100%;
            padding: 15px 20px 15px 55px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.5);
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(5px);
            font-size: 1.05rem;
            color: #1e293b;
            font-weight: 600;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.01), 0 2px 4px rgba(0,0,0,0.02);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .profile-input:hover {
            background: rgba(255, 255, 255, 0.9);
            border-color: rgba(168, 85, 247, 0.3);
            transform: translateY(-1px);
        }
        .profile-input:focus {
            outline: none;
            background-color: #ffffff;
            border-color: #a855f7;
            box-shadow: 0 0 0 4px rgba(168, 85, 247, 0.15), 0 8px 15px -3px rgba(0,0,0,0.05);
            transform: translateY(-2px);
        }
        .profile-input-wrapper:focus-within i {
            color: #a855f7;
            transform: scale(1.15);
        }
        .profile-label {
            font-size: 0.75rem;
            font-weight: 800;
            color: #475569;
            margin-bottom: 12px;
            display: block;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            padding-left: 5px;
        }
        .profile-readonly {
            background-color: rgba(241, 245, 249, 0.6) !important;
            color: #94a3b8;
            cursor: not-allowed;
            border-color: transparent !important;
            box-shadow: none !important;
        }
        .btn-submit-profile {
            background: linear-gradient(135deg, #6366f1, #a855f7, #ec4899);
            background-size: 200% auto;
            color: white;
            font-weight: 800;
            border: none;
            border-radius: 50px;
            padding: 18px 60px;
            font-size: 1.15rem;
            letter-spacing: 0.5px;
            box-shadow: 0 10px 25px -5px rgba(168, 85, 247, 0.4);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .btn-submit-profile:hover {
            background-position: right center;
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 20px 35px -5px rgba(168, 85, 247, 0.5);
        }
        .btn-submit-profile:active {
            transform: translateY(0) scale(0.98);
        }
        .avatar-container {
            position: relative;
            width: 105px;
            height: 105px;
            border-radius: 50%;
            padding: 5px;
            background: linear-gradient(135deg, #6366f1, #a855f7, #ec4899);
            margin-right: 2.5rem;
            box-shadow: 0 0 35px rgba(168, 85, 247, 0.5);
            animation: pulseGlow 3s infinite alternate;
            flex-shrink: 0;
        }
        @keyframes pulseGlow {
            from { box-shadow: 0 0 20px rgba(168, 85, 247, 0.3); }
            to { box-shadow: 0 0 45px rgba(168, 85, 247, 0.7); }
        }
        .avatar-img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #ffffff;
        }
        .avatar-fallback {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 4px solid #ffffff;
        }
        .avatar-fallback i {
            font-size: 3rem;
            color: #8b5cf6;
        }

        /* Dark Mode Overrides */
        [data-theme="dark"] .profile-glass {
            background: rgba(15, 23, 42, 0.75);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.1) inset;
        }
        [data-theme="dark"] .profile-input {
            background: rgba(15, 23, 42, 0.6);
            border-color: rgba(255,255,255,0.1);
            color: #f8fafc;
        }
        [data-theme="dark"] .profile-input:hover {
            background: rgba(30, 41, 59, 0.9);
            border-color: rgba(168, 85, 247, 0.5);
        }
        [data-theme="dark"] .profile-input:focus {
            background-color: #0f172a;
            border-color: #a855f7;
            color: #f8fafc;
        }
        [data-theme="dark"] .profile-label {
            color: #94a3b8;
        }
        [data-theme="dark"] .profile-readonly {
            background-color: rgba(30, 41, 59, 0.6) !important;
            color: #64748b;
        }
        [data-theme="dark"] .avatar-img, [data-theme="dark"] .avatar-fallback {
            border-color: #0f172a;
        }
        [data-theme="dark"] .avatar-fallback {
            background: #0f172a;
        }

        .profile-avatar-overlay {
            position: absolute;
            top: 5px;
            left: 5px;
            right: 5px;
            bottom: 5px;
            border-radius: 50%;
            background: rgba(15, 23, 42, 0.6);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            color: #ffffff;
            backdrop-filter: blur(2px);
            cursor: pointer;
        }
        .avatar-container:hover .profile-avatar-overlay {
            opacity: 1;
        }
        .profile-avatar-overlay i {
            font-size: 1.5rem;
            margin-bottom: 0.25rem;
        }
        .profile-avatar-overlay span {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .badge-update {
            background: rgba(255, 255, 255, 0.8);
            color: #6366f1;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.6);
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
        }
        .z-1 { z-index: 1; }
    </style>

    <div class="profile-glass">
        <div class="profile-header">
            <form action="profile.php" method="POST" enctype="multipart/form-data" id="avatarForm" style="display: contents;">
                <div class="avatar-container" onclick="document.getElementById('profile_pic_input').click();" style="cursor:pointer;">
                    <?php if (!empty($profile_pic)): ?>
                        <img src="../uploads/<?php echo htmlspecialchars($profile_pic); ?>?v=<?php echo htmlspecialchars($profile_pic_version); ?>" class="avatar-img">
                    <?php else: ?>
                        <div class="avatar-fallback" style="display: flex;">
                            <?php if (($_SESSION['role'] ?? 'student') === 'student'): ?>
                                <i class="fas fa-user-graduate" style="background: linear-gradient(135deg, #6366f1, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                            <?php elseif (($_SESSION['role'] ?? 'student') === 'staff'): ?>
                                <i class="fas fa-user-tie" style="background: linear-gradient(135deg, #334155, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                            <?php elseif (($_SESSION['role'] ?? 'student') === 'parent'): ?>
                                <svg viewBox="0 0 100 100" style="width: 2.2rem; height: 2.2rem;" xmlns="http://www.w3.org/2000/svg">
                                  <circle cx="50" cy="50" r="45" fill="none" stroke="#334155" stroke-width="8"/>
                                  <circle cx="50" cy="28" r="8" fill="#334155"/>
                                  <path d="M 50 40 Q 25 45 10 75 Q 20 90 30 75 Q 35 65 40 60 L 35 100 L 65 100 L 60 60 Q 65 65 70 75 Q 80 90 90 75 Q 75 45 50 40 Z" fill="#334155"/>
                                  <g fill="#334155" stroke="#ffffff" stroke-width="3" stroke-linejoin="round">
                                    <circle cx="25" cy="58" r="6"/>
                                    <path d="M 25 66 Q 12 70 8 95 L 42 95 Q 38 70 25 66 Z"/>
                                    <circle cx="75" cy="58" r="6"/>
                                    <path d="M 75 66 Q 62 70 58 95 L 92 95 Q 88 70 75 66 Z"/>
                                  </g>
                                </svg>
                            <?php else: ?>
                                <i class="fas fa-user"></i>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="profile-avatar-overlay">
                        <i class="fas fa-camera"></i>
                        <span>Upload Photo</span>
                    </div>
                </div>
                <input type="file" id="profile_pic_input" name="profile_pic" style="display:none;" onchange="document.getElementById('avatarForm').submit();" accept="image/*">
            </form>
            <div>
                <h3 class="mb-0 fw-bold theme-text-main" style="letter-spacing: -0.5px; font-size: 1.8rem;"><?php echo htmlspecialchars($u['name']); ?>'s Profile</h3>
                <div class="badge-update">
                    <i class="fas fa-clock"></i> Last Updated: <?php echo ($u['updated_at'] && $u['updated_at'] !== '0000-00-00 00:00:00') ? date('d M Y, h:i A', strtotime($u['updated_at'])) : 'Never'; ?>
                </div>
            </div>
        </div>
        
        <form action="profile.php" method="POST">
            <input type="hidden" name="update_details" value="1">
            <div class="row g-x-5">
                <!-- Column 1 -->
                <div class="col-md-6 pe-md-4">
                    <div class="profile-input-wrapper">
                        <label class="profile-label">Full Name</label>
                        <input type="text" name="name" class="profile-input" value="<?php echo htmlspecialchars($u['name'] ?? ''); ?>" required pattern="^[A-Za-z\s]+$" title="Only letters and spaces are allowed">
                        <i class="fas fa-user"></i>
                    </div>
                    
                    <div class="profile-input-wrapper">
                        <label class="profile-label"><?php echo ($u['role'] === 'staff') ? 'Employee ID' : 'Roll No'; ?></label>
                        <input type="text" name="roll_no" class="profile-input" value="<?php echo htmlspecialchars($u['roll_no'] ?? ''); ?>" placeholder="<?php echo ($u['role'] === 'staff') ? 'Enter Employee ID' : 'Enter Roll No'; ?>" pattern="^[A-Za-z0-9\s\-]+$" title="Only alphanumeric characters, spaces and hyphens are allowed" <?php echo ($u['role'] === 'staff') ? 'readonly style="background-color: #e2e8f0; cursor: not-allowed;"' : ''; ?>>
                        <i class="fas fa-id-card"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">College</label>
                        <input type="text" name="college" class="profile-input" value="<?php echo htmlspecialchars($u['college'] ?? ''); ?>" placeholder="Enter college name" pattern="^[A-Za-z0-9\s\.,\-]+$" title="Only letters, numbers, spaces, dots, commas and hyphens are allowed">
                        <i class="fas fa-building"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">Year</label>
                        <input type="text" name="year" class="profile-input" value="<?php echo htmlspecialchars($u['year'] ?? ''); ?>" placeholder="e.g. First, Second, Third, Fourth" pattern="^[A-Za-z0-9\s\-]+$" title="Only alphanumeric characters, spaces and hyphens are allowed">
                        <i class="fas fa-calendar-alt"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">State</label>
                        <select name="state" class="profile-input">
                            <option value="">Select State</option>
                            <?php 
                            $states = [
                                'Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 
                                'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Goa', 
                                'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 
                                'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 
                                'Mizoram', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 
                                'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
                            ];
                            foreach ($states as $s) {
                                $selected = ($u['state'] === $s) ? 'selected' : '';
                                echo "<option value=\"$s\" $selected>$s</option>";
                            }
                            ?>
                        </select>
                        <i class="fas fa-map"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">Pincode</label>
                        <input type="text" name="pincode" class="profile-input" value="<?php echo htmlspecialchars($u['pincode'] ?? ''); ?>" placeholder="Enter 6-digit pincode" pattern="^[0-9]{6}$" maxlength="6" title="Pincode must be exactly 6 digits">
                        <i class="fas fa-map-pin"></i>
                    </div>
                </div>

                <!-- Column 2 -->
                <div class="col-md-6 ps-md-4">
                    <div class="profile-input-wrapper">
                        <label class="profile-label">User Email <span class="text-danger fw-normal ms-1" style="font-size: 0.7rem;">(READ-ONLY)</span></label>
                        <input type="email" class="profile-input profile-readonly" value="<?php echo htmlspecialchars($u['email'] ?? ''); ?>" readonly>
                        <i class="fas fa-envelope"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">University</label>
                        <input type="text" name="university" class="profile-input" value="<?php echo htmlspecialchars($u['university'] ?? ''); ?>" placeholder="Enter university name" pattern="^[A-Za-z0-9\s\.,\-]+$" title="Only letters, numbers, spaces, dots, commas and hyphens are allowed">
                        <i class="fas fa-university"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label"><?php echo ($u['role'] === 'staff') ? 'Designation' : 'Trade'; ?></label>
                        <input type="text" name="trade" class="profile-input" value="<?php echo htmlspecialchars($u['trade'] ?? ''); ?>" placeholder="<?php echo ($u['role'] === 'staff') ? 'e.g. M.T.S, Clerk, etc.' : 'e.g. CSA, Fitter, etc.'; ?>" required pattern="^[A-Za-z0-9\s\.,\-]+$" title="Only alphanumeric characters, spaces, dots, commas and hyphens are allowed">
                        <i class="fas fa-briefcase"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">Contact Number</label>
                        <input type="text" name="contact" class="profile-input" value="<?php echo htmlspecialchars($u['contact'] ?? ''); ?>" placeholder="Enter 10-digit number" pattern="^[0-9]{10}$" maxlength="10" title="Contact number must be exactly 10 digits">
                        <i class="fas fa-phone-alt"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">Country</label>
                        <input type="text" name="country" class="profile-input" value="<?php echo htmlspecialchars($u['country'] ?? ''); ?>" placeholder="Enter country" pattern="^[A-Za-z\s]+$" title="Only letters and spaces are allowed">
                        <i class="fas fa-globe"></i>
                    </div>

                    <div class="profile-input-wrapper">
                        <label class="profile-label">Registration Date <span class="text-danger fw-normal ms-1" style="font-size: 0.7rem;">(READ-ONLY)</span></label>
                        <input type="text" class="profile-input profile-readonly" value="<?php echo date('d M Y, h:i A', strtotime($u['created_at'])); ?>" readonly>
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>

            <!-- Submit Button centered -->
            <div class="text-center mt-5 mb-2 d-flex justify-content-center gap-3">
                <button type="submit" class="btn-submit-profile">
                    <i class="fas fa-save me-2" style="font-size: 0.9rem;"></i> SAVE CHANGES
                </button>
            </div>
        </form>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
