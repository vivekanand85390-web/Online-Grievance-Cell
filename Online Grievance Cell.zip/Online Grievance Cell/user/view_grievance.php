<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$grievance_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

if (!$grievance_id) {
    redirect('track_grievance.php');
}

// Fetch grievance details
$stmt = $pdo->prepare("SELECT g.*, c.name as category, u.name as user_name, u.role as user_role 
                       FROM grievances g 
                       JOIN categories c ON g.category_id = c.id 
                       JOIN users u ON g.user_id = u.id 
                       WHERE g.id = ?");
$stmt->execute([$grievance_id]);
$g = $stmt->fetch();

// Security check:
// Students can only view their own grievances.
// Staff can view their own grievances AND any student's grievances.
$is_authorized = false;
if ($g) {
    if ($user_role === 'student' && $g['user_id'] == $user_id) {
        $is_authorized = true;
    } elseif ($user_role === 'staff' && ($g['user_role'] === 'student' || $g['user_id'] == $user_id)) {
        $is_authorized = true;
    }
}

if (!$is_authorized) {
    redirect('track_grievance.php', 'Grievance not found or unauthorized access.', 'error');
}

// Handle update by staff
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user_role === 'staff') {
    $status = $_POST['status'];
    $message = sanitize($_POST['message']);

    $pdo->beginTransaction();
    try {
        // Update grievance status
        $stmt_u = $pdo->prepare("UPDATE grievances SET status = ? WHERE id = ?");
        $stmt_u->execute([$status, $grievance_id]);

        // Add to updates table
        $stmt_tu = $pdo->prepare("INSERT INTO grievance_updates (grievance_id, updated_by, status, message) VALUES (?, ?, ?, ?)");
        $stmt_tu->execute([$grievance_id, $user_id, $status, $message]);

        // Add notification for user (student)
        $stmt_not = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $stmt_not->execute([$g['user_id'], "Grievance {$g['complaint_id']} status updated to $status by Faculty {$_SESSION['name']}"]);

        $pdo->commit();
        redirect("view_grievance.php?id=$grievance_id", 'Grievance updated successfully', 'success');
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['msg'] = "Error updating grievance: " . $e->getMessage();
        $_SESSION['msg_type'] = "error";
    }
}

// Fetch updates/timeline
$stmt = $pdo->prepare("SELECT gu.*, u.name as updater_name, u.role as updater_role 
                       FROM grievance_updates gu 
                       JOIN users u ON gu.updated_by = u.id 
                       WHERE gu.grievance_id = ? 
                       ORDER BY gu.created_at ASC");
$stmt->execute([$grievance_id]);
$updates = $stmt->fetchAll();

include_once '../includes/header.php';
?>

<div class="row fade-in">
    <!-- Main Content -->
    <div class="col-lg-8">
        <div class="glass-card theme-card mb-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0 theme-text-main"><?php echo htmlspecialchars($g['title']); ?></h3>
                <div>
                    <a href="print_grievance.php?id=<?php echo $grievance_id; ?>" target="_blank" class="btn btn-outline-info me-2"><i class="fas fa-print me-1"></i> Print Form</a>
                    <span class="<?php echo getStatusBadge($g['status']); ?> fs-6 py-2 px-3"><?php echo getStatusLabel($g['status']); ?></span>
                </div>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-4">
                    <p class="theme-text-muted small mb-1">Complaint ID</p>
                    <p class="fw-bold theme-text-main"><?php echo $g['complaint_id']; ?></p>
                </div>
                <div class="col-md-4">
                    <p class="theme-text-muted small mb-1">Category</p>
                    <p class="fw-bold theme-text-main"><?php echo $g['category']; ?></p>
                </div>
                <div class="col-md-4">
                    <p class="theme-text-muted small mb-1">Date Submitted</p>
                    <p class="fw-bold theme-text-main"><?php echo date('d M Y, h:i A', strtotime($g['created_at'])); ?></p>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="theme-text-muted mb-3 border-bottom border-secondary pb-2">Description</h5>
                <p class="theme-text-main"><?php echo nl2br($g['description']); ?></p>
            </div>

            <?php if ($g['attachment']): ?>
                <div class="mb-4">
                    <h5 class="theme-text-muted mb-3">Attachment</h5>
                    <a href="../uploads/<?php echo $g['attachment']; ?>" target="_blank" class="btn btn-outline-info rounded-pill">
                        <i class="fas fa-paperclip me-2"></i>View Attachment
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Progress Update Form for Staff -->
        <?php if ($user_role === 'staff' && $g['user_role'] === 'student' && $g['status'] != 'Resolved'): ?>
        <div class="glass-card theme-card mb-4">
            <h4 class="mb-4 theme-text-main">Update Resolution Status</h4>
            <form action="view_grievance.php?id=<?php echo $grievance_id; ?>" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="input-label theme-text-main">Update Status</label>
                        <select name="status" class="form-control" required>
                            <option value="Pending" <?php echo $g['status'] == 'Pending' ? 'selected' : ''; ?>>Not Processed</option>
                            <option value="In Progress" <?php echo $g['status'] == 'In Progress' ? 'selected' : ''; ?>>Under Process</option>
                            <option value="Resolved" <?php echo $g['status'] == 'Resolved' ? 'selected' : ''; ?>>Resolved Complaint</option>
                            <option value="Rejected" <?php echo $g['status'] == 'Rejected' ? 'selected' : ''; ?>>Rejected Complaint</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="input-label theme-text-main">Faculty/Staff Response Message</label>
                        <textarea name="message" class="form-control" rows="4" placeholder="Enter your response here..." required></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-premium px-5">Submit Update</button>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Timeline / Updates -->
        <div class="glass-card theme-card">
            <h4 class="mb-4 pb-2 border-bottom border-secondary theme-text-main">Resolution Timeline</h4>
            <div class="timeline ps-3 border-start border-secondary">
                <div class="timeline-item mb-4 position-relative">
                    <div class="position-absolute translate-middle-x bg-primary rounded-circle" style="width: 12px; height: 12px; left: -16px; top: 10px;"></div>
                    <div class="ps-3">
                        <p class="mb-1 fw-bold theme-text-main">Grievance Submitted</p>
                        <p class="theme-text-muted small mb-0"><?php echo date('d M Y, h:i A', strtotime($g['created_at'])); ?></p>
                    </div>
                </div>

                <?php foreach ($updates as $u): ?>
                    <div class="timeline-item mb-4 position-relative">
                        <div class="position-absolute translate-middle-x bg-info rounded-circle" style="width: 12px; height: 12px; left: -16px; top: 10px;"></div>
                        <div class="ps-3 p-3 rounded-3" style="background: rgba(139, 92, 246, 0.05); border: 1px solid rgba(139, 92, 246, 0.1);">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <p class="mb-0 fw-bold theme-text-main">
                                    Status updated to <span class="<?php echo getStatusBadge($u['status']); ?>"><?php echo getStatusLabel($u['status']); ?></span>
                                </p>
                                <span class="theme-text-muted small"><?php echo date('d M Y, h:i A', strtotime($u['created_at'])); ?></span>
                            </div>
                            <p class="mb-1 theme-text-main"><?php echo nl2br($u['message']); ?></p>
                            <p class="theme-text-muted small mb-0">By: <?php echo $u['updater_name']; ?> (<?php echo ucfirst($u['updater_role']); ?>)</p>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if ($g['status'] === 'Resolved'): ?>
                    <div class="timeline-item position-relative">
                        <div class="position-absolute translate-middle-x bg-success rounded-circle" style="width: 12px; height: 12px; left: -16px; top: 10px;"></div>
                        <div class="ps-3">
                            <p class="mb-1 fw-bold text-success">Issue Resolved</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar Info -->
    <div class="col-lg-4">
        <div class="glass-card theme-card text-center py-5">
            <div class="mb-4">
                <i class="fas fa-user-shield fa-4x text-primary-gradient" style="background: var(--primary-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
            </div>
            <h4 class="theme-text-main">Assigned Officer</h4>
            <p class="theme-text-muted">The Grievance Officer is reviewing your case. You will receive an update shortly.</p>
            <hr class="my-4 border-secondary opacity-25">
            <h5 class="small text-uppercase theme-text-muted mb-3">Priority</h5>
            <div class="<?php echo getPriorityBadge($g['priority']); ?> fs-6 py-2 px-4 rounded-pill d-inline-block">
                <?php echo $g['priority']; ?>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
