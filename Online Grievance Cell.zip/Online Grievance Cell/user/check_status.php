<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $complaint_id = sanitize($_POST['complaint_id']);
    
    // Find the grievance ID from the complaint ID
    // If student/parent, verify ownership. If staff/admin, allow it or handle in view_grievance.
    // Actually, view_grievance.php already handles authorization checks!
    $stmt = $pdo->prepare("SELECT id FROM grievances WHERE complaint_id = ?");
    $stmt->execute([$complaint_id]);
    $g = $stmt->fetch();
    
    if ($g) {
        redirect("view_grievance.php?id=" . $g['id']);
    } else {
        $error = "No grievance found with that Complaint ID.";
    }
}

include_once '../includes/header.php';
?>

<div class="row justify-content-center fade-in">
    <div class="col-md-8 col-lg-6 mt-5">
        <div class="card border-0 shadow-lg" style="border-radius: 24px; overflow: hidden;">
            <div class="card-header border-0 text-center" style="background: linear-gradient(135deg, #0f3057 0%, #b01c70 100%); padding: 3rem 2rem 2rem;">
                <div class="d-inline-flex align-items-center justify-content-center bg-white mb-3" style="width: 85px; height: 85px; border-radius: 50%; box-shadow: 0 10px 25px rgba(0,0,0,0.15);">
                    <i class="fas fa-search" style="font-size: 2.5rem; color: #b01c70;"></i>
                </div>
                <h3 class="fw-bold text-white mb-0">Track Complaint Status</h3>
            </div>
            
            <div class="card-body" style="padding: 3rem 2.5rem; background-color: #ffffff;">
                <p class="text-center text-muted mb-4" style="font-size: 1.05rem;">Enter your Grievance ID below to view its current status and resolution timeline.</p>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger d-flex align-items-center" style="border-radius: 12px; border-left: 5px solid #dc3545;">
                        <i class="fas fa-exclamation-circle me-3 fs-4"></i>
                        <div><?php echo $error; ?></div>
                    </div>
                <?php endif; ?>
                
                <form action="check_status.php" method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark mb-2 ms-1">Grievance ID</label>
                        <input type="text" name="complaint_id" class="form-control form-control-lg" placeholder="e.g. GRV-XXXXX" required style="border-radius: 12px; border: 2px solid #e2e8f0; background-color: #f8fafc; color: #0f172a; padding: 1rem 1.5rem; font-size: 1.1rem; transition: all 0.3s ease;" onfocus="this.style.borderColor='#0f3057'; this.style.backgroundColor='#ffffff'; this.style.boxShadow='0 0 0 4px rgba(15,48,87,0.1)';" onblur="this.style.borderColor='#e2e8f0'; this.style.backgroundColor='#f8fafc'; this.style.boxShadow='none';">
                    </div>
                    <button type="submit" class="btn btn-lg w-100 text-white fw-bold shadow-sm" style="background: #0f3057; border-radius: 12px; padding: 1rem; font-size: 1.1rem; letter-spacing: 0.5px; transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 10px 20px rgba(15,48,87,0.2)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 .125rem .25rem rgba(0,0,0,.075)';">
                        <i class="fas fa-search me-2"></i> TRACK STATUS
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
