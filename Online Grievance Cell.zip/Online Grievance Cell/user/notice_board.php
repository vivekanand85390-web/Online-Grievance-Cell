<?php
include_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php', 'Please login first', 'warning');
}

$user_role = $_SESSION['role'] ?? 'student';

// Fetch notices for 'all' or specific to the user's role
$stmt = $pdo->prepare("
    SELECT n.*, u.name as created_by_name 
    FROM notices n 
    LEFT JOIN users u ON n.created_by = u.id 
    WHERE n.target_audience = 'all' OR n.target_audience = ? 
    ORDER BY n.created_at DESC
");
$stmt->execute([$user_role]);
$notices = $stmt->fetchAll();

include_once '../includes/header.php';
?>

<div class="fade-in">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">
                    <i class="fas fa-bullhorn text-primary me-2"></i> Notice Board
                </h4>
            </div>
            <p class="theme-text-muted mt-2">Important announcements and updates from the administration.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php if (empty($notices)): ?>
            <div class="col-12">
                <div class="glass-card theme-card text-center p-5">
                    <i class="fas fa-inbox fa-4x theme-text-muted mb-3 opacity-50"></i>
                    <h5 class="theme-text-muted">No notices at the moment.</h5>
                    <p class="mb-0 theme-text">Check back later for updates.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($notices as $notice): ?>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="glass-card theme-card h-100 p-4" style="border-left: 4px solid var(--primary-color);">
                        <div class="card-body p-0">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title fw-bold mb-0 theme-text-main"><?php echo htmlspecialchars($notice['title']); ?></h5>
                                <?php if ($notice['target_audience'] !== 'all'): ?>
                                    <span class="badge bg-secondary">For <?php echo ucfirst($notice['target_audience']); ?>s</span>
                                <?php endif; ?>
                            </div>
                            <div class="theme-text-muted small mb-3">
                                <i class="far fa-clock me-1"></i> <?php echo date('d M Y, h:i A', strtotime($notice['created_at'])); ?>
                                <span class="ms-3"><i class="far fa-user me-1"></i> <?php echo htmlspecialchars($notice['created_by_name'] ?? 'System Admin'); ?></span>
                            </div>
                            <div class="card-text theme-text">
                                <?php echo nl2br(htmlspecialchars($notice['message'])); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
