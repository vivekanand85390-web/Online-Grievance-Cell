<?php
require_once 'includes/functions.php';

try {
    $stmt = $pdo->query("SELECT id, username, roll_no FROM users WHERE role = 'staff'");
    $staff = $stmt->fetchAll();
    $updated = 0;
    
    foreach($staff as $s) {
        // If it doesn't start with EMP, generate a new one
        if (empty($s['roll_no']) || strpos($s['roll_no'], 'EMP') !== 0) {
            $new_id = 'EMP' . rand(100000, 999999);
            $u_stmt = $pdo->prepare("UPDATE users SET roll_no = ? WHERE id = ?");
            $u_stmt->execute([$new_id, $s['id']]);
            echo "Updated staff '{$s['username']}' with Employee ID: $new_id\n";
            $updated++;
        } else {
            echo "Staff '{$s['username']}' already has Employee ID: {$s['roll_no']}\n";
        }
    }
    
    echo "\nTotal existing staff accounts updated: $updated\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
